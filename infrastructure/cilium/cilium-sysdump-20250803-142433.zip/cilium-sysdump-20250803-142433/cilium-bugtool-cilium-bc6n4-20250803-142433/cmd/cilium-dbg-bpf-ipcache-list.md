IP PREFIX/ADDRESS   IDENTITY
10.0.0.43/32        identity=17157 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>             
10.0.0.203/32       identity=4 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                 
10.0.0.220/32       identity=24121 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>             
10.0.0.236/32       identity=64642 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>             
10.0.1.184/32       identity=24121 encryptkey=0 tunnelendpoint=91.217.196.183 flags=hastunnel   
10.0.1.237/32       identity=4 encryptkey=0 tunnelendpoint=91.217.196.183 flags=hastunnel       
91.217.196.183/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                 
91.217.196.189/32   identity=1 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                 
10.0.0.124/32       identity=1 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                 
10.0.1.78/32        identity=2284 encryptkey=0 tunnelendpoint=91.217.196.183 flags=hastunnel    
10.0.1.138/32       identity=6 encryptkey=0 tunnelendpoint=91.217.196.183 flags=hastunnel       
10.0.1.156/32       identity=45704 encryptkey=0 tunnelendpoint=91.217.196.183 flags=hastunnel   
10.0.1.0/24         identity=2 encryptkey=0 tunnelendpoint=91.217.196.183 flags=hastunnel       
0.0.0.0/0           identity=2 encryptkey=0 tunnelendpoint=0.0.0.0 flags=<none>                 
