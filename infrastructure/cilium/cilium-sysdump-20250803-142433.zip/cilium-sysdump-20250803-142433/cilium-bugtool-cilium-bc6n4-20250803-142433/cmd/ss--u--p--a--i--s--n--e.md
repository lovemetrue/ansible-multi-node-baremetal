Total: 644
TCP:   468 (estab 233, closed 168, orphaned 0, timewait 151)

Transport Total     IP        IPv6
RAW	  2         1         1        
UDP	  9         6         3        
TCP	  300       256       44       
INET	  311       263       48       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q        Local Address:Port  Peer Address:PortProcess                                                                              
UNCONN 0      0                 127.0.0.1:37393      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=53)) ino:2218209 sk:102bdb fwmark:0xb00 cgroup:/ <->
UNCONN 0      0             127.0.0.53%lo:53         0.0.0.0:*    uid:102 ino:20777 sk:7005 cgroup:unreachable:989 <->                                
UNCONN 0      0      91.217.196.189%ens18:68         0.0.0.0:*    uid:101 ino:1984148 sk:e8b81 cgroup:unreachable:927 <->                             
UNCONN 0      0                   0.0.0.0:111        0.0.0.0:*    ino:20020 sk:314b cgroup:unreachable:da <->                                         
UNCONN 0      0                   0.0.0.0:8472       0.0.0.0:*    ino:36776 sk:314c cgroup:unreachable:1cf1 <->                                       
UNCONN 0      0                 127.0.0.1:323        0.0.0.0:*    ino:23926 sk:314d cgroup:unreachable:a4d <->                                        
UNCONN 0      0                      [::]:111           [::]:*    ino:22771 sk:314e cgroup:unreachable:da v6only:1 <->                                
UNCONN 0      0                      [::]:8472          [::]:*    ino:36775 sk:314f cgroup:unreachable:1cf1 v6only:1 <->                              
UNCONN 0      0                     [::1]:323           [::]:*    ino:23927 sk:3150 cgroup:unreachable:a4d v6only:1 <->                               
