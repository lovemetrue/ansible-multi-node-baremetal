Node 0, zone      DMA      0      0      0      0      0      0      0      0      1      2      2 
Node 0, zone    DMA32      1      3      0      2      1      2      3      3      3      2    744 
Node 0, zone   Normal     17     40     32    194    196     62     19      7      3      1    144 
