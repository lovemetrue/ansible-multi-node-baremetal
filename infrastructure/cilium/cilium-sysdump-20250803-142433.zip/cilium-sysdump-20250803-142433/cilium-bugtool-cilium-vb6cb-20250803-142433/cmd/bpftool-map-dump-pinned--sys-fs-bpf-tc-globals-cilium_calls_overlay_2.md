key: 01 00 00 00  value: c1 1a 00 00
key: 07 00 00 00  value: bf 1a 00 00
key: 0f 00 00 00  value: bb 1a 00 00
key: 24 00 00 00  value: bd 1a 00 00
key: 26 00 00 00  value: be 1a 00 00
key: 2d 00 00 00  value: c2 1a 00 00
Found 6 elements
