 14:25:05 up 1 day,  2:25,  0 user,  load average: 0.08, 0.09, 0.09
