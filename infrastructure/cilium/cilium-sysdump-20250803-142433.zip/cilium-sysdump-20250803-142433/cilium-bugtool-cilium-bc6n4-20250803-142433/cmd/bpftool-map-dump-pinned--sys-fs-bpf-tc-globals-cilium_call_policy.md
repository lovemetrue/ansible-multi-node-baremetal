key: 21 00 00 00  value: 58 1c 00 00
key: 12 01 00 00  value: 75 1c 00 00
key: 56 01 00 00  value: 38 1c 00 00
key: 8e 01 00 00  value: 5f 1c 00 00
key: 16 0b 00 00  value: 64 1c 00 00
Found 5 elements
