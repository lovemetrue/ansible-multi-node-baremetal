39: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-02T11:51:54+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
40: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-02T11:51:54+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
44: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-02T11:51:54+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
49: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-02T11:51:54+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-02T11:51:54+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
59: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-02T11:51:54+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
64: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-02T11:51:54+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
69: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-02T11:51:54+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
70: cgroup_device  tag c692d192a4d1a516  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
71: cgroup_device  tag 8b9c33f36f812014  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 744B  jited 448B  memlock 4096B
72: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
73: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
74: cgroup_device  tag c692d192a4d1a516  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
75: cgroup_device  tag e3dbd137be8d6168  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 504B  jited 310B  memlock 4096B
76: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
77: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
78: cgroup_device  tag c692d192a4d1a516  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
79: cgroup_device  tag c692d192a4d1a516  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
80: cgroup_device  tag c692d192a4d1a516  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
81: cgroup_device  tag e3dbd137be8d6168  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 504B  jited 310B  memlock 4096B
82: cgroup_device  tag c692d192a4d1a516  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
83: cgroup_device  tag c692d192a4d1a516  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
84: cgroup_device  tag 28a890580b33b0dc  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 560B  jited 352B  memlock 4096B
85: cgroup_device  tag 0ecd07b7b633809f  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 496B  jited 308B  memlock 4096B
86: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
87: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
88: cgroup_device  tag c692d192a4d1a516  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
89: cgroup_device  tag c8b47a902f1cc68b  gpl
	loaded_at 2025-08-02T11:52:00+0000  uid 0
	xlated 464B  jited 289B  memlock 4096B
146: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-02T11:53:15+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
150: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-02T11:53:15+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
1464: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2025-08-03T02:05:27+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
1465: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2025-08-03T02:05:27+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
2882: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T11:54:23+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
2886: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T11:54:23+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
2887: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T11:54:23+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
2891: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T11:54:23+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
6533: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T13:49:41+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
6537: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T13:49:41+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
6566: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T13:50:11+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
6570: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T13:50:11+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
6776: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T13:50:28+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
6780: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T13:50:28+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
6824: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T14:08:59+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
6828: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T14:08:59+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
6829: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T14:08:59+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
6833: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T14:08:59+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
7049: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T14:09:29+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
7053: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T14:09:29+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
7054: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T14:09:30+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
7058: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T14:09:30+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
7064: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T14:11:43+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
7068: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T14:11:43+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
7069: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T14:21:58+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
7073: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T14:21:58+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
7102: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T14:22:04+0000  uid 0
	xlated 440B  jited 272B  memlock 4096B
7106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T14:22:04+0000  uid 0
	xlated 512B  jited 329B  memlock 4096B
7136: cgroup_sock_addr  name cil_sock4_sendmsg  tag 94c731766505c2e6  gpl
	loaded_at 2025-08-03T14:22:07+0000  uid 0
	xlated 5624B  jited 3095B  memlock 8192B  map_ids 39,1429,31,52,50,49,40,34,38
	btf_id 3154
7137: cgroup_sock_addr  name cil_sock6_recvmsg  tag 0af8cba440b61a64  gpl
	loaded_at 2025-08-03T14:22:07+0000  uid 0
	xlated 3488B  jited 1934B  memlock 4096B  map_ids 31,38,39,1429,34
	btf_id 3155
7138: cgroup_sock  name cil_sock_release  tag 6c18cd331b60cdea  gpl
	loaded_at 2025-08-03T14:22:07+0000  uid 0
	xlated 352B  jited 202B  memlock 4096B  map_ids 38,34
	btf_id 3156
7139: cgroup_sock_addr  name cil_sock4_getpeername  tag cb70e624af725bd6  gpl
	loaded_at 2025-08-03T14:22:07+0000  uid 0
	xlated 3232B  jited 1808B  memlock 4096B  map_ids 31,38,39,1429,34
	btf_id 3157
7140: cgroup_sock_addr  name cil_sock6_sendmsg  tag 3e531e933dd62632  gpl
	loaded_at 2025-08-03T14:22:07+0000  uid 0
	xlated 5920B  jited 3255B  memlock 8192B  map_ids 39,1429,31,52,50,49,40,34,38
	btf_id 3158
7141: cgroup_sock_addr  name cil_sock6_connect  tag 7d14ec854354c88d  gpl
	loaded_at 2025-08-03T14:22:07+0000  uid 0
	xlated 5960B  jited 3293B  memlock 8192B  map_ids 39,1429,31,52,50,49,40,34,38
	btf_id 3159
7142: cgroup_sock_addr  name cil_sock4_recvmsg  tag cb70e624af725bd6  gpl
	loaded_at 2025-08-03T14:22:07+0000  uid 0
	xlated 3232B  jited 1808B  memlock 4096B  map_ids 31,38,39,1429,34
	btf_id 3160
7143: cgroup_sock_addr  name cil_sock6_getpeername  tag 0af8cba440b61a64  gpl
	loaded_at 2025-08-03T14:22:07+0000  uid 0
	xlated 3488B  jited 1934B  memlock 4096B  map_ids 31,38,39,1429,34
	btf_id 3161
7144: cgroup_sock  name cil_sock6_post_bind  tag 213689ffdf41d15a  gpl
	loaded_at 2025-08-03T14:22:07+0000  uid 0
	xlated 1680B  jited 994B  memlock 4096B  map_ids 1429,39
	btf_id 3162
7145: cgroup_sock_addr  name cil_sock4_connect  tag b4d1f03c275f5b5f  gpl
	loaded_at 2025-08-03T14:22:07+0000  uid 0
	xlated 5672B  jited 3130B  memlock 8192B  map_ids 39,1429,31,52,50,49,40,34,38
	btf_id 3163
7146: cgroup_sock  name cil_sock4_post_bind  tag e18927aadbfcc32f  gpl
	loaded_at 2025-08-03T14:22:07+0000  uid 0
	xlated 1272B  jited 736B  memlock 4096B  map_ids 39,1429
	btf_id 3164
7147: sched_cls  name tail_handle_snat_fwd_ipv4  tag 0463b0453d458926  gpl
	loaded_at 2025-08-03T14:22:10+0000  uid 0
	xlated 12760B  jited 8498B  memlock 16384B  map_ids 1433,34,1434,48,31,46,44,45,30,1286
	btf_id 3166
7148: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 68431d31d0981562  gpl
	loaded_at 2025-08-03T14:22:10+0000  uid 0
	xlated 12544B  jited 7879B  memlock 16384B  map_ids 1433,48,34,46,44,45,1434,41,1429,31
	btf_id 3167
7149: sched_cls  name tail_handle_ipv4  tag f5a59e2613590b1e  gpl
	loaded_at 2025-08-03T14:22:10+0000  uid 0
	xlated 12232B  jited 7581B  memlock 16384B  map_ids 48,34,39,51,44,45,1434,1433,50,49,40,30,32,47,1429,42
	btf_id 3168
7150: sched_cls  name tail_drop_notify  tag 34144f7a29ebbeeb  gpl
	loaded_at 2025-08-03T14:22:10+0000  uid 0
	xlated 488B  jited 266B  memlock 4096B  map_ids 1433,31
	btf_id 3169
7151: sched_cls  name tail_no_service_ipv4  tag 568acc85674d4a23  gpl
	loaded_at 2025-08-03T14:22:10+0000  uid 0
	xlated 4888B  jited 2811B  memlock 8192B  map_ids 34,1434
	btf_id 3170
7152: sched_cls  name tail_nodeport_nat_egress_ipv4  tag a155624877908e37  gpl
	loaded_at 2025-08-03T14:22:10+0000  uid 0
	xlated 11512B  jited 7379B  memlock 12288B  map_ids 1433,1429,48,34,46,1286,30,31,1434
	btf_id 3171
7153: sched_cls  name cil_from_overlay  tag f1c8f8f9b4ee860f  gpl
	loaded_at 2025-08-03T14:22:10+0000  uid 0
	xlated 1096B  jited 725B  memlock 4096B  map_ids 1433,34,1434
	btf_id 3172
7154: sched_cls  name cil_to_overlay  tag 36537d5409e07eee  gpl
	loaded_at 2025-08-03T14:22:10+0000  uid 0
	xlated 4952B  jited 2945B  memlock 8192B  map_ids 1433,48,34,44,45,41,1434
	btf_id 3173
7193: sched_cls  name cil_to_host  tag 9ba01f5d812049d4  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 344B  jited 197B  memlock 4096B  map_ids 34
	btf_id 3230
7195: sched_cls  name tail_handle_snat_fwd_ipv4  tag b52e3dac71cc3362  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 1168B  jited 751B  memlock 16384B  map_ids 1457,34,1458,48,46,31,44,45,30,1286
	btf_id 3234
7196: sched_cls  name cil_from_host  tag c4dd7859434f8299  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 2488B  jited 1630B  memlock 4096B  map_ids 1457,34,1429,1458
	btf_id 3235
7203: sched_cls  name tail_nodeport_nat_egress_ipv4  tag 388dce088d659c3f  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 12008B  jited 7712B  memlock 12288B  map_ids 1457,1429,48,34,46,1286,30,31,1458
	btf_id 3236
7223: sched_cls  name tail_drop_notify  tag c28a85176191cd99  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 968B  jited 556B  memlock 4096B  map_ids 1457,31
	btf_id 3262
7224: sched_cls  name cil_host_policy  tag bcf7977d3b93787c  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 16B  jited 16B  memlock 4096B
	btf_id 3263
7226: sched_cls  name tail_handle_ipv4_from_host  tag 5505370a883fb1d1  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 4576B  jited 2655B  memlock 8192B  map_ids 1457,32,1429,34,31,1458,42
	btf_id 3264
7240: sched_cls  name tail_handle_ipv4_from_netdev  tag 5ecac7d478d5dca9  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 11328B  jited 7071B  memlock 12288B  map_ids 1457,48,34,39,51,44,45,1458,50,49,40,30,32,47
	btf_id 3266
7241: sched_cls  name tail_no_service_ipv4  tag 40e480f35731b6a4  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 4920B  jited 2829B  memlock 8192B  map_ids 1457,34,1458
	btf_id 3276
7242: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 417577d9698ff7a5  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 13032B  jited 8121B  memlock 16384B  map_ids 1457,48,34,46,44,45,1458,41,1429,31
	btf_id 3277
7245: sched_cls  name cil_from_container  tag 7806952dab6adb9b  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 816B  jited 575B  memlock 4096B  map_ids 1465,1464,34
	btf_id 3287
7246: sched_cls  name tail_drop_notify  tag e0a1ca3d87070fd9  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 544B  jited 299B  memlock 4096B  map_ids 1468,31
	btf_id 3288
7248: sched_cls  name tail_handle_snat_fwd_ipv4  tag b52e3dac71cc3362  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 1168B  jited 751B  memlock 16384B  map_ids 1461,34,1460,48,46,31,44,45,30,1286
	btf_id 3285
7249: sched_cls  name tail_ipv4_ct_ingress  tag 306a89ce00eec9cd  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 6672B  jited 4127B  memlock 8192B  map_ids 1472,34,1470,44,45,48,1474
	btf_id 3297
7250: sched_cls  name tail_nodeport_rev_dnat_ipv4  tag 793cf577341c5f87  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 6768B  jited 4125B  memlock 8192B  map_ids 1465,48,44,45,34,1464,41,1429,31
	btf_id 3291
7251: sched_cls  name tail_handle_arp  tag 068976a41f6d23e4  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 1440B  jited 901B  memlock 4096B  map_ids 1465,34,1464
	btf_id 3300
7252: sched_cls  name cil_lxc_policy_egress  tag bcf7977d3b93787c  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 16B  jited 16B  memlock 4096B
	btf_id 3301
7253: sched_cls  name tail_ipv4_ct_ingress  tag 306a89ce00eec9cd  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 6672B  jited 4127B  memlock 8192B  map_ids 1465,34,1464,44,45,48,1463
	btf_id 3302
7254: sched_cls  name tail_drop_notify  tag e0a1ca3d87070fd9  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 544B  jited 299B  memlock 4096B  map_ids 1465,31
	btf_id 3303
7255: sched_cls  name tail_ipv4_to_endpoint  tag 472b521a26d96ab1  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 9456B  jited 5557B  memlock 12288B  map_ids 1429,1465,34,1463,41,1435,1282,27,28,29,30,31,44,45,1464
	btf_id 3304
7256: sched_cls  name cil_lxc_policy  tag aaf48831833e84f3  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 15984B  jited 9805B  memlock 16384B  map_ids 1468,34,1467,44,45,48,1466,41,1406,1282,1429,27,28,29,30,31
	btf_id 3290
7257: sched_cls  name tail_handle_ipv4  tag 46a54185bc2a01c6  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 19416B  jited 11865B  memlock 20480B  map_ids 1471,34,1469,44,45,48,1473,1429,31,1333,1282,27,28,29,30,32,42
	btf_id 3298
7258: sched_cls  name tail_ipv4_to_endpoint  tag 472b521a26d96ab1  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 9456B  jited 5557B  memlock 12288B  map_ids 1429,1471,34,1473,41,1333,1282,27,28,29,30,31,44,45,1469
	btf_id 3307
7259: sched_cls  name tail_ipv4_ct_ingress  tag 306a89ce00eec9cd  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 6672B  jited 4127B  memlock 8192B  map_ids 1471,34,1469,44,45,48,1473
	btf_id 3308
7260: sched_cls  name tail_handle_arp  tag 068976a41f6d23e4  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 1440B  jited 901B  memlock 4096B  map_ids 1471,34,1469
	btf_id 3309
7261: sched_cls  name cil_lxc_policy_egress  tag bcf7977d3b93787c  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 16B  jited 16B  memlock 4096B
	btf_id 3310
7262: sched_cls  name tail_drop_notify  tag e0a1ca3d87070fd9  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 544B  jited 299B  memlock 4096B  map_ids 1471,31
	btf_id 3311
7263: sched_cls  name cil_lxc_policy  tag aaf48831833e84f3  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 15984B  jited 9805B  memlock 16384B  map_ids 1472,34,1470,44,45,48,1474,41,1294,1282,1429,27,28,29,30,31
	btf_id 3299
7264: sched_cls  name cil_from_container  tag 7806952dab6adb9b  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 816B  jited 575B  memlock 4096B  map_ids 1471,1469,34
	btf_id 3312
7267: sched_cls  name cil_lxc_policy_egress  tag bcf7977d3b93787c  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 16B  jited 16B  memlock 4096B
	btf_id 3315
7268: sched_cls  name cil_lxc_policy  tag aaf48831833e84f3  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 15984B  jited 9805B  memlock 16384B  map_ids 1465,34,1464,44,45,48,1463,41,1435,1282,1429,27,28,29,30,31
	btf_id 3305
7269: sched_cls  name tail_handle_ipv4  tag 46a54185bc2a01c6  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 19416B  jited 11865B  memlock 20480B  map_ids 1468,34,1467,44,45,48,1466,1429,31,1406,1282,27,28,29,30,32,42
	btf_id 3306
7271: sched_cls  name tail_nodeport_rev_dnat_ipv4  tag 793cf577341c5f87  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 6768B  jited 4125B  memlock 8192B  map_ids 1471,48,44,45,34,1469,41,1429,31
	btf_id 3316
7272: sched_cls  name tail_nodeport_rev_dnat_ipv4  tag 793cf577341c5f87  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 6768B  jited 4125B  memlock 8192B  map_ids 1468,48,44,45,34,1467,41,1429,31
	btf_id 3320
7273: sched_cls  name cil_from_container  tag 7806952dab6adb9b  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 816B  jited 575B  memlock 4096B  map_ids 1468,1467,34
	btf_id 3322
7274: sched_cls  name cil_lxc_policy_egress  tag bcf7977d3b93787c  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 16B  jited 16B  memlock 4096B
	btf_id 3323
7275: sched_cls  name tail_handle_ipv4_from_netdev  tag 5ecac7d478d5dca9  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 11328B  jited 7071B  memlock 12288B  map_ids 1461,48,34,39,51,44,45,1460,50,49,40,30,32,47
	btf_id 3292
7276: sched_cls  name tail_ipv4_to_endpoint  tag 472b521a26d96ab1  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 9456B  jited 5557B  memlock 12288B  map_ids 1429,1468,34,1466,41,1406,1282,27,28,29,30,31,44,45,1467
	btf_id 3324
7277: sched_cls  name tail_no_service_ipv4  tag 40e480f35731b6a4  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 4920B  jited 2829B  memlock 8192B  map_ids 1461,34,1460
	btf_id 3325
7278: sched_cls  name tail_handle_ipv4  tag 46a54185bc2a01c6  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 19416B  jited 11865B  memlock 20480B  map_ids 1472,34,1470,44,45,48,1474,1429,31,1294,1282,27,28,29,30,32,42
	btf_id 3317
7279: sched_cls  name tail_ipv4_ct_ingress  tag 306a89ce00eec9cd  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 6672B  jited 4127B  memlock 8192B  map_ids 1468,34,1467,44,45,48,1466
	btf_id 3326
7280: sched_cls  name tail_handle_arp  tag 068976a41f6d23e4  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 1440B  jited 901B  memlock 4096B  map_ids 1468,34,1467
	btf_id 3329
7281: sched_cls  name tail_handle_ipv4  tag 46a54185bc2a01c6  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 19416B  jited 11865B  memlock 20480B  map_ids 1465,34,1464,44,45,48,1463,1429,31,1435,1282,27,28,29,30,32,42
	btf_id 3318
7282: sched_cls  name tail_nodeport_rev_dnat_ipv4  tag 793cf577341c5f87  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 6768B  jited 4125B  memlock 8192B  map_ids 1472,48,44,45,34,1470,41,1429,31
	btf_id 3328
7283: sched_cls  name tail_handle_arp  tag 068976a41f6d23e4  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 1440B  jited 901B  memlock 4096B  map_ids 1472,34,1470
	btf_id 3330
7284: sched_cls  name cil_from_container  tag 7806952dab6adb9b  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 816B  jited 575B  memlock 4096B  map_ids 1472,1470,34
	btf_id 3331
7285: sched_cls  name cil_lxc_policy  tag aaf48831833e84f3  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 15984B  jited 9805B  memlock 16384B  map_ids 1471,34,1469,44,45,48,1473,41,1333,1282,1429,27,28,29,30,31
	btf_id 3321
7286: sched_cls  name tail_drop_notify  tag e0a1ca3d87070fd9  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 544B  jited 299B  memlock 4096B  map_ids 1472,31
	btf_id 3332
7288: sched_cls  name cil_to_host  tag 9ba01f5d812049d4  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 344B  jited 197B  memlock 4096B  map_ids 34
	btf_id 3334
7289: sched_cls  name tail_handle_ipv4_from_host  tag 5505370a883fb1d1  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 4576B  jited 2655B  memlock 8192B  map_ids 1461,32,1429,34,31,1460,42
	btf_id 3335
7290: sched_cls  name tail_ipv4_to_endpoint  tag 472b521a26d96ab1  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 9456B  jited 5557B  memlock 12288B  map_ids 1429,1472,34,1474,41,1294,1282,27,28,29,30,31,44,45,1470
	btf_id 3333
7292: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 417577d9698ff7a5  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 13032B  jited 8121B  memlock 16384B  map_ids 1461,48,34,46,44,45,1460,41,1429,31
	btf_id 3337
7293: sched_cls  name tail_nodeport_nat_egress_ipv4  tag 388dce088d659c3f  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 12008B  jited 7712B  memlock 12288B  map_ids 1461,1429,48,34,46,1286,30,31,1460
	btf_id 3338
7294: sched_cls  name tail_drop_notify  tag c28a85176191cd99  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 968B  jited 556B  memlock 4096B  map_ids 1461,31
	btf_id 3339
7296: sched_cls  name tail_handle_snat_fwd_ipv4  tag b52e3dac71cc3362  gpl
	loaded_at 2025-08-03T14:22:13+0000  uid 0
	xlated 13032B  jited 8727B  memlock 16384B  map_ids 1475,34,1476,48,46,31,44,45,30,1286
	btf_id 3343
7297: sched_cls  name tail_no_service_ipv4  tag 40e480f35731b6a4  gpl
	loaded_at 2025-08-03T14:22:14+0000  uid 0
	xlated 4920B  jited 2829B  memlock 8192B  map_ids 1475,34,1476
	btf_id 3344
7298: sched_cls  name tail_nodeport_nat_egress_ipv4  tag 388dce088d659c3f  gpl
	loaded_at 2025-08-03T14:22:14+0000  uid 0
	xlated 12008B  jited 7712B  memlock 12288B  map_ids 1475,1429,48,34,46,1286,30,31,1476
	btf_id 3345
7300: sched_cls  name tail_handle_ipv4_from_host  tag 5505370a883fb1d1  gpl
	loaded_at 2025-08-03T14:22:14+0000  uid 0
	xlated 4576B  jited 2655B  memlock 8192B  map_ids 1475,32,1429,34,31,1476,42
	btf_id 3347
7301: sched_cls  name cil_from_netdev  tag eed8d56b13232c39  gpl
	loaded_at 2025-08-03T14:22:14+0000  uid 0
	xlated 2352B  jited 1580B  memlock 4096B  map_ids 1475,34,1476,1429
	btf_id 3348
7302: sched_cls  name tail_handle_ipv4_from_netdev  tag 5ecac7d478d5dca9  gpl
	loaded_at 2025-08-03T14:22:14+0000  uid 0
	xlated 11328B  jited 7071B  memlock 12288B  map_ids 1475,48,34,39,51,44,45,1476,50,49,40,30,32,47
	btf_id 3349
7304: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 417577d9698ff7a5  gpl
	loaded_at 2025-08-03T14:22:14+0000  uid 0
	xlated 13032B  jited 8121B  memlock 16384B  map_ids 1475,48,34,46,44,45,1476,41,1429,31
	btf_id 3351
7305: sched_cls  name cil_to_netdev  tag d99bedb1d2d52658  gpl
	loaded_at 2025-08-03T14:22:14+0000  uid 0
	xlated 7088B  jited 4369B  memlock 8192B  map_ids 1475,48,34,44,45,41,31,1476
	btf_id 3352
7306: sched_cls  name tail_drop_notify  tag c28a85176191cd99  gpl
	loaded_at 2025-08-03T14:22:14+0000  uid 0
	xlated 968B  jited 556B  memlock 4096B  map_ids 1475,31
	btf_id 3353
