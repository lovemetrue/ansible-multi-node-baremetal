{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.1.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2025-08-03T14:22:15.660Z",
  "value": "id=482   sec_id=24121 flags=0x0000 ifindex=92  mac=22:B2:68:CA:D6:E9 nodemac=0A:F4:F4:A7:F1:CC parent_ifindex=0  "
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.1.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2025-08-03T14:22:15.794Z",
  "value": "id=3911  sec_id=4     flags=0x0000 ifindex=94  mac=DE:CE:89:E9:CD:5E nodemac=52:BE:14:18:05:34 parent_ifindex=0  "
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.1.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2025-08-03T14:22:15.794Z",
  "value": "id=482   sec_id=24121 flags=0x0000 ifindex=92  mac=22:B2:68:CA:D6:E9 nodemac=0A:F4:F4:A7:F1:CC parent_ifindex=0  "
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.1.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2025-08-03T14:22:15.795Z",
  "value": "id=1178  sec_id=2284  flags=0x0000 ifindex=88  mac=66:0E:21:74:33:51 nodemac=FA:54:30:02:7F:19 parent_ifindex=0  "
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.1.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2025-08-03T14:22:15.795Z",
  "value": "id=3132  sec_id=45704 flags=0x0000 ifindex=66  mac=7E:95:3F:3C:C8:59 nodemac=7E:D0:45:7E:3F:C1 parent_ifindex=0  "
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.1.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2025-08-03T14:22:15.918Z",
  "value": "id=3132  sec_id=45704 flags=0x0000 ifindex=66  mac=7E:95:3F:3C:C8:59 nodemac=7E:D0:45:7E:3F:C1 parent_ifindex=0  "
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.1.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2025-08-03T14:22:15.918Z",
  "value": "id=1178  sec_id=2284  flags=0x0000 ifindex=88  mac=66:0E:21:74:33:51 nodemac=FA:54:30:02:7F:19 parent_ifindex=0  "
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.1.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2025-08-03T14:22:15.919Z",
  "value": "id=3911  sec_id=4     flags=0x0000 ifindex=94  mac=DE:CE:89:E9:CD:5E nodemac=52:BE:14:18:05:34 parent_ifindex=0  "
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.1.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2025-08-03T14:24:05.383Z",
  "value": "id=482   sec_id=24121 flags=0x0000 ifindex=92  mac=22:B2:68:CA:D6:E9 nodemac=0A:F4:F4:A7:F1:CC parent_ifindex=0  "
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.1.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2025-08-03T14:24:05.384Z",
  "value": "id=3132  sec_id=45704 flags=0x0000 ifindex=66  mac=7E:95:3F:3C:C8:59 nodemac=7E:D0:45:7E:3F:C1 parent_ifindex=0  "
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.1.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2025-08-03T14:24:05.384Z",
  "value": "id=3911  sec_id=4     flags=0x0000 ifindex=94  mac=DE:CE:89:E9:CD:5E nodemac=52:BE:14:18:05:34 parent_ifindex=0  "
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.1.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2025-08-03T14:24:05.384Z",
  "value": "id=1178  sec_id=2284  flags=0x0000 ifindex=88  mac=66:0E:21:74:33:51 nodemac=FA:54:30:02:7F:19 parent_ifindex=0  "
}

