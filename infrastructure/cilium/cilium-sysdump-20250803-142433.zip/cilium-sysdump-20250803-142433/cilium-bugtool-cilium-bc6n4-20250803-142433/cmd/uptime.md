 14:25:05 up 1 day,  2:35,  0 user,  load average: 0.30, 0.27, 0.27
