IP ADDRESS         LOCAL ENDPOINT INFO
10.0.0.203:0       id=2838  sec_id=4     flags=0x0000 ifindex=96  mac=86:21:73:08:46:3D nodemac=46:47:25:FA:18:58 parent_ifindex=0     
91.217.196.189:0   (localhost)                                                                                                         
10.0.0.43:0        id=274   sec_id=17157 flags=0x0000 ifindex=90  mac=6E:26:C7:E0:F6:95 nodemac=12:59:28:A0:89:94 parent_ifindex=0     
10.0.0.124:0       (localhost)                                                                                                         
10.0.0.220:0       id=33    sec_id=24121 flags=0x0000 ifindex=94  mac=86:28:9E:26:0F:A5 nodemac=52:B7:D0:6A:AC:BD parent_ifindex=0     
10.0.0.236:0       id=398   sec_id=64642 flags=0x0000 ifindex=68  mac=3A:C3:97:18:BE:FC nodemac=CA:E6:42:DE:E8:18 parent_ifindex=0     
