Name            IPv4 Address     Endpoint CIDR   IPv6 Address   Endpoint CIDR   Source
k8s-master-n1   91.217.196.189   10.0.0.0/24                                    local
k8s-worker-n1   91.217.196.183   10.0.1.0/24                                    custom-resource
