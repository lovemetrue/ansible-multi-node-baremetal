2025-08-02T11:59:45,841466+00:00 Linux version 5.15.0-151-generic (buildd@lcy02-amd64-092) (gcc (Ubuntu 11.4.0-1ubuntu1~22.04) 11.4.0, GNU ld (GNU Binutils for Ubuntu) 2.38) #161-Ubuntu SMP Tue Jul 22 14:25:40 UTC 2025 (Ubuntu 5.15.0-151.161-generic 5.15.184)
2025-08-02T11:59:45,841466+00:00 Command line: BOOT_IMAGE=/boot/vmlinuz-5.15.0-151-generic root=UUID=79806a87-a8ae-4e6d-9c8c-9458e92773db ro
2025-08-02T11:59:45,841466+00:00 KERNEL supported cpus:
2025-08-02T11:59:45,841466+00:00   Intel GenuineIntel
2025-08-02T11:59:45,841466+00:00   AMD AuthenticAMD
2025-08-02T11:59:45,841466+00:00   Hygon HygonGenuine
2025-08-02T11:59:45,841466+00:00   Centaur CentaurHauls
2025-08-02T11:59:45,841466+00:00   zhaoxin   Shanghai  
2025-08-02T11:59:45,841466+00:00 BIOS-provided physical RAM map:
2025-08-02T11:59:45,841466+00:00 BIOS-e820: [mem 0x0000000000000000-0x000000000009fbff] usable
2025-08-02T11:59:45,841466+00:00 BIOS-e820: [mem 0x000000000009fc00-0x000000000009ffff] reserved
2025-08-02T11:59:45,841466+00:00 BIOS-e820: [mem 0x00000000000f0000-0x00000000000fffff] reserved
2025-08-02T11:59:45,841466+00:00 BIOS-e820: [mem 0x0000000000100000-0x00000000bffd9fff] usable
2025-08-02T11:59:45,841466+00:00 BIOS-e820: [mem 0x00000000bffda000-0x00000000bfffffff] reserved
2025-08-02T11:59:45,841466+00:00 BIOS-e820: [mem 0x00000000feffc000-0x00000000feffffff] reserved
2025-08-02T11:59:45,841466+00:00 BIOS-e820: [mem 0x00000000fffc0000-0x00000000ffffffff] reserved
2025-08-02T11:59:45,841466+00:00 BIOS-e820: [mem 0x0000000100000000-0x000000043fffffff] usable
2025-08-02T11:59:45,841466+00:00 NX (Execute Disable) protection: active
2025-08-02T11:59:45,841466+00:00 SMBIOS 2.8 present.
2025-08-02T11:59:45,841466+00:00 DMI: QEMU Standard PC (i440FX + PIIX, 1996), BIOS rel-1.16.3-0-ga6ed6b701f0a-prebuilt.qemu.org 04/01/2014
2025-08-02T11:59:45,841466+00:00 Hypervisor detected: KVM
2025-08-02T11:59:45,841466+00:00 kvm-clock: Using msrs 4b564d01 and 4b564d00
2025-08-02T11:59:45,841466+00:00 kvm-clock: cpu 0, msr 2a5401001, primary cpu clock
2025-08-02T11:59:45,841470+00:00 kvm-clock: using sched offset of 3632277175696933 cycles
2025-08-02T11:59:45,841475+00:00 clocksource: kvm-clock: mask: 0xffffffffffffffff max_cycles: 0x1cd42e4dffb, max_idle_ns: 881590591483 ns
2025-08-02T11:59:45,841483+00:00 tsc: Detected 2899.998 MHz processor
2025-08-02T11:59:45,843246+00:00 e820: update [mem 0x00000000-0x00000fff] usable ==> reserved
2025-08-02T11:59:45,843257+00:00 e820: remove [mem 0x000a0000-0x000fffff] usable
2025-08-02T11:59:45,843267+00:00 last_pfn = 0x440000 max_arch_pfn = 0x400000000
2025-08-02T11:59:45,843345+00:00 x86/PAT: Configuration [0-7]: WB  WC  UC- UC  WB  WP  UC- WT  
2025-08-02T11:59:45,843368+00:00 last_pfn = 0xbffda max_arch_pfn = 0x400000000
2025-08-02T11:59:45,856021+00:00 found SMP MP-table at [mem 0x000f5430-0x000f543f]
2025-08-02T11:59:45,856089+00:00 Using GB pages for direct mapping
2025-08-02T11:59:45,856370+00:00 RAMDISK: [mem 0x2b51b000-0x31a84fff]
2025-08-02T11:59:45,856385+00:00 ACPI: Early table checksum verification disabled
2025-08-02T11:59:45,856395+00:00 ACPI: RSDP 0x00000000000F51F0 000014 (v00 BOCHS )
2025-08-02T11:59:45,856406+00:00 ACPI: RSDT 0x00000000BFFE3ECD 000038 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2025-08-02T11:59:45,856420+00:00 ACPI: FACP 0x00000000BFFE3C6F 000074 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2025-08-02T11:59:45,856455+00:00 ACPI: DSDT 0x00000000BFFDF040 004C2F (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2025-08-02T11:59:45,856467+00:00 ACPI: FACS 0x00000000BFFDF000 000040
2025-08-02T11:59:45,856476+00:00 ACPI: APIC 0x00000000BFFE3CE3 0000C0 (v03 BOCHS  BXPC     00000001 BXPC 00000001)
2025-08-02T11:59:45,856485+00:00 ACPI: SSDT 0x00000000BFFE3DA3 0000CA (v01 BOCHS  VMGENID  00000001 BXPC 00000001)
2025-08-02T11:59:45,856494+00:00 ACPI: HPET 0x00000000BFFE3E6D 000038 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2025-08-02T11:59:45,856504+00:00 ACPI: WAET 0x00000000BFFE3EA5 000028 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2025-08-02T11:59:45,856512+00:00 ACPI: Reserving FACP table memory at [mem 0xbffe3c6f-0xbffe3ce2]
2025-08-02T11:59:45,856517+00:00 ACPI: Reserving DSDT table memory at [mem 0xbffdf040-0xbffe3c6e]
2025-08-02T11:59:45,856520+00:00 ACPI: Reserving FACS table memory at [mem 0xbffdf000-0xbffdf03f]
2025-08-02T11:59:45,856522+00:00 ACPI: Reserving APIC table memory at [mem 0xbffe3ce3-0xbffe3da2]
2025-08-02T11:59:45,856525+00:00 ACPI: Reserving SSDT table memory at [mem 0xbffe3da3-0xbffe3e6c]
2025-08-02T11:59:45,856527+00:00 ACPI: Reserving HPET table memory at [mem 0xbffe3e6d-0xbffe3ea4]
2025-08-02T11:59:45,856530+00:00 ACPI: Reserving WAET table memory at [mem 0xbffe3ea5-0xbffe3ecc]
2025-08-02T11:59:45,857252+00:00 No NUMA configuration found
2025-08-02T11:59:45,857257+00:00 Faking a node at [mem 0x0000000000000000-0x000000043fffffff]
2025-08-02T11:59:45,857272+00:00 NODE_DATA(0) allocated [mem 0x43ffd6000-0x43fffffff]
2025-08-02T11:59:45,858004+00:00 Zone ranges:
2025-08-02T11:59:45,858008+00:00   DMA      [mem 0x0000000000001000-0x0000000000ffffff]
2025-08-02T11:59:45,858013+00:00   DMA32    [mem 0x0000000001000000-0x00000000ffffffff]
2025-08-02T11:59:45,858017+00:00   Normal   [mem 0x0000000100000000-0x000000043fffffff]
2025-08-02T11:59:45,858021+00:00   Device   empty
2025-08-02T11:59:45,858024+00:00 Movable zone start for each node
2025-08-02T11:59:45,858028+00:00 Early memory node ranges
2025-08-02T11:59:45,858030+00:00   node   0: [mem 0x0000000000001000-0x000000000009efff]
2025-08-02T11:59:45,858033+00:00   node   0: [mem 0x0000000000100000-0x00000000bffd9fff]
2025-08-02T11:59:45,858037+00:00   node   0: [mem 0x0000000100000000-0x000000043fffffff]
2025-08-02T11:59:45,858043+00:00 Initmem setup node 0 [mem 0x0000000000001000-0x000000043fffffff]
2025-08-02T11:59:45,858065+00:00 On node 0, zone DMA: 1 pages in unavailable ranges
2025-08-02T11:59:45,858169+00:00 On node 0, zone DMA: 97 pages in unavailable ranges
2025-08-02T11:59:45,945806+00:00 On node 0, zone Normal: 38 pages in unavailable ranges
2025-08-02T11:59:45,947569+00:00 ACPI: PM-Timer IO Port: 0x608
2025-08-02T11:59:45,947602+00:00 ACPI: LAPIC_NMI (acpi_id[0xff] dfl dfl lint[0x1])
2025-08-02T11:59:45,947672+00:00 IOAPIC[0]: apic_id 0, version 17, address 0xfec00000, GSI 0-23
2025-08-02T11:59:45,947679+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 0 global_irq 2 dfl dfl)
2025-08-02T11:59:45,947682+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 5 global_irq 5 high level)
2025-08-02T11:59:45,947684+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 9 global_irq 9 high level)
2025-08-02T11:59:45,947686+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 10 global_irq 10 high level)
2025-08-02T11:59:45,947688+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 11 global_irq 11 high level)
2025-08-02T11:59:45,947694+00:00 ACPI: Using ACPI (MADT) for SMP configuration information
2025-08-02T11:59:45,947696+00:00 ACPI: HPET id: 0x8086a201 base: 0xfed00000
2025-08-02T11:59:45,947704+00:00 TSC deadline timer available
2025-08-02T11:59:45,947716+00:00 smpboot: Allowing 10 CPUs, 0 hotplug CPUs
2025-08-02T11:59:45,947747+00:00 kvm-guest: KVM setup pv remote TLB flush
2025-08-02T11:59:45,947752+00:00 kvm-guest: setup PV sched yield
2025-08-02T11:59:45,947770+00:00 PM: hibernation: Registered nosave memory: [mem 0x00000000-0x00000fff]
2025-08-02T11:59:45,947773+00:00 PM: hibernation: Registered nosave memory: [mem 0x0009f000-0x000fffff]
2025-08-02T11:59:45,947775+00:00 PM: hibernation: Registered nosave memory: [mem 0xbffda000-0xffffffff]
2025-08-02T11:59:45,947777+00:00 [mem 0xc0000000-0xfeffbfff] available for PCI devices
2025-08-02T11:59:45,947779+00:00 Booting paravirtualized kernel on KVM
2025-08-02T11:59:45,947784+00:00 clocksource: refined-jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 7645519600211568 ns
2025-08-02T11:59:45,947795+00:00 setup_percpu: NR_CPUS:8192 nr_cpumask_bits:10 nr_cpu_ids:10 nr_node_ids:1
2025-08-02T11:59:45,953517+00:00 percpu: Embedded 62 pages/cpu s217088 r8192 d28672 u524288
2025-08-02T11:59:45,953545+00:00 pcpu-alloc: s217088 r8192 d28672 u524288 alloc=1*2097152
2025-08-02T11:59:45,953550+00:00 pcpu-alloc: [0] 00 01 02 03 [0] 04 05 06 07 
2025-08-02T11:59:45,953562+00:00 pcpu-alloc: [0] 08 09 -- -- 
2025-08-02T11:59:45,953629+00:00 kvm-guest: setup async PF for cpu 0
2025-08-02T11:59:45,953641+00:00 kvm-guest: stealtime: cpu 0, msr 42f834080
2025-08-02T11:59:45,953651+00:00 kvm-guest: PV spinlocks enabled
2025-08-02T11:59:45,953657+00:00 PV qspinlock hash table entries: 256 (order: 0, 4096 bytes, linear)
2025-08-02T11:59:45,953684+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 4128474
2025-08-02T11:59:45,953688+00:00 Policy zone: Normal
2025-08-02T11:59:45,953690+00:00 Kernel command line: BOOT_IMAGE=/boot/vmlinuz-5.15.0-151-generic root=UUID=79806a87-a8ae-4e6d-9c8c-9458e92773db ro
2025-08-02T11:59:45,953771+00:00 Unknown kernel command line parameters "BOOT_IMAGE=/boot/vmlinuz-5.15.0-151-generic", will be passed to user space.
2025-08-02T11:59:45,956462+00:00 Dentry cache hash table entries: 2097152 (order: 12, 16777216 bytes, linear)
2025-08-02T11:59:45,961091+00:00 Inode-cache hash table entries: 1048576 (order: 11, 8388608 bytes, linear)
2025-08-02T11:59:45,961589+00:00 mem auto-init: stack:off, heap alloc:on, heap free:off
2025-08-02T11:59:46,051056+00:00 Memory: 16258712K/16776672K available (16393K kernel code, 4398K rwdata, 10988K rodata, 3284K init, 18780K bss, 517700K reserved, 0K cma-reserved)
2025-08-02T11:59:46,051479+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=10, Nodes=1
2025-08-02T11:59:46,051513+00:00 Kernel/User page tables isolation: enabled
2025-08-02T11:59:46,051609+00:00 ftrace: allocating 50849 entries in 199 pages
2025-08-02T11:59:46,078588+00:00 ftrace: allocated 199 pages with 5 groups
2025-08-02T11:59:46,079013+00:00 rcu: Hierarchical RCU implementation.
2025-08-02T11:59:46,079016+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=8192 to nr_cpu_ids=10.
2025-08-02T11:59:46,079019+00:00 	Rude variant of Tasks RCU enabled.
2025-08-02T11:59:46,079020+00:00 	Tracing variant of Tasks RCU enabled.
2025-08-02T11:59:46,079021+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 25 jiffies.
2025-08-02T11:59:46,079023+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=10
2025-08-02T11:59:46,084960+00:00 NR_IRQS: 524544, nr_irqs: 504, preallocated irqs: 16
2025-08-02T11:59:46,085322+00:00 Console: colour dummy device 80x25
2025-08-02T11:59:46,085486+00:00 printk: console [tty0] enabled
2025-08-02T11:59:46,085537+00:00 ACPI: Core revision 20210730
2025-08-02T11:59:46,085943+00:00 clocksource: hpet: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 19112604467 ns
2025-08-02T11:59:46,086194+00:00 APIC: Switch to symmetric I/O mode setup
2025-08-02T11:59:46,086719+00:00 x2apic enabled
2025-08-02T11:59:46,087298+00:00 Switched APIC routing to physical x2apic.
2025-08-02T11:59:46,087310+00:00 kvm-guest: setup PV IPIs
2025-08-02T11:59:46,089603+00:00 ..TIMER: vector=0x30 apic1=0 pin1=2 apic2=-1 pin2=-1
2025-08-02T11:59:46,089663+00:00 clocksource: tsc-early: mask: 0xffffffffffffffff max_cycles: 0x29cd4133323, max_idle_ns: 440795296220 ns
2025-08-02T11:59:46,089683+00:00 Calibrating delay loop (skipped) preset value.. 5799.99 BogoMIPS (lpj=11599992)
2025-08-02T11:59:46,089786+00:00 x86/cpu: User Mode Instruction Prevention (UMIP) activated
2025-08-02T11:59:46,089905+00:00 Last level iTLB entries: 4KB 0, 2MB 0, 4MB 0
2025-08-02T11:59:46,089914+00:00 Last level dTLB entries: 4KB 0, 2MB 0, 4MB 0, 1GB 0
2025-08-02T11:59:46,089932+00:00 Spectre V1 : Mitigation: usercopy/swapgs barriers and __user pointer sanitization
2025-08-02T11:59:46,089941+00:00 Spectre V2 : Mitigation: Retpolines
2025-08-02T11:59:46,089946+00:00 Spectre V2 : Spectre v2 / SpectreRSB: Filling RSB on context switch and VMEXIT
2025-08-02T11:59:46,089953+00:00 Spectre V2 : Enabling Restricted Speculation for firmware calls
2025-08-02T11:59:46,089960+00:00 Spectre V2 : mitigation: Enabling conditional Indirect Branch Prediction Barrier
2025-08-02T11:59:46,089966+00:00 Speculative Store Bypass: Mitigation: Speculative Store Bypass disabled via prctl and seccomp
2025-08-02T11:59:46,089973+00:00 MDS: Mitigation: Clear CPU buffers
2025-08-02T11:59:46,089977+00:00 MMIO Stale Data: Unknown: No mitigations
2025-08-02T11:59:46,089981+00:00 ITS: Mitigation: Aligned branch/return thunks
2025-08-02T11:59:46,090027+00:00 x86/fpu: Supporting XSAVE feature 0x001: 'x87 floating point registers'
2025-08-02T11:59:46,090034+00:00 x86/fpu: Supporting XSAVE feature 0x002: 'SSE registers'
2025-08-02T11:59:46,090037+00:00 x86/fpu: Supporting XSAVE feature 0x004: 'AVX registers'
2025-08-02T11:59:46,090042+00:00 x86/fpu: xstate_offset[2]:  576, xstate_sizes[2]:  256
2025-08-02T11:59:46,090045+00:00 x86/fpu: Enabled xstate features 0x7, context size is 832 bytes, using 'standard' format.
2025-08-02T11:59:46,120954+00:00 Freeing SMP alternatives memory: 44K
2025-08-02T11:59:46,120971+00:00 pid_max: default: 32768 minimum: 301
2025-08-02T11:59:46,121075+00:00 LSM: Security Framework initializing
2025-08-02T11:59:46,121110+00:00 landlock: Up and running.
2025-08-02T11:59:46,121115+00:00 Yama: becoming mindful.
2025-08-02T11:59:46,121203+00:00 AppArmor: AppArmor initialized
2025-08-02T11:59:46,121472+00:00 Mount-cache hash table entries: 32768 (order: 6, 262144 bytes, linear)
2025-08-02T11:59:46,121754+00:00 Mountpoint-cache hash table entries: 32768 (order: 6, 262144 bytes, linear)
2025-08-02T11:59:46,122715+00:00 smpboot: CPU0: Intel(R) Xeon(R) CPU E5-2690 0 @ 2.90GHz (family: 0x6, model: 0x2d, stepping: 0x7)
2025-08-02T11:59:46,123291+00:00 Performance Events: SandyBridge events, full-width counters, Intel PMU driver.
2025-08-02T11:59:46,123342+00:00 ... version:                2
2025-08-02T11:59:46,123345+00:00 ... bit width:              48
2025-08-02T11:59:46,123347+00:00 ... generic registers:      4
2025-08-02T11:59:46,123348+00:00 ... value mask:             0000ffffffffffff
2025-08-02T11:59:46,123351+00:00 ... max period:             00007fffffffffff
2025-08-02T11:59:46,123353+00:00 ... fixed-purpose events:   3
2025-08-02T11:59:46,123355+00:00 ... event mask:             000000070000000f
2025-08-02T11:59:46,123597+00:00 signal: max sigframe size: 1776
2025-08-02T11:59:46,123661+00:00 rcu: Hierarchical SRCU implementation.
2025-08-02T11:59:46,125079+00:00 smp: Bringing up secondary CPUs ...
2025-08-02T11:59:46,125473+00:00 x86: Booting SMP configuration:
2025-08-02T11:59:46,125479+00:00 .... node  #0, CPUs:        #1
2025-08-02T11:59:45,845900+00:00 kvm-clock: cpu 1, msr 2a5401041, secondary cpu clock
2025-08-02T11:59:46,125673+00:00 kvm-guest: setup async PF for cpu 1
2025-08-02T11:59:46,125673+00:00 kvm-guest: stealtime: cpu 1, msr 42f8b4080
2025-08-02T11:59:46,125762+00:00   #2
2025-08-02T11:59:45,845900+00:00 kvm-clock: cpu 2, msr 2a5401081, secondary cpu clock
2025-08-02T11:59:46,126210+00:00 kvm-guest: setup async PF for cpu 2
2025-08-02T11:59:46,126210+00:00 kvm-guest: stealtime: cpu 2, msr 42f934080
2025-08-02T11:59:46,126210+00:00   #3
2025-08-02T11:59:45,845900+00:00 kvm-clock: cpu 3, msr 2a54010c1, secondary cpu clock
2025-08-02T11:59:46,126736+00:00 kvm-guest: setup async PF for cpu 3
2025-08-02T11:59:46,126736+00:00 kvm-guest: stealtime: cpu 3, msr 42f9b4080
2025-08-02T11:59:46,126736+00:00   #4
2025-08-02T11:59:45,845900+00:00 kvm-clock: cpu 4, msr 2a5401101, secondary cpu clock
2025-08-02T11:59:46,126859+00:00 kvm-guest: setup async PF for cpu 4
2025-08-02T11:59:46,126859+00:00 kvm-guest: stealtime: cpu 4, msr 42fa34080
2025-08-02T11:59:46,126859+00:00   #5
2025-08-02T11:59:45,845900+00:00 kvm-clock: cpu 5, msr 2a5401141, secondary cpu clock
2025-08-02T11:59:45,845900+00:00 smpboot: CPU 5 Converting physical 0 to logical die 1
2025-08-02T11:59:46,133734+00:00 kvm-guest: setup async PF for cpu 5
2025-08-02T11:59:46,133748+00:00 kvm-guest: stealtime: cpu 5, msr 42fab4080
2025-08-02T11:59:46,134326+00:00   #6
2025-08-02T11:59:45,845900+00:00 kvm-clock: cpu 6, msr 2a5401181, secondary cpu clock
2025-08-02T11:59:46,134952+00:00 kvm-guest: setup async PF for cpu 6
2025-08-02T11:59:46,134952+00:00 kvm-guest: stealtime: cpu 6, msr 42fb34080
2025-08-02T11:59:46,134952+00:00   #7
2025-08-02T11:59:45,845900+00:00 kvm-clock: cpu 7, msr 2a54011c1, secondary cpu clock
2025-08-02T11:59:46,134952+00:00 kvm-guest: setup async PF for cpu 7
2025-08-02T11:59:46,134952+00:00 kvm-guest: stealtime: cpu 7, msr 42fbb4080
2025-08-02T11:59:46,134952+00:00   #8
2025-08-02T11:59:45,845900+00:00 kvm-clock: cpu 8, msr 2a5401201, secondary cpu clock
2025-08-02T11:59:46,134952+00:00 kvm-guest: setup async PF for cpu 8
2025-08-02T11:59:46,134952+00:00 kvm-guest: stealtime: cpu 8, msr 42fc34080
2025-08-02T11:59:46,137790+00:00   #9
2025-08-02T11:59:45,845900+00:00 kvm-clock: cpu 9, msr 2a5401241, secondary cpu clock
2025-08-02T11:59:46,138288+00:00 kvm-guest: setup async PF for cpu 9
2025-08-02T11:59:46,138288+00:00 kvm-guest: stealtime: cpu 9, msr 42fcb4080
2025-08-02T11:59:46,138288+00:00 smp: Brought up 1 node, 10 CPUs
2025-08-02T11:59:46,138288+00:00 smpboot: Max logical packages: 2
2025-08-02T11:59:46,138288+00:00 smpboot: Total of 10 processors activated (57999.96 BogoMIPS)
2025-08-02T11:59:46,139610+00:00 devtmpfs: initialized
2025-08-02T11:59:46,141765+00:00 x86/mm: Memory block size: 128MB
2025-08-02T11:59:46,144279+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 7645041785100000 ns
2025-08-02T11:59:46,144279+00:00 futex hash table entries: 4096 (order: 6, 262144 bytes, linear)
2025-08-02T11:59:46,144279+00:00 pinctrl core: initialized pinctrl subsystem
2025-08-02T11:59:46,144279+00:00 PM: RTC time: 11:59:46, date: 2025-08-02
2025-08-02T11:59:46,146218+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2025-08-02T11:59:46,148198+00:00 DMA: preallocated 2048 KiB GFP_KERNEL pool for atomic allocations
2025-08-02T11:59:46,148662+00:00 DMA: preallocated 2048 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2025-08-02T11:59:46,149092+00:00 DMA: preallocated 2048 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2025-08-02T11:59:46,149123+00:00 audit: initializing netlink subsys (disabled)
2025-08-02T11:59:46,149173+00:00 audit: type=2000 audit(1754135986.378:1): state=initialized audit_enabled=0 res=1
2025-08-02T11:59:46,149886+00:00 thermal_sys: Registered thermal governor 'fair_share'
2025-08-02T11:59:46,149888+00:00 thermal_sys: Registered thermal governor 'bang_bang'
2025-08-02T11:59:46,149892+00:00 thermal_sys: Registered thermal governor 'step_wise'
2025-08-02T11:59:46,149895+00:00 thermal_sys: Registered thermal governor 'user_space'
2025-08-02T11:59:46,149897+00:00 thermal_sys: Registered thermal governor 'power_allocator'
2025-08-02T11:59:46,149921+00:00 cpuidle: using governor ladder
2025-08-02T11:59:46,149929+00:00 cpuidle: using governor menu
2025-08-02T11:59:46,150221+00:00 ACPI: bus type PCI registered
2025-08-02T11:59:46,150229+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2025-08-02T11:59:46,150564+00:00 PCI: Using configuration type 1 for base access
2025-08-02T11:59:46,150604+00:00 core: PMU erratum BJ122, BV98, HSD29 workaround disabled, HT off
2025-08-02T11:59:46,154522+00:00 kprobes: kprobe jump-optimization is enabled. All kprobes are optimized if possible.
2025-08-02T11:59:46,154553+00:00 HugeTLB registered 1.00 GiB page size, pre-allocated 0 pages
2025-08-02T11:59:46,154553+00:00 HugeTLB registered 2.00 MiB page size, pre-allocated 0 pages
2025-08-02T11:59:46,169944+00:00 fbcon: Taking over console
2025-08-02T11:59:46,170002+00:00 ACPI: Added _OSI(Module Device)
2025-08-02T11:59:46,170009+00:00 ACPI: Added _OSI(Processor Device)
2025-08-02T11:59:46,170013+00:00 ACPI: Added _OSI(3.0 _SCP Extensions)
2025-08-02T11:59:46,170017+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2025-08-02T11:59:46,170022+00:00 ACPI: Added _OSI(Linux-Dell-Video)
2025-08-02T11:59:46,170027+00:00 ACPI: Added _OSI(Linux-Lenovo-NV-HDMI-Audio)
2025-08-02T11:59:46,170031+00:00 ACPI: Added _OSI(Linux-HPI-Hybrid-Graphics)
2025-08-02T11:59:46,179724+00:00 ACPI: 2 ACPI AML tables successfully acquired and loaded
2025-08-02T11:59:46,181733+00:00 ACPI: Interpreter enabled
2025-08-02T11:59:46,181759+00:00 ACPI: PM: (supports S0 S5)
2025-08-02T11:59:46,181764+00:00 ACPI: Using IOAPIC for interrupt routing
2025-08-02T11:59:46,181800+00:00 PCI: Using host bridge windows from ACPI; if necessary, use "pci=nocrs" and report a bug
2025-08-02T11:59:46,181808+00:00 PCI: Using E820 reservations for host bridge windows
2025-08-02T11:59:46,182175+00:00 ACPI: Enabled 3 GPEs in block 00 to 0F
2025-08-02T11:59:46,197971+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-ff])
2025-08-02T11:59:46,198012+00:00 acpi PNP0A03:00: _OSC: OS supports [ASPM ClockPM Segments MSI EDR HPX-Type3]
2025-08-02T11:59:46,198039+00:00 acpi PNP0A03:00: fail to add MMCONFIG information, can't access extended PCI configuration space under this bridge.
2025-08-02T11:59:46,198774+00:00 acpiphp: Slot [8] registered
2025-08-02T11:59:46,198806+00:00 acpiphp: Slot [10] registered
2025-08-02T11:59:46,198834+00:00 acpiphp: Slot [18] registered
2025-08-02T11:59:46,198931+00:00 acpiphp: Slot [3] registered
2025-08-02T11:59:46,198974+00:00 acpiphp: Slot [4] registered
2025-08-02T11:59:46,199030+00:00 acpiphp: Slot [6] registered
2025-08-02T11:59:46,199071+00:00 acpiphp: Slot [7] registered
2025-08-02T11:59:46,199100+00:00 acpiphp: Slot [9] registered
2025-08-02T11:59:46,199161+00:00 acpiphp: Slot [11] registered
2025-08-02T11:59:46,199211+00:00 acpiphp: Slot [12] registered
2025-08-02T11:59:46,199281+00:00 acpiphp: Slot [13] registered
2025-08-02T11:59:46,199329+00:00 acpiphp: Slot [14] registered
2025-08-02T11:59:46,199372+00:00 acpiphp: Slot [15] registered
2025-08-02T11:59:46,199415+00:00 acpiphp: Slot [16] registered
2025-08-02T11:59:46,199457+00:00 acpiphp: Slot [17] registered
2025-08-02T11:59:46,199502+00:00 acpiphp: Slot [19] registered
2025-08-02T11:59:46,199563+00:00 acpiphp: Slot [20] registered
2025-08-02T11:59:46,199616+00:00 acpiphp: Slot [21] registered
2025-08-02T11:59:46,199666+00:00 acpiphp: Slot [22] registered
2025-08-02T11:59:46,199717+00:00 acpiphp: Slot [23] registered
2025-08-02T11:59:46,199768+00:00 acpiphp: Slot [24] registered
2025-08-02T11:59:46,199812+00:00 acpiphp: Slot [25] registered
2025-08-02T11:59:46,199854+00:00 acpiphp: Slot [26] registered
2025-08-02T11:59:46,199912+00:00 acpiphp: Slot [27] registered
2025-08-02T11:59:46,199957+00:00 acpiphp: Slot [28] registered
2025-08-02T11:59:46,200014+00:00 acpiphp: Slot [29] registered
2025-08-02T11:59:46,200055+00:00 PCI host bridge to bus 0000:00
2025-08-02T11:59:46,200064+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0x0cf7 window]
2025-08-02T11:59:46,200071+00:00 pci_bus 0000:00: root bus resource [io  0x0d00-0xffff window]
2025-08-02T11:59:46,200076+00:00 pci_bus 0000:00: root bus resource [mem 0x000a0000-0x000bffff window]
2025-08-02T11:59:46,200082+00:00 pci_bus 0000:00: root bus resource [mem 0xc0000000-0xfebfffff window]
2025-08-02T11:59:46,200088+00:00 pci_bus 0000:00: root bus resource [mem 0x380000000000-0x38200000bfff window]
2025-08-02T11:59:46,200095+00:00 pci_bus 0000:00: root bus resource [bus 00-ff]
2025-08-02T11:59:46,200390+00:00 pci 0000:00:00.0: [8086:1237] type 00 class 0x060000
2025-08-02T11:59:46,201783+00:00 pci 0000:00:01.0: [8086:7000] type 00 class 0x060100
2025-08-02T11:59:46,202846+00:00 pci 0000:00:01.1: [8086:7010] type 00 class 0x010180
2025-08-02T11:59:46,204542+00:00 pci 0000:00:01.1: reg 0x20: [io  0xf100-0xf10f]
2025-08-02T11:59:46,204630+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x10: [io  0x01f0-0x01f7]
2025-08-02T11:59:46,204637+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x14: [io  0x03f6]
2025-08-02T11:59:46,204642+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x18: [io  0x0170-0x0177]
2025-08-02T11:59:46,204647+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x1c: [io  0x0376]
2025-08-02T11:59:46,205210+00:00 pci 0000:00:01.2: [8086:7020] type 00 class 0x0c0300
2025-08-02T11:59:46,206676+00:00 pci 0000:00:01.2: reg 0x20: [io  0xf0c0-0xf0df]
2025-08-02T11:59:46,208172+00:00 pci 0000:00:01.3: [8086:7113] type 00 class 0x068000
2025-08-02T11:59:46,208873+00:00 pci 0000:00:01.3: quirk: [io  0x0600-0x063f] claimed by PIIX4 ACPI
2025-08-02T11:59:46,208891+00:00 pci 0000:00:01.3: quirk: [io  0x0700-0x070f] claimed by PIIX4 SMB
2025-08-02T11:59:46,209846+00:00 pci 0000:00:02.0: [1234:1111] type 00 class 0x030000
2025-08-02T11:59:46,217813+00:00 pci 0000:00:02.0: reg 0x10: [mem 0xfd000000-0xfdffffff pref]
2025-08-02T11:59:46,217989+00:00 pci 0000:00:02.0: reg 0x18: [mem 0xfea50000-0xfea50fff]
2025-08-02T11:59:46,218053+00:00 pci 0000:00:02.0: reg 0x30: [mem 0xfea40000-0xfea4ffff pref]
2025-08-02T11:59:46,218342+00:00 pci 0000:00:02.0: BAR 0: assigned to efifb
2025-08-02T11:59:46,218429+00:00 pci 0000:00:02.0: Video device with shadowed ROM at [mem 0x000c0000-0x000dffff]
2025-08-02T11:59:46,221094+00:00 pci 0000:00:05.0: [1b36:0001] type 01 class 0x060400
2025-08-02T11:59:46,225253+00:00 pci 0000:00:05.0: reg 0x10: [mem 0x380000000000-0x3800000000ff 64bit]
2025-08-02T11:59:46,229329+00:00 pci 0000:00:08.0: [1af4:1003] type 00 class 0x078000
2025-08-02T11:59:46,232173+00:00 pci 0000:00:08.0: reg 0x10: [io  0xf080-0xf0bf]
2025-08-02T11:59:46,232214+00:00 pci 0000:00:08.0: reg 0x14: [mem 0xfea51000-0xfea51fff]
2025-08-02T11:59:46,232268+00:00 pci 0000:00:08.0: reg 0x20: [mem 0x382000000000-0x382000003fff 64bit pref]
2025-08-02T11:59:46,236795+00:00 pci 0000:00:0a.0: [1af4:1001] type 00 class 0x010000
2025-08-02T11:59:46,240089+00:00 pci 0000:00:0a.0: reg 0x10: [io  0xf000-0xf07f]
2025-08-02T11:59:46,240135+00:00 pci 0000:00:0a.0: reg 0x14: [mem 0xfea52000-0xfea52fff]
2025-08-02T11:59:46,240204+00:00 pci 0000:00:0a.0: reg 0x20: [mem 0x382000004000-0x382000007fff 64bit pref]
2025-08-02T11:59:46,247184+00:00 pci 0000:00:12.0: [1af4:1000] type 00 class 0x020000
2025-08-02T11:59:46,249594+00:00 pci 0000:00:12.0: reg 0x10: [io  0xf0e0-0xf0ff]
2025-08-02T11:59:46,249632+00:00 pci 0000:00:12.0: reg 0x14: [mem 0xfea53000-0xfea53fff]
2025-08-02T11:59:46,249702+00:00 pci 0000:00:12.0: reg 0x20: [mem 0x382000008000-0x38200000bfff 64bit pref]
2025-08-02T11:59:46,249727+00:00 pci 0000:00:12.0: reg 0x30: [mem 0xfea00000-0xfea3ffff pref]
2025-08-02T11:59:46,258493+00:00 pci 0000:00:1e.0: [1b36:0001] type 01 class 0x060400
2025-08-02T11:59:46,261481+00:00 pci 0000:00:1e.0: reg 0x10: [mem 0x380000001000-0x3800000010ff 64bit]
2025-08-02T11:59:46,264269+00:00 pci 0000:00:1f.0: [1b36:0001] type 01 class 0x060400
2025-08-02T11:59:46,267377+00:00 pci 0000:00:1f.0: reg 0x10: [mem 0x380000002000-0x3800000020ff 64bit]
2025-08-02T11:59:46,270696+00:00 pci_bus 0000:01: extended config space not accessible
2025-08-02T11:59:46,271622+00:00 acpiphp: Slot [0] registered
2025-08-02T11:59:46,271700+00:00 acpiphp: Slot [1-2] registered
2025-08-02T11:59:46,271764+00:00 acpiphp: Slot [2] registered
2025-08-02T11:59:46,271824+00:00 acpiphp: Slot [3-2] registered
2025-08-02T11:59:46,271883+00:00 acpiphp: Slot [4-2] registered
2025-08-02T11:59:46,271951+00:00 acpiphp: Slot [5] registered
2025-08-02T11:59:46,272014+00:00 acpiphp: Slot [6-2] registered
2025-08-02T11:59:46,272074+00:00 acpiphp: Slot [7-2] registered
2025-08-02T11:59:46,272130+00:00 acpiphp: Slot [8-2] registered
2025-08-02T11:59:46,272205+00:00 acpiphp: Slot [9-2] registered
2025-08-02T11:59:46,272266+00:00 acpiphp: Slot [10-2] registered
2025-08-02T11:59:46,272340+00:00 acpiphp: Slot [11-2] registered
2025-08-02T11:59:46,272398+00:00 acpiphp: Slot [12-2] registered
2025-08-02T11:59:46,272458+00:00 acpiphp: Slot [13-2] registered
2025-08-02T11:59:46,272516+00:00 acpiphp: Slot [14-2] registered
2025-08-02T11:59:46,272575+00:00 acpiphp: Slot [15-2] registered
2025-08-02T11:59:46,272636+00:00 acpiphp: Slot [16-2] registered
2025-08-02T11:59:46,272693+00:00 acpiphp: Slot [17-2] registered
2025-08-02T11:59:46,272779+00:00 acpiphp: Slot [18-2] registered
2025-08-02T11:59:46,272839+00:00 acpiphp: Slot [19-2] registered
2025-08-02T11:59:46,272905+00:00 acpiphp: Slot [20-2] registered
2025-08-02T11:59:46,272964+00:00 acpiphp: Slot [21-2] registered
2025-08-02T11:59:46,273022+00:00 acpiphp: Slot [22-2] registered
2025-08-02T11:59:46,273081+00:00 acpiphp: Slot [23-2] registered
2025-08-02T11:59:46,273158+00:00 acpiphp: Slot [24-2] registered
2025-08-02T11:59:46,273220+00:00 acpiphp: Slot [25-2] registered
2025-08-02T11:59:46,273292+00:00 acpiphp: Slot [26-2] registered
2025-08-02T11:59:46,273352+00:00 acpiphp: Slot [27-2] registered
2025-08-02T11:59:46,273408+00:00 acpiphp: Slot [28-2] registered
2025-08-02T11:59:46,273465+00:00 acpiphp: Slot [29-2] registered
2025-08-02T11:59:46,273545+00:00 acpiphp: Slot [30] registered
2025-08-02T11:59:46,273597+00:00 acpiphp: Slot [31] registered
2025-08-02T11:59:46,287423+00:00 pci 0000:00:05.0: PCI bridge to [bus 01]
2025-08-02T11:59:46,287514+00:00 pci 0000:00:05.0:   bridge window [io  0xe000-0xefff]
2025-08-02T11:59:46,287561+00:00 pci 0000:00:05.0:   bridge window [mem 0xfe800000-0xfe9fffff]
2025-08-02T11:59:46,287642+00:00 pci 0000:00:05.0:   bridge window [mem 0x381800000000-0x381fffffffff 64bit pref]
2025-08-02T11:59:46,289212+00:00 pci_bus 0000:02: extended config space not accessible
2025-08-02T11:59:46,290085+00:00 acpiphp: Slot [0-2] registered
2025-08-02T11:59:46,290176+00:00 acpiphp: Slot [1-3] registered
2025-08-02T11:59:46,290246+00:00 acpiphp: Slot [2-2] registered
2025-08-02T11:59:46,290311+00:00 acpiphp: Slot [3-3] registered
2025-08-02T11:59:46,290374+00:00 acpiphp: Slot [4-3] registered
2025-08-02T11:59:46,290435+00:00 acpiphp: Slot [5-2] registered
2025-08-02T11:59:46,290501+00:00 acpiphp: Slot [6-3] registered
2025-08-02T11:59:46,290583+00:00 acpiphp: Slot [7-3] registered
2025-08-02T11:59:46,290656+00:00 acpiphp: Slot [8-3] registered
2025-08-02T11:59:46,290721+00:00 acpiphp: Slot [9-3] registered
2025-08-02T11:59:46,290788+00:00 acpiphp: Slot [10-3] registered
2025-08-02T11:59:46,290854+00:00 acpiphp: Slot [11-3] registered
2025-08-02T11:59:46,290923+00:00 acpiphp: Slot [12-3] registered
2025-08-02T11:59:46,290990+00:00 acpiphp: Slot [13-3] registered
2025-08-02T11:59:46,291077+00:00 acpiphp: Slot [14-3] registered
2025-08-02T11:59:46,291143+00:00 acpiphp: Slot [15-3] registered
2025-08-02T11:59:46,291208+00:00 acpiphp: Slot [16-3] registered
2025-08-02T11:59:46,291292+00:00 acpiphp: Slot [17-3] registered
2025-08-02T11:59:46,291360+00:00 acpiphp: Slot [18-3] registered
2025-08-02T11:59:46,291427+00:00 acpiphp: Slot [19-3] registered
2025-08-02T11:59:46,291513+00:00 acpiphp: Slot [20-3] registered
2025-08-02T11:59:46,291590+00:00 acpiphp: Slot [21-3] registered
2025-08-02T11:59:46,291666+00:00 acpiphp: Slot [22-3] registered
2025-08-02T11:59:46,291731+00:00 acpiphp: Slot [23-3] registered
2025-08-02T11:59:46,291798+00:00 acpiphp: Slot [24-3] registered
2025-08-02T11:59:46,291862+00:00 acpiphp: Slot [25-3] registered
2025-08-02T11:59:46,291929+00:00 acpiphp: Slot [26-3] registered
2025-08-02T11:59:46,292013+00:00 acpiphp: Slot [27-3] registered
2025-08-02T11:59:46,292080+00:00 acpiphp: Slot [28-3] registered
2025-08-02T11:59:46,292149+00:00 acpiphp: Slot [29-3] registered
2025-08-02T11:59:46,292242+00:00 acpiphp: Slot [30-2] registered
2025-08-02T11:59:46,292309+00:00 acpiphp: Slot [31-2] registered
2025-08-02T11:59:46,304987+00:00 pci 0000:00:1e.0: PCI bridge to [bus 02]
2025-08-02T11:59:46,305028+00:00 pci 0000:00:1e.0:   bridge window [io  0xd000-0xdfff]
2025-08-02T11:59:46,305053+00:00 pci 0000:00:1e.0:   bridge window [mem 0xfe600000-0xfe7fffff]
2025-08-02T11:59:46,305101+00:00 pci 0000:00:1e.0:   bridge window [mem 0x381000000000-0x3817ffffffff 64bit pref]
2025-08-02T11:59:46,305963+00:00 pci_bus 0000:03: extended config space not accessible
2025-08-02T11:59:46,306481+00:00 acpiphp: Slot [0-3] registered
2025-08-02T11:59:46,306666+00:00 acpiphp: Slot [1-4] registered
2025-08-02T11:59:46,306701+00:00 acpiphp: Slot [2-3] registered
2025-08-02T11:59:46,306733+00:00 acpiphp: Slot [3-4] registered
2025-08-02T11:59:46,306776+00:00 acpiphp: Slot [4-4] registered
2025-08-02T11:59:46,306810+00:00 acpiphp: Slot [5-3] registered
2025-08-02T11:59:46,306848+00:00 acpiphp: Slot [6-4] registered
2025-08-02T11:59:46,306911+00:00 acpiphp: Slot [7-4] registered
2025-08-02T11:59:46,306974+00:00 acpiphp: Slot [8-4] registered
2025-08-02T11:59:46,307024+00:00 acpiphp: Slot [9-4] registered
2025-08-02T11:59:46,307096+00:00 acpiphp: Slot [10-4] registered
2025-08-02T11:59:46,307148+00:00 acpiphp: Slot [11-4] registered
2025-08-02T11:59:46,307203+00:00 acpiphp: Slot [12-4] registered
2025-08-02T11:59:46,307252+00:00 acpiphp: Slot [13-4] registered
2025-08-02T11:59:46,307289+00:00 acpiphp: Slot [14-4] registered
2025-08-02T11:59:46,307322+00:00 acpiphp: Slot [15-4] registered
2025-08-02T11:59:46,307404+00:00 acpiphp: Slot [16-4] registered
2025-08-02T11:59:46,307449+00:00 acpiphp: Slot [17-4] registered
2025-08-02T11:59:46,307486+00:00 acpiphp: Slot [18-4] registered
2025-08-02T11:59:46,307542+00:00 acpiphp: Slot [19-4] registered
2025-08-02T11:59:46,307579+00:00 acpiphp: Slot [20-4] registered
2025-08-02T11:59:46,307612+00:00 acpiphp: Slot [21-4] registered
2025-08-02T11:59:46,307644+00:00 acpiphp: Slot [22-4] registered
2025-08-02T11:59:46,307688+00:00 acpiphp: Slot [23-4] registered
2025-08-02T11:59:46,307723+00:00 acpiphp: Slot [24-4] registered
2025-08-02T11:59:46,307766+00:00 acpiphp: Slot [25-4] registered
2025-08-02T11:59:46,307801+00:00 acpiphp: Slot [26-4] registered
2025-08-02T11:59:46,307833+00:00 acpiphp: Slot [27-4] registered
2025-08-02T11:59:46,307879+00:00 acpiphp: Slot [28-4] registered
2025-08-02T11:59:46,307953+00:00 acpiphp: Slot [29-4] registered
2025-08-02T11:59:46,308025+00:00 acpiphp: Slot [30-3] registered
2025-08-02T11:59:46,308086+00:00 acpiphp: Slot [31-3] registered
2025-08-02T11:59:46,319439+00:00 pci 0000:00:1f.0: PCI bridge to [bus 03]
2025-08-02T11:59:46,319485+00:00 pci 0000:00:1f.0:   bridge window [io  0xc000-0xcfff]
2025-08-02T11:59:46,319518+00:00 pci 0000:00:1f.0:   bridge window [mem 0xfe400000-0xfe5fffff]
2025-08-02T11:59:46,319585+00:00 pci 0000:00:1f.0:   bridge window [mem 0x380800000000-0x380fffffffff 64bit pref]
2025-08-02T11:59:46,324245+00:00 ACPI: PCI: Interrupt link LNKA configured for IRQ 10
2025-08-02T11:59:46,324582+00:00 ACPI: PCI: Interrupt link LNKB configured for IRQ 10
2025-08-02T11:59:46,324913+00:00 ACPI: PCI: Interrupt link LNKC configured for IRQ 11
2025-08-02T11:59:46,325240+00:00 ACPI: PCI: Interrupt link LNKD configured for IRQ 11
2025-08-02T11:59:46,325406+00:00 ACPI: PCI: Interrupt link LNKS configured for IRQ 9
2025-08-02T11:59:46,328224+00:00 iommu: Default domain type: Translated 
2025-08-02T11:59:46,328224+00:00 iommu: DMA domain TLB invalidation policy: lazy mode 
2025-08-02T11:59:46,328224+00:00 SCSI subsystem initialized
2025-08-02T11:59:46,329729+00:00 libata version 3.00 loaded.
2025-08-02T11:59:46,329954+00:00 pci 0000:00:02.0: vgaarb: setting as boot VGA device
2025-08-02T11:59:46,329954+00:00 pci 0000:00:02.0: vgaarb: VGA device added: decodes=io+mem,owns=io+mem,locks=none
2025-08-02T11:59:46,329954+00:00 pci 0000:00:02.0: vgaarb: bridge control possible
2025-08-02T11:59:46,329954+00:00 vgaarb: loaded
2025-08-02T11:59:46,329954+00:00 ACPI: bus type USB registered
2025-08-02T11:59:46,329985+00:00 usbcore: registered new interface driver usbfs
2025-08-02T11:59:46,330005+00:00 usbcore: registered new interface driver hub
2025-08-02T11:59:46,330017+00:00 usbcore: registered new device driver usb
2025-08-02T11:59:46,330078+00:00 pps_core: LinuxPPS API ver. 1 registered
2025-08-02T11:59:46,330085+00:00 pps_core: Software ver. 5.3.6 - Copyright 2005-2007 Rodolfo Giometti <giometti@linux.it>
2025-08-02T11:59:46,330098+00:00 PTP clock support registered
2025-08-02T11:59:46,330195+00:00 EDAC MC: Ver: 3.0.0
2025-08-02T11:59:46,330492+00:00 NetLabel: Initializing
2025-08-02T11:59:46,330505+00:00 NetLabel:  domain hash size = 128
2025-08-02T11:59:46,330509+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2025-08-02T11:59:46,330573+00:00 NetLabel:  unlabeled traffic allowed by default
2025-08-02T11:59:46,330653+00:00 PCI: Using ACPI for IRQ routing
2025-08-02T11:59:46,330653+00:00 PCI: pci_cache_line_size set to 64 bytes
2025-08-02T11:59:46,333680+00:00 e820: reserve RAM buffer [mem 0x0009fc00-0x0009ffff]
2025-08-02T11:59:46,333686+00:00 e820: reserve RAM buffer [mem 0xbffda000-0xbfffffff]
2025-08-02T11:59:46,343216+00:00 hpet0: at MMIO 0xfed00000, IRQs 2, 8, 0
2025-08-02T11:59:46,343246+00:00 hpet0: 3 comparators, 64-bit 100.000000 MHz counter
2025-08-02T11:59:46,347441+00:00 clocksource: Switched to clocksource kvm-clock
2025-08-02T11:59:46,372078+00:00 VFS: Disk quotas dquot_6.6.0
2025-08-02T11:59:46,372129+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2025-08-02T11:59:46,372512+00:00 AppArmor: AppArmor Filesystem Enabled
2025-08-02T11:59:46,372551+00:00 pnp: PnP ACPI init
2025-08-02T11:59:46,372776+00:00 pnp 00:02: [dma 2]
2025-08-02T11:59:46,373278+00:00 pnp: PnP ACPI: found 4 devices
2025-08-02T11:59:46,386764+00:00 clocksource: acpi_pm: mask: 0xffffff max_cycles: 0xffffff, max_idle_ns: 2085701024 ns
2025-08-02T11:59:46,387156+00:00 NET: Registered PF_INET protocol family
2025-08-02T11:59:46,389584+00:00 IP idents hash table entries: 262144 (order: 9, 2097152 bytes, linear)
2025-08-02T11:59:46,394679+00:00 tcp_listen_portaddr_hash hash table entries: 8192 (order: 5, 131072 bytes, linear)
2025-08-02T11:59:46,394980+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2025-08-02T11:59:46,396042+00:00 TCP established hash table entries: 131072 (order: 8, 1048576 bytes, linear)
2025-08-02T11:59:46,397230+00:00 TCP bind hash table entries: 65536 (order: 8, 1048576 bytes, linear)
2025-08-02T11:59:46,397358+00:00 TCP: Hash tables configured (established 131072 bind 65536)
2025-08-02T11:59:46,398242+00:00 MPTCP token hash table entries: 16384 (order: 6, 393216 bytes, linear)
2025-08-02T11:59:46,398587+00:00 UDP hash table entries: 8192 (order: 6, 262144 bytes, linear)
2025-08-02T11:59:46,398894+00:00 UDP-Lite hash table entries: 8192 (order: 6, 262144 bytes, linear)
2025-08-02T11:59:46,399143+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2025-08-02T11:59:46,399181+00:00 NET: Registered PF_XDP protocol family
2025-08-02T11:59:46,399233+00:00 pci 0000:00:05.0: PCI bridge to [bus 01]
2025-08-02T11:59:46,399295+00:00 pci 0000:00:05.0:   bridge window [io  0xe000-0xefff]
2025-08-02T11:59:46,401424+00:00 pci 0000:00:05.0:   bridge window [mem 0xfe800000-0xfe9fffff]
2025-08-02T11:59:46,402749+00:00 pci 0000:00:05.0:   bridge window [mem 0x381800000000-0x381fffffffff 64bit pref]
2025-08-02T11:59:46,405321+00:00 pci 0000:00:1e.0: PCI bridge to [bus 02]
2025-08-02T11:59:46,405355+00:00 pci 0000:00:1e.0:   bridge window [io  0xd000-0xdfff]
2025-08-02T11:59:46,407352+00:00 pci 0000:00:1e.0:   bridge window [mem 0xfe600000-0xfe7fffff]
2025-08-02T11:59:46,408676+00:00 pci 0000:00:1e.0:   bridge window [mem 0x381000000000-0x3817ffffffff 64bit pref]
2025-08-02T11:59:46,411730+00:00 pci 0000:00:1f.0: PCI bridge to [bus 03]
2025-08-02T11:59:46,411762+00:00 pci 0000:00:1f.0:   bridge window [io  0xc000-0xcfff]
2025-08-02T11:59:46,412934+00:00 pci 0000:00:1f.0:   bridge window [mem 0xfe400000-0xfe5fffff]
2025-08-02T11:59:46,413730+00:00 pci 0000:00:1f.0:   bridge window [mem 0x380800000000-0x380fffffffff 64bit pref]
2025-08-02T11:59:46,415696+00:00 pci_bus 0000:00: resource 4 [io  0x0000-0x0cf7 window]
2025-08-02T11:59:46,415707+00:00 pci_bus 0000:00: resource 5 [io  0x0d00-0xffff window]
2025-08-02T11:59:46,415714+00:00 pci_bus 0000:00: resource 6 [mem 0x000a0000-0x000bffff window]
2025-08-02T11:59:46,415720+00:00 pci_bus 0000:00: resource 7 [mem 0xc0000000-0xfebfffff window]
2025-08-02T11:59:46,415726+00:00 pci_bus 0000:00: resource 8 [mem 0x380000000000-0x38200000bfff window]
2025-08-02T11:59:46,415734+00:00 pci_bus 0000:01: resource 0 [io  0xe000-0xefff]
2025-08-02T11:59:46,415740+00:00 pci_bus 0000:01: resource 1 [mem 0xfe800000-0xfe9fffff]
2025-08-02T11:59:46,415745+00:00 pci_bus 0000:01: resource 2 [mem 0x381800000000-0x381fffffffff 64bit pref]
2025-08-02T11:59:46,415754+00:00 pci_bus 0000:02: resource 0 [io  0xd000-0xdfff]
2025-08-02T11:59:46,415759+00:00 pci_bus 0000:02: resource 1 [mem 0xfe600000-0xfe7fffff]
2025-08-02T11:59:46,415764+00:00 pci_bus 0000:02: resource 2 [mem 0x381000000000-0x3817ffffffff 64bit pref]
2025-08-02T11:59:46,415769+00:00 pci_bus 0000:03: resource 0 [io  0xc000-0xcfff]
2025-08-02T11:59:46,415774+00:00 pci_bus 0000:03: resource 1 [mem 0xfe400000-0xfe5fffff]
2025-08-02T11:59:46,415779+00:00 pci_bus 0000:03: resource 2 [mem 0x380800000000-0x380fffffffff 64bit pref]
2025-08-02T11:59:46,416051+00:00 pci 0000:00:01.0: PIIX3: Enabling Passive Release
2025-08-02T11:59:46,416091+00:00 pci 0000:00:00.0: Limiting direct PCI/PCI transfers
2025-08-02T11:59:46,416125+00:00 pci 0000:00:01.0: Activating ISA DMA hang workarounds
2025-08-02T11:59:46,418246+00:00 ACPI: \_SB_.LNKD: Enabled at IRQ 11
2025-08-02T11:59:46,420608+00:00 PCI: CLS 0 bytes, default 64
2025-08-02T11:59:46,420654+00:00 PCI-DMA: Using software bounce buffering for IO (SWIOTLB)
2025-08-02T11:59:46,420667+00:00 software IO TLB: mapped [mem 0x00000000bbfda000-0x00000000bffda000] (64MB)
2025-08-02T11:59:46,420827+00:00 clocksource: tsc: mask: 0xffffffffffffffff max_cycles: 0x29cd4133323, max_idle_ns: 440795296220 ns
2025-08-02T11:59:46,421085+00:00 Trying to unpack rootfs image as initramfs...
2025-08-02T11:59:46,422589+00:00 Initialise system trusted keyrings
2025-08-02T11:59:46,422654+00:00 Key type blacklist registered
2025-08-02T11:59:46,422874+00:00 workingset: timestamp_bits=36 max_order=22 bucket_order=0
2025-08-02T11:59:46,426514+00:00 zbud: loaded
2025-08-02T11:59:46,427376+00:00 squashfs: version 4.0 (2009/01/31) Phillip Lougher
2025-08-02T11:59:46,428026+00:00 fuse: init (API version 7.34)
2025-08-02T11:59:46,428874+00:00 integrity: Platform Keyring initialized
2025-08-02T11:59:46,438921+00:00 Key type asymmetric registered
2025-08-02T11:59:46,438953+00:00 Asymmetric key parser 'x509' registered
2025-08-02T11:59:46,439017+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 243)
2025-08-02T11:59:46,439267+00:00 io scheduler mq-deadline registered
2025-08-02T11:59:46,440913+00:00 shpchp 0000:00:05.0: Requesting control of SHPC hotplug via OSHP (\_SB_.PCI0.S28_)
2025-08-02T11:59:46,440938+00:00 shpchp 0000:00:05.0: Requesting control of SHPC hotplug via OSHP (\_SB_.PCI0)
2025-08-02T11:59:46,440961+00:00 shpchp 0000:00:05.0: Cannot get control of SHPC hotplug
2025-08-02T11:59:46,441061+00:00 shpchp 0000:00:1e.0: Requesting control of SHPC hotplug via OSHP (\_SB_.PCI0.SF0_)
2025-08-02T11:59:46,441076+00:00 shpchp 0000:00:1e.0: Requesting control of SHPC hotplug via OSHP (\_SB_.PCI0)
2025-08-02T11:59:46,441086+00:00 shpchp 0000:00:1e.0: Cannot get control of SHPC hotplug
2025-08-02T11:59:46,441188+00:00 shpchp 0000:00:1f.0: Requesting control of SHPC hotplug via OSHP (\_SB_.PCI0.SF8_)
2025-08-02T11:59:46,441204+00:00 shpchp 0000:00:1f.0: Requesting control of SHPC hotplug via OSHP (\_SB_.PCI0)
2025-08-02T11:59:46,441215+00:00 shpchp 0000:00:1f.0: Cannot get control of SHPC hotplug
2025-08-02T11:59:46,441246+00:00 shpchp: Standard Hot Plug PCI Controller Driver version: 0.4
2025-08-02T11:59:46,441775+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXPWRBN:00/input/input0
2025-08-02T11:59:46,441886+00:00 ACPI: button: Power Button [PWRF]
2025-08-02T11:59:46,449981+00:00 ACPI: \_SB_.LNKB: Enabled at IRQ 10
2025-08-02T11:59:46,457410+00:00 Serial: 8250/16550 driver, 32 ports, IRQ sharing enabled
2025-08-02T11:59:46,481053+00:00 Linux agpgart interface v0.103
2025-08-02T11:59:46,489520+00:00 loop: module loaded
2025-08-02T11:59:46,490027+00:00 ata_piix 0000:00:01.1: version 2.13
2025-08-02T11:59:46,491725+00:00 scsi host0: ata_piix
2025-08-02T11:59:46,492126+00:00 scsi host1: ata_piix
2025-08-02T11:59:46,492192+00:00 ata1: PATA max MWDMA2 cmd 0x1f0 ctl 0x3f6 bmdma 0xf100 irq 14
2025-08-02T11:59:46,492203+00:00 ata2: PATA max MWDMA2 cmd 0x170 ctl 0x376 bmdma 0xf108 irq 15
2025-08-02T11:59:46,492611+00:00 tun: Universal TUN/TAP device driver, 1.6
2025-08-02T11:59:46,492741+00:00 PPP generic driver version 2.4.2
2025-08-02T11:59:46,492959+00:00 VFIO - User Level meta-driver version: 0.3
2025-08-02T11:59:46,493172+00:00 ehci_hcd: USB 2.0 'Enhanced' Host Controller (EHCI) Driver
2025-08-02T11:59:46,493189+00:00 ehci-pci: EHCI PCI platform driver
2025-08-02T11:59:46,493205+00:00 ehci-platform: EHCI generic platform driver
2025-08-02T11:59:46,493213+00:00 ohci_hcd: USB 1.1 'Open' Host Controller (OHCI) Driver
2025-08-02T11:59:46,493218+00:00 ohci-pci: OHCI PCI platform driver
2025-08-02T11:59:46,493234+00:00 ohci-platform: OHCI generic platform driver
2025-08-02T11:59:46,493251+00:00 uhci_hcd: USB Universal Host Controller Interface driver
2025-08-02T11:59:46,495065+00:00 uhci_hcd 0000:00:01.2: UHCI Host Controller
2025-08-02T11:59:46,495089+00:00 uhci_hcd 0000:00:01.2: new USB bus registered, assigned bus number 1
2025-08-02T11:59:46,495129+00:00 uhci_hcd 0000:00:01.2: detected 2 ports
2025-08-02T11:59:46,495300+00:00 uhci_hcd 0000:00:01.2: irq 11, io base 0x0000f0c0
2025-08-02T11:59:46,495511+00:00 usb usb1: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 5.15
2025-08-02T11:59:46,495518+00:00 usb usb1: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2025-08-02T11:59:46,495524+00:00 usb usb1: Product: UHCI Host Controller
2025-08-02T11:59:46,495530+00:00 usb usb1: Manufacturer: Linux 5.15.0-151-generic uhci_hcd
2025-08-02T11:59:46,495535+00:00 usb usb1: SerialNumber: 0000:00:01.2
2025-08-02T11:59:46,495740+00:00 hub 1-0:1.0: USB hub found
2025-08-02T11:59:46,495756+00:00 hub 1-0:1.0: 2 ports detected
2025-08-02T11:59:46,496068+00:00 i8042: PNP: PS/2 Controller [PNP0303:KBD,PNP0f13:MOU] at 0x60,0x64 irq 1,12
2025-08-02T11:59:46,497554+00:00 serio: i8042 KBD port at 0x60,0x64 irq 1
2025-08-02T11:59:46,497587+00:00 serio: i8042 AUX port at 0x60,0x64 irq 12
2025-08-02T11:59:46,498247+00:00 mousedev: PS/2 mouse device common for all mice
2025-08-02T11:59:46,498752+00:00 rtc_cmos 00:03: RTC can wake from S4
2025-08-02T11:59:46,499394+00:00 input: AT Translated Set 2 keyboard as /devices/platform/i8042/serio0/input/input1
2025-08-02T11:59:46,500261+00:00 rtc_cmos 00:03: registered as rtc0
2025-08-02T11:59:46,500476+00:00 rtc_cmos 00:03: setting system clock to 2025-08-02T11:59:46 UTC (1754135986)
2025-08-02T11:59:46,500747+00:00 rtc_cmos 00:03: alarms up to one day, y3k, 242 bytes nvram, hpet irqs
2025-08-02T11:59:46,500778+00:00 i2c_dev: i2c /dev entries driver
2025-08-02T11:59:46,500860+00:00 device-mapper: core: CONFIG_IMA_DISABLE_HTABLE is disabled. Duplicate IMA measurements will not be recorded in the IMA log.
2025-08-02T11:59:46,501006+00:00 device-mapper: uevent: version 1.0.3
2025-08-02T11:59:46,501254+00:00 device-mapper: ioctl: 4.45.0-ioctl (2021-03-22) initialised: dm-devel@redhat.com
2025-08-02T11:59:46,501273+00:00 intel_pstate: CPU model not supported
2025-08-02T11:59:46,502119+00:00 ledtrig-cpu: registered to indicate activity on CPUs
2025-08-02T11:59:46,502241+00:00 efifb: probing for efifb
2025-08-02T11:59:46,502293+00:00 efifb: No BGRT, not showing boot graphics
2025-08-02T11:59:46,502299+00:00 efifb: framebuffer at 0xfd000000, using 1408k, total 1408k
2025-08-02T11:59:46,502303+00:00 efifb: mode is 800x600x24, linelength=2400, pages=1
2025-08-02T11:59:46,502308+00:00 efifb: scrolling: redraw
2025-08-02T11:59:46,502310+00:00 efifb: Truecolor: size=0:8:8:8, shift=0:16:8:0
2025-08-02T11:59:46,502691+00:00 Console: switching to colour frame buffer device 100x37
2025-08-02T11:59:46,505583+00:00 fb0: EFI VGA frame buffer device
2025-08-02T11:59:46,505843+00:00 drop_monitor: Initializing network drop monitor service
2025-08-02T11:59:46,506186+00:00 NET: Registered PF_INET6 protocol family
2025-08-02T11:59:46,651354+00:00 ata2.00: ATAPI: QEMU DVD-ROM, 2.5+, max UDMA/100
2025-08-02T11:59:46,653929+00:00 scsi 1:0:0:0: CD-ROM            QEMU     QEMU DVD-ROM     2.5+ PQ: 0 ANSI: 5
2025-08-02T11:59:46,695320+00:00 sr 1:0:0:0: [sr0] scsi3-mmc drive: 4x/4x cd/rw xa/form2 tray
2025-08-02T11:59:46,695414+00:00 cdrom: Uniform CD-ROM driver Revision: 3.20
2025-08-02T11:59:46,727857+00:00 sr 1:0:0:0: Attached scsi CD-ROM sr0
2025-08-02T11:59:46,728054+00:00 sr 1:0:0:0: Attached scsi generic sg0 type 5
2025-08-02T11:59:46,829980+00:00 usb 1-1: new full-speed USB device number 2 using uhci_hcd
2025-08-02T11:59:47,023469+00:00 usb 1-1: New USB device found, idVendor=0627, idProduct=0001, bcdDevice= 0.00
2025-08-02T11:59:47,023562+00:00 usb 1-1: New USB device strings: Mfr=1, Product=3, SerialNumber=10
2025-08-02T11:59:47,023626+00:00 usb 1-1: Product: QEMU USB Tablet
2025-08-02T11:59:47,025251+00:00 usb 1-1: Manufacturer: QEMU
2025-08-02T11:59:47,026747+00:00 usb 1-1: SerialNumber: 28754-0000:00:01.2-1
2025-08-02T11:59:47,885987+00:00 Freeing initrd memory: 103848K
2025-08-02T11:59:47,905995+00:00 Segment Routing with IPv6
2025-08-02T11:59:47,907461+00:00 In-situ OAM (IOAM) with IPv6
2025-08-02T11:59:47,908638+00:00 NET: Registered PF_PACKET protocol family
2025-08-02T11:59:47,910283+00:00 Key type dns_resolver registered
2025-08-02T11:59:47,913545+00:00 IPI shorthand broadcast: enabled
2025-08-02T11:59:47,914679+00:00 sched_clock: Marking stable (2072721691, 434868)->(2119794459, -46637900)
2025-08-02T11:59:47,917296+00:00 registered taskstats version 1
2025-08-02T11:59:47,920646+00:00 Loading compiled-in X.509 certificates
2025-08-02T11:59:47,923707+00:00 Loaded X.509 cert 'Build time autogenerated kernel key: 365d5e7c4363e0109b5f9144bb9f614e1e0c60f4'
2025-08-02T11:59:47,928056+00:00 Loaded X.509 cert 'Canonical Ltd. Live Patch Signing 2025 Kmod: d541cef61dc7e793b7eb7e899970a2eef0b5dc8c'
2025-08-02T11:59:47,931759+00:00 Loaded X.509 cert 'Canonical Ltd. Live Patch Signing: 14df34d1a87cf37625abec039ef2bf521249b969'
2025-08-02T11:59:47,935200+00:00 Loaded X.509 cert 'Canonical Ltd. Kernel Module Signing: 88f752e560a1e0737e31163a466ad7b70a850c19'
2025-08-02T11:59:47,937794+00:00 blacklist: Loading compiled-in revocation X.509 certificates
2025-08-02T11:59:47,939342+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing: 61482aa2830d0ab2ad5af10b7250da9033ddcef0'
2025-08-02T11:59:47,942210+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2017): 242ade75ac4a15e50d50c84b0d45ff3eae707a03'
2025-08-02T11:59:47,944525+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (ESM 2018): 365188c1d374d6b07c3c8f240f8ef722433d6a8b'
2025-08-02T11:59:47,947152+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2019): c0746fd6c5da3ae827864651ad66ae47fe24b3e8'
2025-08-02T11:59:47,949741+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v1): a8d54bbb3825cfb94fa13c9f8a594a195c107b8d'
2025-08-02T11:59:47,952434+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v2): 4cf046892d6fd3c9a5b03f98d845f90851dc6a8c'
2025-08-02T11:59:47,955376+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v3): 100437bb6de6e469b581e61cd66bce3ef4ed53af'
2025-08-02T11:59:47,958003+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (Ubuntu Core 2019): c1d57b8f6b743f23ee41f4f7ee292f06eecadfb9'
2025-08-02T11:59:47,963957+00:00 zswap: loaded using pool lzo/zbud
2025-08-02T11:59:47,967655+00:00 Key type .fscrypt registered
2025-08-02T11:59:47,969370+00:00 Key type fscrypt-provisioning registered
2025-08-02T11:59:47,980584+00:00 Key type encrypted registered
2025-08-02T11:59:47,982377+00:00 AppArmor: AppArmor sha1 policy hashing enabled
2025-08-02T11:59:47,984456+00:00 ima: No TPM chip found, activating TPM-bypass!
2025-08-02T11:59:47,986261+00:00 Loading compiled-in module X.509 certificates
2025-08-02T11:59:47,988544+00:00 Loaded X.509 cert 'Build time autogenerated kernel key: 365d5e7c4363e0109b5f9144bb9f614e1e0c60f4'
2025-08-02T11:59:47,991557+00:00 ima: Allocated hash algorithm: sha1
2025-08-02T11:59:47,993249+00:00 ima: No architecture policies found
2025-08-02T11:59:47,995078+00:00 evm: Initialising EVM extended attributes:
2025-08-02T11:59:47,996724+00:00 evm: security.selinux
2025-08-02T11:59:47,998438+00:00 evm: security.SMACK64
2025-08-02T11:59:47,999961+00:00 evm: security.SMACK64EXEC
2025-08-02T11:59:48,001765+00:00 evm: security.SMACK64TRANSMUTE
2025-08-02T11:59:48,003019+00:00 evm: security.SMACK64MMAP
2025-08-02T11:59:48,004121+00:00 evm: security.apparmor
2025-08-02T11:59:48,005079+00:00 evm: security.ima
2025-08-02T11:59:48,006122+00:00 evm: security.capability
2025-08-02T11:59:48,007162+00:00 evm: HMAC attrs: 0x1
2025-08-02T11:59:48,009258+00:00 PM:   Magic number: 5:769:983
2025-08-02T11:59:48,011561+00:00 RAS: Correctable Errors collector initialized.
2025-08-02T11:59:48,012530+00:00 clk: Disabling unused clocks
2025-08-02T11:59:48,017492+00:00 Freeing unused decrypted memory: 2036K
2025-08-02T11:59:48,019502+00:00 Freeing unused kernel image (initmem) memory: 3284K
2025-08-02T11:59:48,020533+00:00 Write protecting the kernel read-only data: 30720k
2025-08-02T11:59:48,023461+00:00 Freeing unused kernel image (text/rodata gap) memory: 2036K
2025-08-02T11:59:48,026547+00:00 Freeing unused kernel image (rodata/data gap) memory: 1300K
2025-08-02T11:59:48,076100+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2025-08-02T11:59:48,076912+00:00 x86/mm: Checking user space page tables
2025-08-02T11:59:48,123869+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2025-08-02T11:59:48,124704+00:00 Run /init as init process
2025-08-02T11:59:48,125419+00:00   with arguments:
2025-08-02T11:59:48,125422+00:00     /init
2025-08-02T11:59:48,125423+00:00   with environment:
2025-08-02T11:59:48,125424+00:00     HOME=/
2025-08-02T11:59:48,125425+00:00     TERM=linux
2025-08-02T11:59:48,125426+00:00     BOOT_IMAGE=/boot/vmlinuz-5.15.0-151-generic
2025-08-02T11:59:48,437228+00:00 piix4_smbus 0000:00:01.3: SMBus Host Controller at 0x700, revision 0
2025-08-02T11:59:48,438467+00:00 hid: raw HID events driver (C) Jiri Kosina
2025-08-02T11:59:48,453765+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input4
2025-08-02T11:59:48,463049+00:00 virtio_blk virtio1: [vda] 251658240 512-byte logical blocks (129 GB/120 GiB)
2025-08-02T11:59:48,471767+00:00 cryptd: max_cpu_qlen set to 1000
2025-08-02T11:59:48,474575+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input3
2025-08-02T11:59:48,477677+00:00 usbcore: registered new interface driver usbhid
2025-08-02T11:59:48,478932+00:00 usbhid: USB HID core driver
2025-08-02T11:59:48,483713+00:00  vda: vda1 vda2
2025-08-02T11:59:48,491544+00:00 AVX version of gcm_enc/dec engaged.
2025-08-02T11:59:48,493416+00:00 AES CTR mode by8 optimization enabled
2025-08-02T11:59:48,552083+00:00 Console: switching to colour dummy device 80x25
2025-08-02T11:59:48,552222+00:00 bochs-drm 0000:00:02.0: vgaarb: deactivate vga console
2025-08-02T11:59:48,552495+00:00 [drm] Found bochs VGA, ID 0xb0c5.
2025-08-02T11:59:48,552506+00:00 [drm] Framebuffer size 16384 kB @ 0xfd000000, mmio @ 0xfea50000.
2025-08-02T11:59:48,555550+00:00 [drm] Found EDID data blob.
2025-08-02T11:59:48,555777+00:00 [drm] Initialized bochs-drm 1.0.0 20130925 for 0000:00:02.0 on minor 0
2025-08-02T11:59:48,560079+00:00 fbcon: bochs-drmdrmfb (fb0) is primary device
2025-08-02T11:59:48,589558+00:00 Console: switching to colour frame buffer device 160x50
2025-08-02T11:59:48,596302+00:00 bochs-drm 0000:00:02.0: [drm] fb0: bochs-drmdrmfb frame buffer device
2025-08-02T11:59:48,616133+00:00 input: QEMU QEMU USB Tablet as /devices/pci0000:00/0000:00:01.2/usb1/1-1/1-1:1.0/0003:0627:0001.0001/input/input5
2025-08-02T11:59:48,617775+00:00 hid-generic 0003:0627:0001.0001: input,hidraw0: USB HID v0.01 Mouse [QEMU QEMU USB Tablet] on usb-0000:00:01.2-1/input0
2025-08-02T11:59:48,618859+00:00 virtio_net virtio2 ens18: renamed from eth0
2025-08-02T11:59:48,933922+00:00 raid6: sse2x4   gen() 12005 MB/s
2025-08-02T11:59:49,001920+00:00 raid6: sse2x4   xor()  6280 MB/s
2025-08-02T11:59:49,069925+00:00 raid6: sse2x2   gen()  8500 MB/s
2025-08-02T11:59:49,137968+00:00 raid6: sse2x2   xor()  7163 MB/s
2025-08-02T11:59:49,205935+00:00 raid6: sse2x1   gen()  7856 MB/s
2025-08-02T11:59:49,273925+00:00 raid6: sse2x1   xor()  6817 MB/s
2025-08-02T11:59:49,273957+00:00 raid6: using algorithm sse2x4 gen() 12005 MB/s
2025-08-02T11:59:49,273970+00:00 raid6: .... xor() 6280 MB/s, rmw enabled
2025-08-02T11:59:49,273982+00:00 raid6: using ssse3x2 recovery algorithm
2025-08-02T11:59:49,275784+00:00 xor: automatically using best checksumming function   avx       
2025-08-02T11:59:49,277002+00:00 async_tx: api initialized (async)
2025-08-02T11:59:49,403254+00:00 Btrfs loaded, crc32c=crc32c-intel, zoned=yes, fsverity=yes
2025-08-02T11:59:49,550170+00:00 EXT4-fs (vda2): mounted filesystem with ordered data mode. Opts: (null). Quota mode: none.
2025-08-02T11:59:49,969641+00:00 systemd[1]: Inserted module 'autofs4'
2025-08-02T11:59:50,010537+00:00 systemd[1]: systemd 249.11-0ubuntu3.12 running in system mode (+PAM +AUDIT +SELINUX +APPARMOR +IMA +SMACK +SECCOMP +GCRYPT +GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN +IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 -PWQUALITY -P11KIT -QRENCODE +BZIP2 +LZ4 +XZ +ZLIB +ZSTD -XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2025-08-02T11:59:50,012091+00:00 systemd[1]: Detected virtualization kvm.
2025-08-02T11:59:50,012648+00:00 systemd[1]: Detected architecture x86-64.
2025-08-02T11:59:50,019891+00:00 systemd[1]: Hostname set to <k8s-worker-n1>.
2025-08-02T11:59:50,139301+00:00 random: lvmconfig: uninitialized urandom read (4 bytes read)
2025-08-02T11:59:50,296093+00:00 systemd[1]: Configuration file /run/systemd/system/netplan-ovs-cleanup.service is marked world-inaccessible. This has no effect as configuration data is accessible via APIs without restrictions. Proceeding anyway.
2025-08-02T11:59:50,342079+00:00 systemd[1]: /lib/systemd/system/snapd.service:23: Unknown key name 'RestartMode' in section 'Service', ignoring.
2025-08-02T11:59:50,523606+00:00 random: systemd: uninitialized urandom read (16 bytes read)
2025-08-02T11:59:50,526743+00:00 systemd[1]: Queued start job for default target Graphical Interface.
2025-08-02T11:59:50,528172+00:00 random: systemd: uninitialized urandom read (16 bytes read)
2025-08-02T11:59:50,532246+00:00 systemd[1]: Created slice Slice /system/modprobe.
2025-08-02T11:59:50,534581+00:00 systemd[1]: Created slice Slice /system/postgresql.
2025-08-02T11:59:50,536823+00:00 systemd[1]: Created slice User and Session Slice.
2025-08-02T11:59:50,538133+00:00 systemd[1]: Started Forward Password Requests to Wall Directory Watch.
2025-08-02T11:59:50,539458+00:00 systemd[1]: Set up automount Arbitrary Executable File Formats File System Automount Point.
2025-08-02T11:59:50,540583+00:00 systemd[1]: Reached target Slice Units.
2025-08-02T11:59:50,541599+00:00 systemd[1]: Reached target Mounting snaps.
2025-08-02T11:59:50,544518+00:00 systemd[1]: Reached target Swaps.
2025-08-02T11:59:50,546988+00:00 systemd[1]: Reached target System Time Set.
2025-08-02T11:59:50,549463+00:00 systemd[1]: Reached target Local Verity Protected Volumes.
2025-08-02T11:59:50,551181+00:00 systemd[1]: Listening on Device-mapper event daemon FIFOs.
2025-08-02T11:59:50,552642+00:00 systemd[1]: Listening on LVM2 poll daemon socket.
2025-08-02T11:59:50,555642+00:00 systemd[1]: Listening on multipathd control socket.
2025-08-02T11:59:50,565947+00:00 systemd[1]: Listening on RPCbind Server Activation Socket.
2025-08-02T11:59:50,567949+00:00 systemd[1]: Listening on Syslog Socket.
2025-08-02T11:59:50,569191+00:00 systemd[1]: Listening on fsck to fsckd communication Socket.
2025-08-02T11:59:50,572997+00:00 systemd[1]: Listening on initctl Compatibility Named Pipe.
2025-08-02T11:59:50,575742+00:00 systemd[1]: Listening on Journal Audit Socket.
2025-08-02T11:59:50,577999+00:00 systemd[1]: Listening on Journal Socket (/dev/log).
2025-08-02T11:59:50,580176+00:00 systemd[1]: Listening on Journal Socket.
2025-08-02T11:59:50,584948+00:00 systemd[1]: Listening on Network Service Netlink Socket.
2025-08-02T11:59:50,587484+00:00 systemd[1]: Listening on udev Control Socket.
2025-08-02T11:59:50,588906+00:00 systemd[1]: Listening on udev Kernel Socket.
2025-08-02T11:59:50,591711+00:00 systemd[1]: Mounting Huge Pages File System...
2025-08-02T11:59:50,594434+00:00 systemd[1]: Mounting POSIX Message Queue File System...
2025-08-02T11:59:50,597182+00:00 systemd[1]: Mounting Kernel Debug File System...
2025-08-02T11:59:50,601495+00:00 systemd[1]: Mounting Kernel Trace File System...
2025-08-02T11:59:50,607636+00:00 systemd[1]: Starting Journal Service...
2025-08-02T11:59:50,611687+00:00 systemd[1]: Condition check resulted in Kernel Module supporting RPCSEC_GSS being skipped.
2025-08-02T11:59:50,615769+00:00 systemd[1]: Starting Set the console keyboard layout...
2025-08-02T11:59:50,621175+00:00 systemd[1]: Starting Create List of Static Device Nodes...
2025-08-02T11:59:50,624402+00:00 systemd[1]: Starting Monitoring of LVM2 mirrors, snapshots etc. using dmeventd or progress polling...
2025-08-02T11:59:50,627278+00:00 systemd[1]: Condition check resulted in LXD - agent being skipped.
2025-08-02T11:59:50,630272+00:00 systemd[1]: Starting Load Kernel Module configfs...
2025-08-02T11:59:50,635985+00:00 systemd[1]: Starting Load Kernel Module drm...
2025-08-02T11:59:50,640715+00:00 systemd[1]: Starting Load Kernel Module efi_pstore...
2025-08-02T11:59:50,645796+00:00 systemd[1]: Starting Load Kernel Module fuse...
2025-08-02T11:59:50,647598+00:00 systemd[1]: Condition check resulted in OpenVSwitch configuration for cleanup being skipped.
2025-08-02T11:59:50,648574+00:00 systemd[1]: Condition check resulted in File System Check on Root Device being skipped.
2025-08-02T11:59:50,654817+00:00 systemd[1]: Starting Load Kernel Modules...
2025-08-02T11:59:50,663176+00:00 systemd[1]: Starting Remount Root and Kernel File Systems...
2025-08-02T11:59:50,670576+00:00 systemd[1]: Starting Coldplug All udev Devices...
2025-08-02T11:59:50,675946+00:00 systemd[1]: Mounted Huge Pages File System.
2025-08-02T11:59:50,676062+00:00 EXT4-fs (vda2): re-mounted. Opts: (null). Quota mode: none.
2025-08-02T11:59:50,681060+00:00 systemd[1]: Mounted POSIX Message Queue File System.
2025-08-02T11:59:50,683976+00:00 systemd[1]: Mounted Kernel Debug File System.
2025-08-02T11:59:50,687210+00:00 systemd[1]: Mounted Kernel Trace File System.
2025-08-02T11:59:50,689060+00:00 bridge: filtering via arp/ip/ip6tables is no longer available by default. Update your scripts to load br_netfilter if you need this.
2025-08-02T11:59:50,693502+00:00 systemd[1]: Finished Create List of Static Device Nodes.
2025-08-02T11:59:50,693526+00:00 Bridge firewalling registered
2025-08-02T11:59:50,698135+00:00 systemd[1]: modprobe@configfs.service: Deactivated successfully.
2025-08-02T11:59:50,700391+00:00 systemd[1]: Finished Load Kernel Module configfs.
2025-08-02T11:59:50,705452+00:00 systemd[1]: modprobe@drm.service: Deactivated successfully.
2025-08-02T11:59:50,708274+00:00 systemd[1]: Finished Load Kernel Module drm.
2025-08-02T11:59:50,712543+00:00 systemd[1]: Started Journal Service.
2025-08-02T11:59:50,763907+00:00 alua: device handler registered
2025-08-02T11:59:50,766541+00:00 emc: device handler registered
2025-08-02T11:59:50,768881+00:00 systemd-journald[440]: Received client request to flush runtime journal.
2025-08-02T11:59:50,770054+00:00 rdac: device handler registered
2025-08-02T11:59:50,888213+00:00 loop0: detected capacity change from 0 to 130592
2025-08-02T11:59:50,890522+00:00 loop1: detected capacity change from 0 to 130592
2025-08-02T11:59:50,897946+00:00 loop2: detected capacity change from 0 to 178256
2025-08-02T11:59:50,904816+00:00 loop3: detected capacity change from 0 to 183096
2025-08-02T11:59:50,915417+00:00 loop4: detected capacity change from 0 to 104240
2025-08-02T11:59:50,924173+00:00 loop5: detected capacity change from 0 to 100952
2025-08-02T11:59:51,022745+00:00 audit: type=1400 audit(1754135991.020:2): apparmor="STATUS" operation="profile_load" profile="unconfined" name="lsb_release" pid=510 comm="apparmor_parser"
2025-08-02T11:59:51,024515+00:00 audit: type=1400 audit(1754135991.020:3): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/bin/man" pid=516 comm="apparmor_parser"
2025-08-02T11:59:51,024524+00:00 audit: type=1400 audit(1754135991.020:4): apparmor="STATUS" operation="profile_load" profile="unconfined" name="man_filter" pid=516 comm="apparmor_parser"
2025-08-02T11:59:51,024529+00:00 audit: type=1400 audit(1754135991.020:5): apparmor="STATUS" operation="profile_load" profile="unconfined" name="man_groff" pid=516 comm="apparmor_parser"
2025-08-02T11:59:51,024934+00:00 audit: type=1400 audit(1754135991.020:6): apparmor="STATUS" operation="profile_load" profile="unconfined" name="nvidia_modprobe" pid=511 comm="apparmor_parser"
2025-08-02T11:59:51,024942+00:00 audit: type=1400 audit(1754135991.020:7): apparmor="STATUS" operation="profile_load" profile="unconfined" name="nvidia_modprobe//kmod" pid=511 comm="apparmor_parser"
2025-08-02T11:59:51,033090+00:00 audit: type=1400 audit(1754135991.028:8): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/sbin/chronyd" pid=519 comm="apparmor_parser"
2025-08-02T11:59:51,033185+00:00 audit: type=1400 audit(1754135991.028:9): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/lib/snapd/snap-confine" pid=518 comm="apparmor_parser"
2025-08-02T11:59:51,033194+00:00 audit: type=1400 audit(1754135991.028:10): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/lib/snapd/snap-confine//mount-namespace-capture-helper" pid=518 comm="apparmor_parser"
2025-08-02T11:59:51,145370+00:00 random: systemd: uninitialized urandom read (16 bytes read)
2025-08-02T11:59:51,146715+00:00 random: systemd-journal: uninitialized urandom read (16 bytes read)
2025-08-02T11:59:51,167363+00:00 random: systemd-journal: uninitialized urandom read (16 bytes read)
2025-08-02T11:59:51,192161+00:00 RPC: Registered named UNIX socket transport module.
2025-08-02T11:59:51,192166+00:00 RPC: Registered udp transport module.
2025-08-02T11:59:51,192168+00:00 RPC: Registered tcp transport module.
2025-08-02T11:59:51,192169+00:00 RPC: Registered tcp NFSv4.1 backchannel transport module.
2025-08-02T11:59:51,550833+00:00 RAPL PMU: API unit is 2^-32 Joules, 0 fixed counters, 10737418240 ms ovfl timer
2025-08-02T11:59:51,577363+00:00 kauditd_printk_skb: 15 callbacks suppressed
2025-08-02T11:59:51,577369+00:00 audit: type=1400 audit(1754135991.572:26): apparmor="STATUS" operation="profile_load" profile="unconfined" name="snap-update-ns.lxd" pid=621 comm="apparmor_parser"
2025-08-02T11:59:51,599761+00:00 audit: type=1400 audit(1754135991.596:27): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/snap/snapd/24792/usr/lib/snapd/snap-confine" pid=620 comm="apparmor_parser"
2025-08-02T11:59:51,599777+00:00 audit: type=1400 audit(1754135991.596:28): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/snap/snapd/24792/usr/lib/snapd/snap-confine//mount-namespace-capture-helper" pid=620 comm="apparmor_parser"
2025-08-02T11:59:51,599795+00:00 audit: type=1400 audit(1754135991.596:29): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/snap/snapd/24718/usr/lib/snapd/snap-confine" pid=619 comm="apparmor_parser"
2025-08-02T11:59:51,599799+00:00 audit: type=1400 audit(1754135991.596:30): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/snap/snapd/24718/usr/lib/snapd/snap-confine//mount-namespace-capture-helper" pid=619 comm="apparmor_parser"
2025-08-02T11:59:51,601552+00:00 audit: type=1400 audit(1754135991.596:31): apparmor="STATUS" operation="profile_load" profile="unconfined" name="snap.lxd.activate" pid=622 comm="apparmor_parser"
2025-08-02T11:59:51,602999+00:00 audit: type=1400 audit(1754135991.600:32): apparmor="STATUS" operation="profile_load" profile="unconfined" name="snap.lxd.benchmark" pid=623 comm="apparmor_parser"
2025-08-02T11:59:51,625090+00:00 audit: type=1400 audit(1754135991.612:33): apparmor="STATUS" operation="profile_load" profile="unconfined" name="snap.lxd.hook.install" pid=628 comm="apparmor_parser"
2025-08-02T11:59:51,625122+00:00 audit: type=1400 audit(1754135991.612:34): apparmor="STATUS" operation="profile_load" profile="unconfined" name="snap.lxd.buginfo" pid=624 comm="apparmor_parser"
2025-08-02T11:59:51,628387+00:00 audit: type=1400 audit(1754135991.624:35): apparmor="STATUS" operation="profile_load" profile="unconfined" name="snap.lxd.lxc-to-lxd" pid=631 comm="apparmor_parser"
2025-08-02T11:59:52,445951+00:00 random: crng init done
2025-08-02T11:59:52,445958+00:00 random: 233 urandom warning(s) missed due to ratelimiting
2025-08-02T11:59:55,240036+00:00 Loading iSCSI transport class v2.0-870.
2025-08-02T12:00:04,187061+00:00 loop6: detected capacity change from 0 to 8
2025-08-02T12:00:08,714079+00:00 kauditd_printk_skb: 8 callbacks suppressed
2025-08-02T12:00:08,714088+00:00 audit: type=1400 audit(1754136008.990:44): apparmor="STATUS" operation="profile_load" profile="unconfined" name="cri-containerd.apparmor.d" pid=1509 comm="apparmor_parser"
2025-08-02T12:00:53,462155+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): cilium_net: link becomes ready
2025-08-02T12:00:53,462230+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): cilium_host: link becomes ready
2025-08-02T12:00:54,266189+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-02T12:00:59,289102+00:00 eth0: renamed from tmpf0031
2025-08-02T12:00:59,325682+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2025-08-02T12:00:59,325753+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxca5351ba4e0bb: link becomes ready
2025-08-02T12:01:00,111839+00:00 cilium_vxlan: Caught tx_queue_len zero misconfig
2025-08-02T12:01:00,193183+00:00 Initializing XFRM netlink socket
2025-08-02T12:01:25,296344+00:00 eth0: renamed from tmp2b92c
2025-08-02T12:01:25,324676+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2025-08-02T12:01:25,324793+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc3760e0fe9f16: link becomes ready
2025-08-02T12:01:50,388209+00:00 eth0: renamed from tmp22346
2025-08-02T12:01:50,411964+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2025-08-02T12:01:50,412047+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc9126acfb330f: link becomes ready
2025-08-02T12:03:34,825503+00:00 eth0: renamed from tmp898ca
2025-08-02T12:03:34,853185+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc91007210295d: link becomes ready
2025-08-02T18:37:59,717369+00:00 eth0: renamed from tmpcd209
2025-08-02T18:37:59,731536+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc98c17a76b721: link becomes ready
2025-08-02T18:39:32,935691+00:00 eth0: renamed from tmp4bd9f
2025-08-02T18:39:32,954647+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcede3395603b8: link becomes ready
2025-08-02T18:41:41,303141+00:00 eth0: renamed from tmp19527
2025-08-02T18:41:41,331401+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcb73384ba0cfb: link becomes ready
2025-08-02T18:45:14,161379+00:00 eth0: renamed from tmp0c24d
2025-08-02T18:45:14,184821+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcb44e766eaf69: link becomes ready
2025-08-03T01:34:59,650416+00:00 systemd-journald[440]: Retention time reached.
2025-08-03T05:46:23,236348+00:00 eth0: renamed from tmpee339
2025-08-03T05:46:23,289737+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc65c113775fff: link becomes ready
2025-08-03T06:00:20,572324+00:00 eth0: renamed from tmp9f206
2025-08-03T06:00:20,604368+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2025-08-03T06:00:20,604511+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc3900ba16ccb1: link becomes ready
2025-08-03T06:13:41,082037+00:00 eth0: renamed from tmp070ae
2025-08-03T06:13:41,109444+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc101b3507abaa: link becomes ready
2025-08-03T06:14:57,590560+00:00 eth0: renamed from tmpdbd30
2025-08-03T06:14:57,617997+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcad402080c2c2: link becomes ready
2025-08-03T06:16:20,944488+00:00 eth0: renamed from tmp9e8cc
2025-08-03T06:16:20,972725+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc1ecc7257ca70: link becomes ready
2025-08-03T10:43:20,850916+00:00 eth0: renamed from tmp98c21
2025-08-03T10:43:20,874608+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc00b2f640c636: link becomes ready
2025-08-03T10:46:56,018884+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T10:56:55,557436+00:00 eth0: renamed from tmp7ec8f
2025-08-03T10:56:55,585493+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcbdfa85df8a41: link becomes ready
2025-08-03T11:07:28,427524+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T11:07:28,546884+00:00 eth0: renamed from tmp3b3a5
2025-08-03T11:07:28,578051+00:00 eth0: renamed from tmp26687
2025-08-03T11:07:28,599083+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc5c558dd1459e: link becomes ready
2025-08-03T11:07:28,600339+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcdff03ecf3e1a: link becomes ready
2025-08-03T11:13:12,210013+00:00 eth0: renamed from tmpb716b
2025-08-03T11:13:12,241147+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxca491fb9c00a8: link becomes ready
2025-08-03T11:16:00,556846+00:00 eth0: renamed from tmpaf138
2025-08-03T11:16:00,584374+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2025-08-03T11:16:00,584482+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxccc39dcafd7dd: link becomes ready
2025-08-03T11:16:39,575084+00:00 eth0: renamed from tmp94c0f
2025-08-03T11:16:39,605930+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2025-08-03T11:16:39,606019+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc898f325aeb8c: link becomes ready
2025-08-03T11:19:53,697312+00:00 eth0: renamed from tmp9191a
2025-08-03T11:19:53,717568+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2025-08-03T11:19:53,717659+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc448e0eea56c0: link becomes ready
2025-08-03T11:26:38,104594+00:00 eth0: renamed from tmp8f63b
2025-08-03T11:26:38,133946+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc1be27db38ae4: link becomes ready
2025-08-03T11:41:58,848762+00:00 eth0: renamed from tmpb7283
2025-08-03T11:41:58,872409+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcbc0449327f9c: link becomes ready
2025-08-03T11:53:56,758459+00:00 eth0: renamed from tmp64158
2025-08-03T11:53:56,798383+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc27acf6e1a545: link becomes ready
2025-08-03T12:32:57,194594+00:00 eth0: renamed from tmpb2d42
2025-08-03T12:32:57,215004+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc0d13a1673008: link becomes ready
2025-08-03T12:35:14,771287+00:00 eth0: renamed from tmp018fc
2025-08-03T12:35:14,804858+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc0c6597f85f08: link becomes ready
2025-08-03T12:50:45,393945+00:00 eth0: renamed from tmp6a446
2025-08-03T12:50:45,417067+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2025-08-03T12:50:45,417181+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcb16c490a744c: link becomes ready
2025-08-03T13:04:46,471265+00:00 eth0: renamed from tmp8c647
2025-08-03T13:04:46,506166+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2025-08-03T13:04:46,506291+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcb5b02f8b684e: link becomes ready
2025-08-03T13:04:46,584148+00:00 eth0: renamed from tmp336ab
2025-08-03T13:04:46,616117+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc7e26dfab0ca5: link becomes ready
2025-08-03T13:04:51,013363+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T13:09:56,327751+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T13:33:32,430322+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T13:35:03,164866+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T13:35:48,241695+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T13:38:54,349820+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T13:40:16,888033+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T13:50:24,033056+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T13:50:33,095857+00:00 eth0: renamed from tmpf8e6e
2025-08-03T13:50:33,128134+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2025-08-03T13:50:33,128224+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc1a9e66ab2e3d: link becomes ready
2025-08-03T14:09:00,888314+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T14:09:09,684431+00:00 eth0: renamed from tmp15602
2025-08-03T14:09:09,704830+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc9f888d020df3: link becomes ready
2025-08-03T14:14:05,099871+00:00 device cilium_vxlan entered promiscuous mode
2025-08-03T14:22:04,253680+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T14:25:02,329345+00:00 printk: dmesg (58644): Attempt to access syslog with CAP_SYS_ADMIN but no CAP_SYSLOG (deprecated).
