default via 91.217.196.129 dev ens18 proto dhcp src 91.217.196.183 metric 100 
10.0.0.0/24 via 10.0.1.138 dev cilium_host proto kernel src 10.0.1.138 mtu 1450 
10.0.1.0/24 via 10.0.1.138 dev cilium_host proto kernel src 10.0.1.138 
10.0.1.138 dev cilium_host proto kernel scope link 
91.217.196.1 via 91.217.196.129 dev ens18 proto dhcp src 91.217.196.183 metric 100 
91.217.196.5 via 91.217.196.129 dev ens18 proto dhcp src 91.217.196.183 metric 100 
91.217.196.9 via 91.217.196.129 dev ens18 proto dhcp src 91.217.196.183 metric 100 
91.217.196.128/25 dev ens18 proto kernel scope link src 91.217.196.183 metric 100 
91.217.196.129 dev ens18 proto dhcp scope link src 91.217.196.183 metric 100 
