Error: failed to open IPv6 map: no such file or directory

> Error while running 'cilium-dbg bpf frag list':  exit status 1

