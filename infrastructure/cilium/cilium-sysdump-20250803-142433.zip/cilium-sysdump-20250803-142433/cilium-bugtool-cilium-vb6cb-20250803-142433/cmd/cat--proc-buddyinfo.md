Node 0, zone      DMA      0      0      0      0      0      0      0      0      1      2      2 
Node 0, zone    DMA32      3      4      0      2      2      2      4      2      4      2    744 
Node 0, zone   Normal     58     35      1    188    165    100     47     33     10      3   2062 
