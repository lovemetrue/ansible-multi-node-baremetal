markdown output at /tmp/cilium-bugtool-20250803-142505.298+0000-UTC-2522174830/cmd/cilium-debuginfo-20250803-142505.616+0000-UTC.md
json output at /tmp/cilium-bugtool-20250803-142505.298+0000-UTC-2522174830/cmd/cilium-debuginfo-20250803-142505.616+0000-UTC.json
