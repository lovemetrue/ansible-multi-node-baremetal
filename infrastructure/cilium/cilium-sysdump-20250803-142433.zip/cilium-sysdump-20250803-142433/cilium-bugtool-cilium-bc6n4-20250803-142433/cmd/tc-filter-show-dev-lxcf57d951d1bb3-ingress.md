filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf57d951d1bb3 direct-action not_in_hw id 7284 name cil_from_contai tag 7806952dab6adb9b jited 
