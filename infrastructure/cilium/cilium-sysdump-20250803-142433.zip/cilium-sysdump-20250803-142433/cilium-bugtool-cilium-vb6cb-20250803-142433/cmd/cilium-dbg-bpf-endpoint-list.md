IP ADDRESS         LOCAL ENDPOINT INFO
10.0.1.78:0        id=1178  sec_id=2284  flags=0x0000 ifindex=88  mac=66:0E:21:74:33:51 nodemac=FA:54:30:02:7F:19 parent_ifindex=0     
10.0.1.138:0       (localhost)                                                                                                         
10.0.1.184:0       id=482   sec_id=24121 flags=0x0000 ifindex=92  mac=22:B2:68:CA:D6:E9 nodemac=0A:F4:F4:A7:F1:CC parent_ifindex=0     
91.217.196.183:0   (localhost)                                                                                                         
10.0.1.237:0       id=3911  sec_id=4     flags=0x0000 ifindex=94  mac=DE:CE:89:E9:CD:5E nodemac=52:BE:14:18:05:34 parent_ifindex=0     
10.0.1.156:0       id=3132  sec_id=45704 flags=0x0000 ifindex=66  mac=7E:95:3F:3C:C8:59 nodemac=7E:D0:45:7E:3F:C1 parent_ifindex=0     
