Total: 380
TCP:   158 (estab 27, closed 93, orphaned 0, timewait 77)

Transport Total     IP        IPv6
RAW	  2         1         1        
UDP	  9         6         3        
TCP	  65        54        11       
INET	  76        61        15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q        Local Address:Port  Peer Address:PortProcess                                                                             
UNCONN 0      0             127.0.0.53%lo:53         0.0.0.0:*    uid:102 ino:15557 sk:2 cgroup:unreachable:9eb <->                                  
UNCONN 0      0      91.217.196.183%ens18:68         0.0.0.0:*    uid:101 ino:875149 sk:502b0 cgroup:unreachable:989 <->                             
UNCONN 0      0                   0.0.0.0:111        0.0.0.0:*    ino:15378 sk:5012 cgroup:unreachable:10b <->                                       
UNCONN 0      0                   0.0.0.0:8472       0.0.0.0:*    ino:32937 sk:5013 cgroup:unreachable:1af9 <->                                      
UNCONN 0      0                 127.0.0.1:323        0.0.0.0:*    ino:28703 sk:5014 cgroup:unreachable:ae0 <->                                       
UNCONN 0      0                 127.0.0.1:45265      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=54)) ino:1019048 sk:58261 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                      [::]:111           [::]:*    ino:23594 sk:5016 cgroup:unreachable:10b v6only:1 <->                              
UNCONN 0      0                      [::]:8472          [::]:*    ino:32936 sk:5017 cgroup:unreachable:1af9 v6only:1 <->                             
UNCONN 0      0                     [::1]:323           [::]:*    ino:28704 sk:5018 cgroup:unreachable:ae0 v6only:1 <->                              
