filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf9e134da9662 direct-action not_in_hw id 7273 name cil_from_contai tag 7806952dab6adb9b jited 
