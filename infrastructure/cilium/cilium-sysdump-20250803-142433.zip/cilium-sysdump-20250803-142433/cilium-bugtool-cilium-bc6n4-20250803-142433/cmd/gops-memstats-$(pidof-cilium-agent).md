alloc: 56.97MB (59734640 bytes)
total-alloc: 244.91MB (256802872 bytes)
sys: 92.23MB (96713926 bytes)
lookups: 0
mallocs: 3431642
frees: 3045379
heap-alloc: 56.97MB (59734640 bytes)
heap-sys: 79.69MB (83558400 bytes)
heap-idle: 11.39MB (11943936 bytes)
heap-in-use: 68.30MB (71614464 bytes)
heap-released: 128.00KB (131072 bytes)
heap-objects: 386263
stack-in-use: 4.31MB (4521984 bytes)
stack-sys: 4.31MB (4521984 bytes)
stack-mspan-inuse: 974.84KB (998240 bytes)
stack-mspan-sys: 1.07MB (1126080 bytes)
stack-mcache-inuse: 9.44KB (9664 bytes)
stack-mcache-sys: 15.34KB (15704 bytes)
other-sys: 1.24MB (1297502 bytes)
gc-sys: 4.30MB (4511848 bytes)
next-gc: when heap-alloc >= 78.27MB (82074730 bytes)
last-gc: 2025-08-03 14:24:15.140578647 +0000 UTC
gc-pause-total: 1.970094ms
gc-pause: 155966
gc-pause-end: 1754231055140578647
num-gc: 12
num-forced-gc: 0
gc-cpu-fraction: 0.00012813083591105718
enable-gc: true
debug-gc: false
