markdown output at /tmp/cilium-bugtool-20250803-142505.3+0000-UTC-1756777175/cmd/cilium-debuginfo-20250803-142505.556+0000-UTC.md
json output at /tmp/cilium-bugtool-20250803-142505.3+0000-UTC-1756777175/cmd/cilium-debuginfo-20250803-142505.556+0000-UTC.json
