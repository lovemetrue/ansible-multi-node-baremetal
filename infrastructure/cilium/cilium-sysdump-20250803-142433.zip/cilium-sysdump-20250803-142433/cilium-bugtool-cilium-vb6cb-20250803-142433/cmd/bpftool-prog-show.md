3: cgroup_device  tag e3dbd137be8d6168  gpl
	loaded_at 2025-08-02T11:59:50+0000  uid 0
	xlated 504B  jited 313B  memlock 4096B
4: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2025-08-02T11:59:50+0000  uid 0
	xlated 64B  jited 58B  memlock 4096B
5: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2025-08-02T11:59:50+0000  uid 0
	xlated 64B  jited 58B  memlock 4096B
6: cgroup_device  tag 0ecd07b7b633809f  gpl
	loaded_at 2025-08-02T11:59:50+0000  uid 0
	xlated 496B  jited 311B  memlock 4096B
7: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2025-08-02T11:59:50+0000  uid 0
	xlated 64B  jited 58B  memlock 4096B
8: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2025-08-02T11:59:50+0000  uid 0
	xlated 64B  jited 58B  memlock 4096B
9: cgroup_device  tag e3dbd137be8d6168  gpl
	loaded_at 2025-08-02T11:59:52+0000  uid 0
	xlated 504B  jited 313B  memlock 4096B
10: cgroup_device  tag c8b47a902f1cc68b  gpl
	loaded_at 2025-08-02T11:59:52+0000  uid 0
	xlated 464B  jited 292B  memlock 4096B
11: cgroup_device  tag 28a890580b33b0dc  gpl
	loaded_at 2025-08-02T11:59:55+0000  uid 0
	xlated 560B  jited 355B  memlock 4096B
12: cgroup_device  tag 8b9c33f36f812014  gpl
	loaded_at 2025-08-02T11:59:55+0000  uid 0
	xlated 744B  jited 451B  memlock 4096B
13: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2025-08-02T11:59:55+0000  uid 0
	xlated 64B  jited 58B  memlock 4096B
14: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2025-08-02T11:59:55+0000  uid 0
	xlated 64B  jited 58B  memlock 4096B
79: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-02T12:00:51+0000  uid 0
	xlated 440B  jited 275B  memlock 4096B
83: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-02T12:00:51+0000  uid 0
	xlated 512B  jited 332B  memlock 4096B
737: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2025-08-03T02:41:12+0000  uid 0
	xlated 64B  jited 58B  memlock 4096B
738: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2025-08-03T02:41:12+0000  uid 0
	xlated 64B  jited 58B  memlock 4096B
2462: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T12:50:48+0000  uid 0
	xlated 440B  jited 275B  memlock 4096B
2466: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T12:50:48+0000  uid 0
	xlated 512B  jited 332B  memlock 4096B
2467: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T12:50:56+0000  uid 0
	xlated 440B  jited 275B  memlock 4096B
2471: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T12:50:56+0000  uid 0
	xlated 512B  jited 332B  memlock 4096B
6264: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T13:49:41+0000  uid 0
	xlated 440B  jited 275B  memlock 4096B
6268: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T13:49:41+0000  uid 0
	xlated 512B  jited 332B  memlock 4096B
6279: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T13:49:46+0000  uid 0
	xlated 440B  jited 275B  memlock 4096B
6283: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T13:49:46+0000  uid 0
	xlated 512B  jited 332B  memlock 4096B
6502: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T13:50:36+0000  uid 0
	xlated 440B  jited 275B  memlock 4096B
6506: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T13:50:36+0000  uid 0
	xlated 512B  jited 332B  memlock 4096B
6507: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T13:50:36+0000  uid 0
	xlated 440B  jited 275B  memlock 4096B
6511: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T13:50:36+0000  uid 0
	xlated 512B  jited 332B  memlock 4096B
6512: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T13:50:36+0000  uid 0
	xlated 440B  jited 275B  memlock 4096B
6516: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T13:50:36+0000  uid 0
	xlated 512B  jited 332B  memlock 4096B
6545: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T14:08:59+0000  uid 0
	xlated 440B  jited 275B  memlock 4096B
6549: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T14:08:59+0000  uid 0
	xlated 512B  jited 332B  memlock 4096B
6555: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T14:08:59+0000  uid 0
	xlated 440B  jited 275B  memlock 4096B
6559: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T14:08:59+0000  uid 0
	xlated 512B  jited 332B  memlock 4096B
6755: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T14:09:12+0000  uid 0
	xlated 440B  jited 275B  memlock 4096B
6759: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T14:09:12+0000  uid 0
	xlated 512B  jited 332B  memlock 4096B
6760: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T14:09:13+0000  uid 0
	xlated 440B  jited 275B  memlock 4096B
6764: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T14:09:13+0000  uid 0
	xlated 512B  jited 332B  memlock 4096B
6765: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T14:21:58+0000  uid 0
	xlated 440B  jited 275B  memlock 4096B
6769: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T14:21:58+0000  uid 0
	xlated 512B  jited 332B  memlock 4096B
6798: cgroup_device  tag 3b0b81b071f088cd  gpl
	loaded_at 2025-08-03T14:22:04+0000  uid 0
	xlated 440B  jited 275B  memlock 4096B
6802: cgroup_device  tag 531db05b114e9af3
	loaded_at 2025-08-03T14:22:04+0000  uid 0
	xlated 512B  jited 332B  memlock 4096B
6832: cgroup_sock_addr  name cil_sock6_connect  tag 7d14ec854354c88d  gpl
	loaded_at 2025-08-03T14:22:08+0000  uid 0
	xlated 5960B  jited 3296B  memlock 8192B  map_ids 32,1414,24,45,43,42,33,27,31
	btf_id 3307
6833: cgroup_sock  name cil_sock_release  tag 6c18cd331b60cdea  gpl
	loaded_at 2025-08-03T14:22:08+0000  uid 0
	xlated 352B  jited 205B  memlock 4096B  map_ids 31,27
	btf_id 3308
6834: cgroup_sock_addr  name cil_sock6_getpeername  tag 0af8cba440b61a64  gpl
	loaded_at 2025-08-03T14:22:08+0000  uid 0
	xlated 3488B  jited 1937B  memlock 4096B  map_ids 24,31,32,1414,27
	btf_id 3309
6835: cgroup_sock_addr  name cil_sock6_recvmsg  tag 0af8cba440b61a64  gpl
	loaded_at 2025-08-03T14:22:08+0000  uid 0
	xlated 3488B  jited 1937B  memlock 4096B  map_ids 24,31,32,1414,27
	btf_id 3310
6836: cgroup_sock  name cil_sock4_post_bind  tag e18927aadbfcc32f  gpl
	loaded_at 2025-08-03T14:22:08+0000  uid 0
	xlated 1272B  jited 739B  memlock 4096B  map_ids 32,1414
	btf_id 3311
6837: cgroup_sock_addr  name cil_sock4_getpeername  tag cb70e624af725bd6  gpl
	loaded_at 2025-08-03T14:22:08+0000  uid 0
	xlated 3232B  jited 1811B  memlock 4096B  map_ids 24,31,32,1414,27
	btf_id 3312
6838: cgroup_sock_addr  name cil_sock4_connect  tag b4d1f03c275f5b5f  gpl
	loaded_at 2025-08-03T14:22:08+0000  uid 0
	xlated 5672B  jited 3133B  memlock 8192B  map_ids 32,1414,24,45,43,42,33,27,31
	btf_id 3313
6839: cgroup_sock_addr  name cil_sock4_sendmsg  tag 94c731766505c2e6  gpl
	loaded_at 2025-08-03T14:22:08+0000  uid 0
	xlated 5624B  jited 3098B  memlock 8192B  map_ids 32,1414,24,45,43,42,33,27,31
	btf_id 3314
6840: cgroup_sock_addr  name cil_sock4_recvmsg  tag cb70e624af725bd6  gpl
	loaded_at 2025-08-03T14:22:08+0000  uid 0
	xlated 3232B  jited 1811B  memlock 4096B  map_ids 24,31,32,1414,27
	btf_id 3315
6841: cgroup_sock_addr  name cil_sock6_sendmsg  tag 3e531e933dd62632  gpl
	loaded_at 2025-08-03T14:22:08+0000  uid 0
	xlated 5920B  jited 3258B  memlock 8192B  map_ids 32,1414,24,45,43,42,33,27,31
	btf_id 3316
6842: cgroup_sock  name cil_sock6_post_bind  tag 213689ffdf41d15a  gpl
	loaded_at 2025-08-03T14:22:08+0000  uid 0
	xlated 1680B  jited 997B  memlock 4096B  map_ids 1414,32
	btf_id 3317
6843: sched_cls  name tail_nodeport_nat_egress_ipv4  tag d8752e23b6733a56  gpl
	loaded_at 2025-08-03T14:22:10+0000  uid 0
	xlated 11512B  jited 7382B  memlock 12288B  map_ids 1418,1414,41,27,39,1282,23,24,1419
	btf_id 3319
6844: sched_cls  name cil_from_overlay  tag f1c8f8f9b4ee860f  gpl
	loaded_at 2025-08-03T14:22:10+0000  uid 0
	xlated 1096B  jited 728B  memlock 4096B  map_ids 1418,27,1419
	btf_id 3320
6845: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 7d1de4af72dfead9  gpl
	loaded_at 2025-08-03T14:22:10+0000  uid 0
	xlated 12544B  jited 7882B  memlock 16384B  map_ids 1418,41,27,39,37,38,1419,34,1414,24
	btf_id 3321
6846: sched_cls  name tail_handle_snat_fwd_ipv4  tag 17ba5b007df991fa  gpl
	loaded_at 2025-08-03T14:22:10+0000  uid 0
	xlated 12760B  jited 8501B  memlock 16384B  map_ids 1418,27,1419,41,24,39,37,38,23,1282
	btf_id 3322
6847: sched_cls  name tail_handle_ipv4  tag 953ec8d35571e699  gpl
	loaded_at 2025-08-03T14:22:10+0000  uid 0
	xlated 12232B  jited 7584B  memlock 16384B  map_ids 41,27,32,44,37,38,1419,1418,43,42,33,23,25,40,1414,35
	btf_id 3323
6848: sched_cls  name cil_to_overlay  tag 36537d5409e07eee  gpl
	loaded_at 2025-08-03T14:22:11+0000  uid 0
	xlated 4952B  jited 2948B  memlock 8192B  map_ids 1418,41,27,37,38,34,1419
	btf_id 3324
6849: sched_cls  name tail_drop_notify  tag 34144f7a29ebbeeb  gpl
	loaded_at 2025-08-03T14:22:11+0000  uid 0
	xlated 488B  jited 269B  memlock 4096B  map_ids 1418,24
	btf_id 3325
6850: sched_cls  name tail_no_service_ipv4  tag 568acc85674d4a23  gpl
	loaded_at 2025-08-03T14:22:11+0000  uid 0
	xlated 4888B  jited 2814B  memlock 8192B  map_ids 27,1419
	btf_id 3326
6891: sched_cls  name cil_from_container  tag 7806952dab6adb9b  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 816B  jited 578B  memlock 4096B  map_ids 1434,1435,27
	btf_id 3377
6892: sched_cls  name tail_ipv4_ct_ingress  tag 306a89ce00eec9cd  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 6672B  jited 4130B  memlock 8192B  map_ids 1434,27,1435,37,38,41,1433
	btf_id 3378
6893: sched_cls  name tail_handle_arp  tag 068976a41f6d23e4  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 1440B  jited 904B  memlock 4096B  map_ids 1434,27,1435
	btf_id 3379
6894: sched_cls  name cil_lxc_policy  tag aaf48831833e84f3  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 15984B  jited 9808B  memlock 16384B  map_ids 1434,27,1435,37,38,41,1433,34,1393,1278,1414,20,21,22,23,24
	btf_id 3380
6895: sched_cls  name tail_drop_notify  tag e0a1ca3d87070fd9  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 544B  jited 302B  memlock 4096B  map_ids 1434,24
	btf_id 3381
6897: sched_cls  name cil_lxc_policy_egress  tag bcf7977d3b93787c  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 16B  jited 19B  memlock 4096B
	btf_id 3383
6898: sched_cls  name tail_handle_ipv4  tag 46a54185bc2a01c6  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 19416B  jited 11868B  memlock 20480B  map_ids 1434,27,1435,37,38,41,1433,1414,24,1393,1278,20,21,22,23,25,35
	btf_id 3384
6899: sched_cls  name tail_ipv4_to_endpoint  tag 1be6ced437a9efcb  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 9456B  jited 5560B  memlock 12288B  map_ids 1414,1434,27,1433,34,1393,1278,20,21,22,23,24,37,38,1435
	btf_id 3385
6900: sched_cls  name tail_nodeport_rev_dnat_ipv4  tag 17ed938aae8f7990  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 6768B  jited 4128B  memlock 8192B  map_ids 1434,41,37,38,27,1435,34,1414,24
	btf_id 3386
6901: sched_cls  name tail_drop_notify  tag e0a1ca3d87070fd9  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 544B  jited 302B  memlock 4096B  map_ids 1436,24
	btf_id 3389
6903: sched_cls  name tail_ipv4_ct_ingress  tag 306a89ce00eec9cd  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 6672B  jited 4130B  memlock 8192B  map_ids 1442,27,1444,37,38,41,1443
	btf_id 3397
6904: sched_cls  name tail_ipv4_to_endpoint  tag 1be6ced437a9efcb  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 9456B  jited 5560B  memlock 12288B  map_ids 1414,1440,27,1441,34,1326,1278,20,21,22,23,24,37,38,1439
	btf_id 3394
6905: sched_cls  name cil_from_container  tag 7806952dab6adb9b  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 816B  jited 578B  memlock 4096B  map_ids 1440,1439,27
	btf_id 3399
6907: sched_cls  name tail_ipv4_ct_ingress  tag 306a89ce00eec9cd  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 6672B  jited 4130B  memlock 8192B  map_ids 1440,27,1439,37,38,41,1441
	btf_id 3401
6908: sched_cls  name cil_lxc_policy_egress  tag bcf7977d3b93787c  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 16B  jited 19B  memlock 4096B
	btf_id 3402
6909: sched_cls  name tail_nodeport_rev_dnat_ipv4  tag 17ed938aae8f7990  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 6768B  jited 4128B  memlock 8192B  map_ids 1440,41,37,38,27,1439,34,1414,24
	btf_id 3403
6910: sched_cls  name tail_handle_arp  tag 068976a41f6d23e4  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 1440B  jited 904B  memlock 4096B  map_ids 1440,27,1439
	btf_id 3404
6911: sched_cls  name cil_lxc_policy  tag aaf48831833e84f3  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 15984B  jited 9808B  memlock 16384B  map_ids 1436,27,1438,37,38,41,1437,34,1420,1278,1414,20,21,22,23,24
	btf_id 3396
6912: sched_cls  name cil_lxc_policy  tag aaf48831833e84f3  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 15984B  jited 9808B  memlock 16384B  map_ids 1442,27,1444,37,38,41,1443,34,1290,1278,1414,20,21,22,23,24
	btf_id 3398
6914: sched_cls  name tail_handle_arp  tag 068976a41f6d23e4  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 1440B  jited 904B  memlock 4096B  map_ids 1442,27,1444
	btf_id 3408
6915: sched_cls  name tail_nodeport_rev_dnat_ipv4  tag 17ed938aae8f7990  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 6768B  jited 4128B  memlock 8192B  map_ids 1442,41,37,38,27,1444,34,1414,24
	btf_id 3409
6916: sched_cls  name cil_from_container  tag 7806952dab6adb9b  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 816B  jited 578B  memlock 4096B  map_ids 1442,1444,27
	btf_id 3410
6917: sched_cls  name tail_ipv4_to_endpoint  tag 1be6ced437a9efcb  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 9456B  jited 5560B  memlock 12288B  map_ids 1414,1436,27,1437,34,1420,1278,20,21,22,23,24,37,38,1438
	btf_id 3406
6918: sched_cls  name tail_ipv4_ct_ingress  tag 306a89ce00eec9cd  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 6672B  jited 4130B  memlock 8192B  map_ids 1436,27,1438,37,38,41,1437
	btf_id 3412
6919: sched_cls  name tail_handle_ipv4  tag 46a54185bc2a01c6  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 19416B  jited 11868B  memlock 20480B  map_ids 1440,27,1439,37,38,41,1441,1414,24,1326,1278,20,21,22,23,25,35
	btf_id 3405
6920: sched_cls  name tail_handle_ipv4  tag 46a54185bc2a01c6  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 19416B  jited 11868B  memlock 20480B  map_ids 1442,27,1444,37,38,41,1443,1414,24,1290,1278,20,21,22,23,25,35
	btf_id 3411
6921: sched_cls  name tail_drop_notify  tag e0a1ca3d87070fd9  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 544B  jited 302B  memlock 4096B  map_ids 1442,24
	btf_id 3415
6922: sched_cls  name tail_handle_ipv4  tag 46a54185bc2a01c6  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 19416B  jited 11868B  memlock 20480B  map_ids 1436,27,1438,37,38,41,1437,1414,24,1420,1278,20,21,22,23,25,35
	btf_id 3413
6923: sched_cls  name cil_lxc_policy_egress  tag bcf7977d3b93787c  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 16B  jited 19B  memlock 4096B
	btf_id 3417
6924: sched_cls  name tail_handle_arp  tag 068976a41f6d23e4  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 1440B  jited 904B  memlock 4096B  map_ids 1436,27,1438
	btf_id 3418
6925: sched_cls  name tail_ipv4_to_endpoint  tag 1be6ced437a9efcb  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 9456B  jited 5560B  memlock 12288B  map_ids 1414,1442,27,1443,34,1290,1278,20,21,22,23,24,37,38,1444
	btf_id 3416
6926: sched_cls  name cil_lxc_policy  tag aaf48831833e84f3  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 15984B  jited 9808B  memlock 16384B  map_ids 1440,27,1439,37,38,41,1441,34,1326,1278,1414,20,21,22,23,24
	btf_id 3414
6927: sched_cls  name cil_lxc_policy_egress  tag bcf7977d3b93787c  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 16B  jited 19B  memlock 4096B
	btf_id 3420
6928: sched_cls  name tail_drop_notify  tag e0a1ca3d87070fd9  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 544B  jited 302B  memlock 4096B  map_ids 1440,24
	btf_id 3421
6929: sched_cls  name tail_nodeport_rev_dnat_ipv4  tag 17ed938aae8f7990  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 6768B  jited 4128B  memlock 8192B  map_ids 1436,41,37,38,27,1438,34,1414,24
	btf_id 3419
6930: sched_cls  name cil_from_container  tag 7806952dab6adb9b  gpl
	loaded_at 2025-08-03T14:22:15+0000  uid 0
	xlated 816B  jited 578B  memlock 4096B  map_ids 1436,1438,27
	btf_id 3422
6968: sched_cls  name tail_no_service_ipv4  tag 40e480f35731b6a4  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 4920B  jited 2832B  memlock 8192B  map_ids 1455,27,1454
	btf_id 3468
6969: sched_cls  name cil_to_host  tag 9ba01f5d812049d4  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 344B  jited 200B  memlock 4096B  map_ids 27
	btf_id 3469
6970: sched_cls  name tail_handle_snat_fwd_ipv4  tag 1d00249f6323a486  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 1168B  jited 754B  memlock 16384B  map_ids 1455,27,1454,41,39,24,37,38,23,1282
	btf_id 3470
6972: sched_cls  name tail_nodeport_nat_egress_ipv4  tag 1c6b77e9a043def6  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 12008B  jited 7715B  memlock 12288B  map_ids 1455,1414,41,27,39,1282,23,24,1454
	btf_id 3472
6973: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 6f3bfc75cd3b3049  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 13032B  jited 8124B  memlock 16384B  map_ids 1455,41,27,39,37,38,1454,34,1414,24
	btf_id 3473
6974: sched_cls  name cil_host_policy  tag bcf7977d3b93787c  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 16B  jited 19B  memlock 4096B
	btf_id 3474
6975: sched_cls  name tail_handle_ipv4_from_host  tag d824f008c1a0c344  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 4576B  jited 2658B  memlock 8192B  map_ids 1455,25,1414,27,24,1454,35
	btf_id 3475
6976: sched_cls  name tail_handle_ipv4_from_netdev  tag 5ecac7d478d5dca9  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 11328B  jited 7074B  memlock 12288B  map_ids 1455,41,27,32,44,37,38,1454,43,42,33,23,25,40
	btf_id 3476
6977: sched_cls  name tail_drop_notify  tag ed3562b4e2482b66  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 968B  jited 559B  memlock 4096B  map_ids 1455,24
	btf_id 3477
6978: sched_cls  name cil_from_host  tag c4dd7859434f8299  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 2488B  jited 1633B  memlock 4096B  map_ids 1455,27,1414,1454
	btf_id 3478
6980: sched_cls  name tail_handle_ipv4_from_host  tag d824f008c1a0c344  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 4576B  jited 2658B  memlock 8192B  map_ids 1457,25,1414,27,24,1459,35
	btf_id 3482
6981: sched_cls  name tail_handle_ipv4_from_netdev  tag 5ecac7d478d5dca9  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 11328B  jited 7074B  memlock 12288B  map_ids 1457,41,27,32,44,37,38,1459,43,42,33,23,25,40
	btf_id 3483
6982: sched_cls  name tail_drop_notify  tag ed3562b4e2482b66  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 968B  jited 559B  memlock 4096B  map_ids 1457,24
	btf_id 3484
6985: sched_cls  name tail_nodeport_nat_egress_ipv4  tag 1c6b77e9a043def6  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 12008B  jited 7715B  memlock 12288B  map_ids 1457,1414,41,27,39,1282,23,24,1459
	btf_id 3487
6987: sched_cls  name tail_no_service_ipv4  tag 40e480f35731b6a4  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 4920B  jited 2832B  memlock 8192B  map_ids 1457,27,1459
	btf_id 3489
6988: sched_cls  name cil_to_host  tag 9ba01f5d812049d4  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 344B  jited 200B  memlock 4096B  map_ids 27
	btf_id 3490
6989: sched_cls  name tail_handle_snat_fwd_ipv4  tag 1d00249f6323a486  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 1168B  jited 754B  memlock 16384B  map_ids 1457,27,1459,41,39,24,37,38,23,1282
	btf_id 3491
6990: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 6f3bfc75cd3b3049  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 13032B  jited 8124B  memlock 16384B  map_ids 1457,41,27,39,37,38,1459,34,1414,24
	btf_id 3492
6991: sched_cls  name tail_no_service_ipv4  tag 40e480f35731b6a4  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 4920B  jited 2832B  memlock 8192B  map_ids 1460,27,1462
	btf_id 3495
6992: sched_cls  name tail_handle_snat_fwd_ipv4  tag 1d00249f6323a486  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 13032B  jited 8730B  memlock 16384B  map_ids 1460,27,1462,41,39,24,37,38,23,1282
	btf_id 3496
6993: sched_cls  name tail_handle_ipv4_from_netdev  tag 5ecac7d478d5dca9  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 11328B  jited 7074B  memlock 12288B  map_ids 1460,41,27,32,44,37,38,1462,43,42,33,23,25,40
	btf_id 3497
6994: sched_cls  name cil_to_netdev  tag 89db1204a3c229a4  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 7088B  jited 4372B  memlock 8192B  map_ids 1460,41,27,37,38,34,24,1462
	btf_id 3498
6997: sched_cls  name tail_drop_notify  tag ed3562b4e2482b66  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 968B  jited 559B  memlock 4096B  map_ids 1460,24
	btf_id 3501
6999: sched_cls  name tail_nodeport_nat_egress_ipv4  tag 1c6b77e9a043def6  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 12008B  jited 7715B  memlock 12288B  map_ids 1460,1414,41,27,39,1282,23,24,1462
	btf_id 3503
7000: sched_cls  name cil_from_netdev  tag eed8d56b13232c39  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 2352B  jited 1583B  memlock 4096B  map_ids 1460,27,1462,1414
	btf_id 3504
7001: sched_cls  name tail_nodeport_nat_ingress_ipv4  tag 6f3bfc75cd3b3049  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 13032B  jited 8124B  memlock 16384B  map_ids 1460,41,27,39,37,38,1462,34,1414,24
	btf_id 3505
7002: sched_cls  name tail_handle_ipv4_from_host  tag d824f008c1a0c344  gpl
	loaded_at 2025-08-03T14:22:19+0000  uid 0
	xlated 4576B  jited 2658B  memlock 8192B  map_ids 1460,25,1414,27,24,1462,35
	btf_id 3506
