Endpoint ID: 482
Path: /sys/fs/bpf/tc/globals/cilium_policy_v2_00482

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    -       -         0        
Allow    Ingress     1          ANY          NONE         disabled    88487   1017      0        
Allow    Egress      0          ANY          NONE         disabled    17382   177       0        


Endpoint ID: 1178
Path: /sys/fs/bpf/tc/globals/cilium_policy_v2_01178

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    -        -         0        
Allow    Ingress     1          ANY          NONE         disabled    200073   2331      0        
Allow    Egress      0          ANY          NONE         disabled    -        -         0        


Endpoint ID: 3132
Path: /sys/fs/bpf/tc/globals/cilium_policy_v2_03132

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    -         -         0        
Allow    Ingress     1          ANY          NONE         disabled    1079736   5264      0        
Allow    Egress      0          ANY          NONE         disabled    126803    1313      0        


Endpoint ID: 3788
Path: /sys/fs/bpf/tc/globals/cilium_policy_v2_03788

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    -       -         0        
Allow    Egress      0          ANY          NONE         disabled    -       -         0        


Endpoint ID: 3911
Path: /sys/fs/bpf/tc/globals/cilium_policy_v2_03911

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    -       -         0        
Allow    Ingress     1          ANY          NONE         disabled    1864    22        0        
Allow    Egress      0          ANY          NONE         disabled    -       -         0        


