key: e2 01 00 00  value: ee 1a 00 00
key: 9a 04 00 00  value: 0e 1b 00 00
key: 3c 0c 00 00  value: 00 1b 00 00
key: cc 0e 00 00  value: 3e 1b 00 00
key: 47 0f 00 00  value: ff 1a 00 00
Found 5 elements
