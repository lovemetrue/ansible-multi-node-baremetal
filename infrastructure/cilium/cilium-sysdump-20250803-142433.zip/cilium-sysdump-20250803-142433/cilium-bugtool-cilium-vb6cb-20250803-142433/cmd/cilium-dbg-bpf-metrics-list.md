REASON                                            DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                                         INGRESS     1089      70008       1172   bpf_host.c
Interface                                         INGRESS     1633341   91467096    1121   bpf_host.c
Interface                                         INGRESS     27944     16451507    1156   bpf_host.c
Interface                                         INGRESS     37330     2090480     1075   bpf_host.c
Interface                                         INGRESS     48570     3121254     1218   bpf_host.c
Interface                                         INGRESS     680940    575129212   1202   bpf_host.c
LB: sock cgroup: Reverse entry delete succeeded   EGRESS      7         0           1256   bpf_sock.c
Success                                           EGRESS      1025      67654       1808   bpf_host.c
Success                                           EGRESS      10369     2126317     1344   bpf_lxc.c
Success                                           EGRESS      12576     900160      53     encap.h
Success                                           EGRESS      15680     3069680     459    nodeport_egress.h
Success                                           EGRESS      157573    17054816    1347   bpf_lxc.c
Success                                           EGRESS      168       11928       35     encap.h
Success                                           EGRESS      17097     1719682     1659   bpf_host.c
Success                                           EGRESS      269       24598       1648   bpf_host.c
Success                                           EGRESS      398640    52787818    293    trace.h
Success                                           EGRESS      4955      13207165    75     local_delivery.h
Success                                           EGRESS      5247      411194      1819   bpf_host.c
Success                                           INGRESS     11828     3125987     122    local_delivery.h
Success                                           INGRESS     11828     3125987     2030   bpf_lxc.c
Success                                           INGRESS     175040    33546238    75     local_delivery.h
Success                                           INGRESS     179995    46753403    293    trace.h
Unsupported L3 protocol                           EGRESS      376       28148       1544   bpf_lxc.c
