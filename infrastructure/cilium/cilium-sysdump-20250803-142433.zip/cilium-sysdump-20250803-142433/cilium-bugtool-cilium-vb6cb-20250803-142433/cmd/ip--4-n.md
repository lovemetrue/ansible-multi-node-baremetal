91.217.196.189 dev ens18 lladdr bc:24:11:57:4e:fb extern_learn REACHABLE 
91.217.196.129 dev ens18 lladdr a0:1d:48:ef:7a:48 REACHABLE 
10.0.1.237 dev lxc_health lladdr de:ce:89:e9:cd:5e STALE 
