[
  {
    "containers": [
      {
        "cgroup-id": 27210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0fa3b2b0_04ca_40e5_aecb_8e6d519bc870.slice/cri-containerd-37455eb8e1398925aadaba9e58ff51a8db392a79f79dbd3991eab7591e622fe1.scope"
      }
    ],
    "ips": [
      "91.217.196.183"
    ],
    "name": "cilium-vb6cb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 26494,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5c296c83_a595_4cfc_b8d8_158cf9a53989.slice/cri-containerd-f656dd5471c332ef913ed159fa6c8b5bbec394115a8b4428fab407cc453b4e69.scope"
      }
    ],
    "ips": [
      "10.0.1.184"
    ],
    "name": "coredns-54558b56c7-tsmph",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 25421,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod77da1804_ffec_4f8f_8cf4_b7a8c47e6790.slice/cri-containerd-4bbb016ed8433c3d2335f5c6a3c22b6a07c8e346b2da59fce8cfd41ed1086e39.scope"
      },
      {
        "cgroup-id": 25356,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod77da1804_ffec_4f8f_8cf4_b7a8c47e6790.slice/cri-containerd-4cb2ba7f49a12f28ac27580adde699844827e1dd3c18647e30ec62804f84ee51.scope"
      }
    ],
    "ips": [
      "10.0.1.78"
    ],
    "name": "hubble-ui-655f947f96-bdmvs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 17471,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9f15bf7_74eb_48ec_9be9_381806bd73fa.slice/cri-containerd-c131638f60c6d38655292f6b95a79bcaf8420e4784cdb7388878fb637946dede.scope"
      }
    ],
    "ips": [
      "10.0.1.156"
    ],
    "name": "metrics-server-7f4c46496-hwgxn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 26234,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b9c30db_9b98_42e7_a5cf_d012c0baaef4.slice/cri-containerd-1c092d1dac51a375105d32c9dd64ab86a311241e5d262acd5fd34544a35725ee.scope"
      }
    ],
    "ips": [
      "91.217.196.183"
    ],
    "name": "cilium-envoy-rwbsf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 24706,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8aa9e879_8356_4493_87f8_347274653b1b.slice/cri-containerd-b2afab111bcfaa0d303488f888f4cb6741fb2bcb7f77473c9178452f702494d8.scope"
      }
    ],
    "ips": [
      "91.217.196.183"
    ],
    "name": "cilium-operator-64ddb69dfd-slbxs",
    "namespace": "kube-system"
  }
]

