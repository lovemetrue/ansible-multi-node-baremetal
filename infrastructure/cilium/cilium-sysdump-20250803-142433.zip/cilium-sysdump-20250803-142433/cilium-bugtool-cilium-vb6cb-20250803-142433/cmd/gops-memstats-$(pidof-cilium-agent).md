alloc: 55.18MB (57856624 bytes)
total-alloc: 239.90MB (251548648 bytes)
sys: 92.73MB (97238214 bytes)
lookups: 0
mallocs: 3362773
frees: 2998212
heap-alloc: 55.18MB (57856624 bytes)
heap-sys: 79.69MB (83558400 bytes)
heap-idle: 12.94MB (13565952 bytes)
heap-in-use: 66.75MB (69992448 bytes)
heap-released: 2.89MB (3031040 bytes)
heap-objects: 364561
stack-in-use: 4.31MB (4521984 bytes)
stack-sys: 4.31MB (4521984 bytes)
stack-mspan-inuse: 949.22KB (972000 bytes)
stack-mspan-sys: 1.06MB (1109760 bytes)
stack-mcache-inuse: 11.80KB (12080 bytes)
stack-mcache-sys: 15.34KB (15704 bytes)
other-sys: 1.77MB (1850758 bytes)
gc-sys: 4.28MB (4491224 bytes)
next-gc: when heap-alloc >= 77.10MB (80848322 bytes)
last-gc: 2025-08-03 14:24:10.413841654 +0000 UTC
gc-pause-total: 2.355928ms
gc-pause: 173607
gc-pause-end: 1754231050413841654
num-gc: 12
num-forced-gc: 0
gc-cpu-fraction: 0.00015164507839674667
enable-gc: true
debug-gc: false
