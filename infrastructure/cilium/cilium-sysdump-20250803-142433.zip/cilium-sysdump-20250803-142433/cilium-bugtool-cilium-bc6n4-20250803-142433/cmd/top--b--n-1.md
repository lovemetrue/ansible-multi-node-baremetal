top - 14:25:05 up 1 day,  2:35,  0 user,  load average: 0.30, 0.27, 0.27
Tasks:  14 total,   8 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 45.5 us, 40.3 sy,  0.0 ni, 13.0 id,  0.0 wa,  0.0 hi,  0.0 si,  1.3 st 
MiB Mem :  11956.3 total,   3620.7 free,   1890.3 used,   6778.1 buff/cache     
MiB Swap:      0.0 total,      0.0 free,      0.0 used.  10066.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    589 root      20   0    4244   1232   1100 R 100.0   0.0   0:00.12 bpftool
    616 root      20   0   37464  32592   2316 R  70.0   0.3   0:00.07 bpftool
    618 root      20   0    2840   1020    932 R  60.0   0.0   0:00.06 cat
    626 root      20   0 1323664  54900  45784 R  40.0   0.4   0:00.04 cilium-+
    627 root      20   0 1323664  54044  45144 R  40.0   0.4   0:00.04 cilium-+
    628 root      20   0 1323664  53824  45272 R  40.0   0.4   0:00.04 cilium-+
    629 root      20   0 1323152  47508  39768 R  40.0   0.4   0:00.04 cilium-+
      1 root      20   0 1428572 183516  95528 S  10.0   1.5   0:11.67 cilium-+
    236 root      20   0 1229876   3512   2876 S   0.0   0.0   0:00.00 cilium-+
    252 root      20   0    2800   1132   1036 S   0.0   0.0   0:00.00 sh
    258 root      20   0    2800    108      0 S   0.0   0.0   0:00.00 sh
    259 root      20   0    8552   7968   3444 S   0.0   0.1   0:00.04 bash
    511 root      20   0 1238140  15468   9552 S   0.0   0.1   0:00.07 cilium-+
    546 root      20   0    8716   4716   2832 R   0.0   0.0   0:00.00 top
