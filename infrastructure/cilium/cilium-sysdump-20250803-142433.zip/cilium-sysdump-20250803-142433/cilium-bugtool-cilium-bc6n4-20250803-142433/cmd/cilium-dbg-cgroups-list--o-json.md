[
  {
    "containers": [
      {
        "cgroup-id": 19057,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1fd2ecd0_8143_4d0e_b956_c31c41d7b357.slice/cri-containerd-ff48e486c09f35162890c974360fe8b0801d982fbd617f9b6688cc04b293e443.scope"
      }
    ],
    "ips": [
      "10.0.0.236"
    ],
    "name": "dnsutils",
    "namespace": "default"
  },
  {
    "containers": [
      {
        "cgroup-id": 27883,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4771fb02_f200_4c27_aeb4_526c00690401.slice/cri-containerd-3250500b60c0573f50536085267a1efcf8a0aaaa04d79c9227b48070624b9c72.scope"
      }
    ],
    "ips": [
      "91.217.196.189"
    ],
    "name": "cilium-envoy-rrgx6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 26680,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod545bda2f_3cd2_4a35_b99e_c08a0b093a14.slice/cri-containerd-1f22111b49718be924b803ba98c9b073a961b5f6902b13cd64b954a135d54790.scope"
      }
    ],
    "ips": [
      "91.217.196.189"
    ],
    "name": "cilium-operator-64ddb69dfd-rq4tf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 28241,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podffad25fa_987f_4ff7_b637_8ab5ba2681e2.slice/cri-containerd-12367db7148356bdfa30774e2a24117c5ce53ff2e18ead09f4eef17e1afa4377.scope"
      }
    ],
    "ips": [
      "10.0.0.220"
    ],
    "name": "coredns-54558b56c7-zth5g",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 28371,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6678686c_9821_4022_bd18_239c984e187a.slice/cri-containerd-a949ab4bc73d5f1eb53b6cbca62794d9a581e78b4224a1e6153fc317a7ebc00f.scope"
      }
    ],
    "ips": [
      "10.0.0.43"
    ],
    "name": "hubble-relay-6b7b5877f4-vfr4c",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 28956,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1a3e0fe1_c520_4de5_baa9_58dfecf2e694.slice/cri-containerd-3cf0e4b01fe400cecb408cdb70f9b40a90d4838f2d6b65f297f6be529c15e062.scope"
      }
    ],
    "ips": [
      "91.217.196.189"
    ],
    "name": "cilium-bc6n4",
    "namespace": "kube-system"
  }
]

