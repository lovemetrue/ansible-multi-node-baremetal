91.217.196.183 dev ens18 lladdr bc:24:11:70:10:81 extern_learn REACHABLE 
10.0.0.203 dev lxc_health lladdr 86:21:73:08:46:3d STALE 
10.0.0.236 dev lxcf57d951d1bb3 lladdr 3a:c3:97:18:be:fc STALE 
91.217.196.129 dev ens18 lladdr a0:1d:48:ef:7a:48 REACHABLE 
