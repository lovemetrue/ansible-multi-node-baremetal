Endpoint ID: 33
Path: /sys/fs/bpf/tc/globals/cilium_policy_v2_00033

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1146    10        0        
Allow    Ingress     1          ANY          NONE         disabled    87760   1013      0        
Allow    Egress      0          ANY          NONE         disabled    15041   159       0        


Endpoint ID: 274
Path: /sys/fs/bpf/tc/globals/cilium_policy_v2_00274

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    -        -         0        
Allow    Ingress     1          ANY          NONE         disabled    459056   5128      0        
Allow    Egress      0          ANY          NONE         disabled    25004    203       0        


Endpoint ID: 342
Path: /sys/fs/bpf/tc/globals/cilium_policy_v2_00342

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    -       -         0        
Allow    Egress      0          ANY          NONE         disabled    -       -         0        


Endpoint ID: 398
Path: /sys/fs/bpf/tc/globals/cilium_policy_v2_00398

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    -       -         0        
Allow    Ingress     1          ANY          NONE         disabled    -       -         0        
Allow    Egress      0          ANY          NONE         disabled    3536    35        0        


Endpoint ID: 2838
Path: /sys/fs/bpf/tc/globals/cilium_policy_v2_02838

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    -       -         0        
Allow    Ingress     1          ANY          NONE         disabled    1798    21        0        
Allow    Egress      0          ANY          NONE         disabled    -       -         0        


