2025-08-02T11:49:39,083109+00:00 Linux version 5.15.0-142-generic (buildd@lcy02-amd64-032) (gcc (Ubuntu 11.4.0-1ubuntu1~22.04) 11.4.0, GNU ld (GNU Binutils for Ubuntu) 2.38) #152-Ubuntu SMP Mon May 19 10:54:31 UTC 2025 (Ubuntu 5.15.0-142.152-generic 5.15.180)
2025-08-02T11:49:39,083109+00:00 Command line: BOOT_IMAGE=/boot/vmlinuz-5.15.0-142-generic root=UUID=79806a87-a8ae-4e6d-9c8c-9458e92773db ro
2025-08-02T11:49:39,083109+00:00 KERNEL supported cpus:
2025-08-02T11:49:39,083109+00:00   Intel GenuineIntel
2025-08-02T11:49:39,083109+00:00   AMD AuthenticAMD
2025-08-02T11:49:39,083109+00:00   Hygon HygonGenuine
2025-08-02T11:49:39,083109+00:00   Centaur CentaurHauls
2025-08-02T11:49:39,083109+00:00   zhaoxin   Shanghai  
2025-08-02T11:49:39,083109+00:00 BIOS-provided physical RAM map:
2025-08-02T11:49:39,083109+00:00 BIOS-e820: [mem 0x0000000000000000-0x000000000009fbff] usable
2025-08-02T11:49:39,083109+00:00 BIOS-e820: [mem 0x000000000009fc00-0x000000000009ffff] reserved
2025-08-02T11:49:39,083109+00:00 BIOS-e820: [mem 0x00000000000f0000-0x00000000000fffff] reserved
2025-08-02T11:49:39,083109+00:00 BIOS-e820: [mem 0x0000000000100000-0x00000000bffd9fff] usable
2025-08-02T11:49:39,083109+00:00 BIOS-e820: [mem 0x00000000bffda000-0x00000000bfffffff] reserved
2025-08-02T11:49:39,083109+00:00 BIOS-e820: [mem 0x00000000feffc000-0x00000000feffffff] reserved
2025-08-02T11:49:39,083109+00:00 BIOS-e820: [mem 0x00000000fffc0000-0x00000000ffffffff] reserved
2025-08-02T11:49:39,083109+00:00 BIOS-e820: [mem 0x0000000100000000-0x000000033fffffff] usable
2025-08-02T11:49:39,083109+00:00 NX (Execute Disable) protection: active
2025-08-02T11:49:39,083109+00:00 SMBIOS 2.8 present.
2025-08-02T11:49:39,083109+00:00 DMI: QEMU Standard PC (i440FX + PIIX, 1996), BIOS rel-1.16.3-0-ga6ed6b701f0a-prebuilt.qemu.org 04/01/2014
2025-08-02T11:49:39,083109+00:00 Hypervisor detected: KVM
2025-08-02T11:49:39,083109+00:00 kvm-clock: Using msrs 4b564d01 and 4b564d00
2025-08-02T11:49:39,083109+00:00 kvm-clock: cpu 0, msr 2fda01001, primary cpu clock
2025-08-02T11:49:39,083112+00:00 kvm-clock: using sched offset of 150339486307867 cycles
2025-08-02T11:49:39,083116+00:00 clocksource: kvm-clock: mask: 0xffffffffffffffff max_cycles: 0x1cd42e4dffb, max_idle_ns: 881590591483 ns
2025-08-02T11:49:39,083121+00:00 tsc: Detected 2299.996 MHz processor
2025-08-02T11:49:39,084388+00:00 e820: update [mem 0x00000000-0x00000fff] usable ==> reserved
2025-08-02T11:49:39,084394+00:00 e820: remove [mem 0x000a0000-0x000fffff] usable
2025-08-02T11:49:39,084400+00:00 last_pfn = 0x340000 max_arch_pfn = 0x400000000
2025-08-02T11:49:39,084451+00:00 x86/PAT: Configuration [0-7]: WB  WC  UC- UC  WB  WP  UC- WT  
2025-08-02T11:49:39,084462+00:00 last_pfn = 0xbffda max_arch_pfn = 0x400000000
2025-08-02T11:49:39,095651+00:00 found SMP MP-table at [mem 0x000f5430-0x000f543f]
2025-08-02T11:49:39,095700+00:00 Using GB pages for direct mapping
2025-08-02T11:49:39,095899+00:00 RAMDISK: [mem 0x2ae41000-0x31717fff]
2025-08-02T11:49:39,095907+00:00 ACPI: Early table checksum verification disabled
2025-08-02T11:49:39,095913+00:00 ACPI: RSDP 0x00000000000F51F0 000014 (v00 BOCHS )
2025-08-02T11:49:39,095919+00:00 ACPI: RSDT 0x00000000BFFE3E11 000038 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2025-08-02T11:49:39,095927+00:00 ACPI: FACP 0x00000000BFFE3BC3 000074 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2025-08-02T11:49:39,095936+00:00 ACPI: DSDT 0x00000000BFFDF040 004B83 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2025-08-02T11:49:39,095941+00:00 ACPI: FACS 0x00000000BFFDF000 000040
2025-08-02T11:49:39,095946+00:00 ACPI: APIC 0x00000000BFFE3C37 0000B0 (v03 BOCHS  BXPC     00000001 BXPC 00000001)
2025-08-02T11:49:39,095951+00:00 ACPI: SSDT 0x00000000BFFE3CE7 0000CA (v01 BOCHS  VMGENID  00000001 BXPC 00000001)
2025-08-02T11:49:39,095957+00:00 ACPI: HPET 0x00000000BFFE3DB1 000038 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2025-08-02T11:49:39,095962+00:00 ACPI: WAET 0x00000000BFFE3DE9 000028 (v01 BOCHS  BXPC     00000001 BXPC 00000001)
2025-08-02T11:49:39,095966+00:00 ACPI: Reserving FACP table memory at [mem 0xbffe3bc3-0xbffe3c36]
2025-08-02T11:49:39,095968+00:00 ACPI: Reserving DSDT table memory at [mem 0xbffdf040-0xbffe3bc2]
2025-08-02T11:49:39,095970+00:00 ACPI: Reserving FACS table memory at [mem 0xbffdf000-0xbffdf03f]
2025-08-02T11:49:39,095971+00:00 ACPI: Reserving APIC table memory at [mem 0xbffe3c37-0xbffe3ce6]
2025-08-02T11:49:39,095972+00:00 ACPI: Reserving SSDT table memory at [mem 0xbffe3ce7-0xbffe3db0]
2025-08-02T11:49:39,095974+00:00 ACPI: Reserving HPET table memory at [mem 0xbffe3db1-0xbffe3de8]
2025-08-02T11:49:39,095975+00:00 ACPI: Reserving WAET table memory at [mem 0xbffe3de9-0xbffe3e10]
2025-08-02T11:49:39,096417+00:00 No NUMA configuration found
2025-08-02T11:49:39,096419+00:00 Faking a node at [mem 0x0000000000000000-0x000000033fffffff]
2025-08-02T11:49:39,096431+00:00 NODE_DATA(0) allocated [mem 0x33ffd6000-0x33fffffff]
2025-08-02T11:49:39,096918+00:00 Zone ranges:
2025-08-02T11:49:39,096921+00:00   DMA      [mem 0x0000000000001000-0x0000000000ffffff]
2025-08-02T11:49:39,096924+00:00   DMA32    [mem 0x0000000001000000-0x00000000ffffffff]
2025-08-02T11:49:39,096926+00:00   Normal   [mem 0x0000000100000000-0x000000033fffffff]
2025-08-02T11:49:39,096928+00:00   Device   empty
2025-08-02T11:49:39,096930+00:00 Movable zone start for each node
2025-08-02T11:49:39,096933+00:00 Early memory node ranges
2025-08-02T11:49:39,096934+00:00   node   0: [mem 0x0000000000001000-0x000000000009efff]
2025-08-02T11:49:39,096936+00:00   node   0: [mem 0x0000000000100000-0x00000000bffd9fff]
2025-08-02T11:49:39,096938+00:00   node   0: [mem 0x0000000100000000-0x000000033fffffff]
2025-08-02T11:49:39,096941+00:00 Initmem setup node 0 [mem 0x0000000000001000-0x000000033fffffff]
2025-08-02T11:49:39,096956+00:00 On node 0, zone DMA: 1 pages in unavailable ranges
2025-08-02T11:49:39,097045+00:00 On node 0, zone DMA: 97 pages in unavailable ranges
2025-08-02T11:49:39,144075+00:00 On node 0, zone Normal: 38 pages in unavailable ranges
2025-08-02T11:49:39,145570+00:00 ACPI: PM-Timer IO Port: 0x608
2025-08-02T11:49:39,145593+00:00 ACPI: LAPIC_NMI (acpi_id[0xff] dfl dfl lint[0x1])
2025-08-02T11:49:39,145649+00:00 IOAPIC[0]: apic_id 0, version 17, address 0xfec00000, GSI 0-23
2025-08-02T11:49:39,145655+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 0 global_irq 2 dfl dfl)
2025-08-02T11:49:39,145657+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 5 global_irq 5 high level)
2025-08-02T11:49:39,145659+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 9 global_irq 9 high level)
2025-08-02T11:49:39,145661+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 10 global_irq 10 high level)
2025-08-02T11:49:39,145663+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 11 global_irq 11 high level)
2025-08-02T11:49:39,145668+00:00 ACPI: Using ACPI (MADT) for SMP configuration information
2025-08-02T11:49:39,145671+00:00 ACPI: HPET id: 0x8086a201 base: 0xfed00000
2025-08-02T11:49:39,145677+00:00 TSC deadline timer available
2025-08-02T11:49:39,145679+00:00 smpboot: Allowing 8 CPUs, 0 hotplug CPUs
2025-08-02T11:49:39,145703+00:00 kvm-guest: KVM setup pv remote TLB flush
2025-08-02T11:49:39,145708+00:00 kvm-guest: setup PV sched yield
2025-08-02T11:49:39,145717+00:00 PM: hibernation: Registered nosave memory: [mem 0x00000000-0x00000fff]
2025-08-02T11:49:39,145720+00:00 PM: hibernation: Registered nosave memory: [mem 0x0009f000-0x0009ffff]
2025-08-02T11:49:39,145722+00:00 PM: hibernation: Registered nosave memory: [mem 0x000a0000-0x000effff]
2025-08-02T11:49:39,145723+00:00 PM: hibernation: Registered nosave memory: [mem 0x000f0000-0x000fffff]
2025-08-02T11:49:39,145725+00:00 PM: hibernation: Registered nosave memory: [mem 0xbffda000-0xbfffffff]
2025-08-02T11:49:39,145726+00:00 PM: hibernation: Registered nosave memory: [mem 0xc0000000-0xfeffbfff]
2025-08-02T11:49:39,145727+00:00 PM: hibernation: Registered nosave memory: [mem 0xfeffc000-0xfeffffff]
2025-08-02T11:49:39,145729+00:00 PM: hibernation: Registered nosave memory: [mem 0xff000000-0xfffbffff]
2025-08-02T11:49:39,145730+00:00 PM: hibernation: Registered nosave memory: [mem 0xfffc0000-0xffffffff]
2025-08-02T11:49:39,145732+00:00 [mem 0xc0000000-0xfeffbfff] available for PCI devices
2025-08-02T11:49:39,145735+00:00 Booting paravirtualized kernel on KVM
2025-08-02T11:49:39,145738+00:00 clocksource: refined-jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 7645519600211568 ns
2025-08-02T11:49:39,145746+00:00 setup_percpu: NR_CPUS:8192 nr_cpumask_bits:8 nr_cpu_ids:8 nr_node_ids:1
2025-08-02T11:49:39,146206+00:00 percpu: Embedded 62 pages/cpu s217088 r8192 d28672 u262144
2025-08-02T11:49:39,146213+00:00 pcpu-alloc: s217088 r8192 d28672 u262144 alloc=1*2097152
2025-08-02T11:49:39,146217+00:00 pcpu-alloc: [0] 0 1 2 3 4 5 6 7 
2025-08-02T11:49:39,146251+00:00 kvm-guest: setup async PF for cpu 0
2025-08-02T11:49:39,146257+00:00 kvm-guest: stealtime: cpu 0, msr 333c34080
2025-08-02T11:49:39,146262+00:00 kvm-guest: PV spinlocks enabled
2025-08-02T11:49:39,146264+00:00 PV qspinlock hash table entries: 256 (order: 0, 4096 bytes, linear)
2025-08-02T11:49:39,146275+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 3096282
2025-08-02T11:49:39,146277+00:00 Policy zone: Normal
2025-08-02T11:49:39,146279+00:00 Kernel command line: BOOT_IMAGE=/boot/vmlinuz-5.15.0-142-generic root=UUID=79806a87-a8ae-4e6d-9c8c-9458e92773db ro
2025-08-02T11:49:39,146334+00:00 Unknown kernel command line parameters "BOOT_IMAGE=/boot/vmlinuz-5.15.0-142-generic", will be passed to user space.
2025-08-02T11:49:39,148985+00:00 Dentry cache hash table entries: 2097152 (order: 12, 16777216 bytes, linear)
2025-08-02T11:49:39,150284+00:00 Inode-cache hash table entries: 1048576 (order: 11, 8388608 bytes, linear)
2025-08-02T11:49:39,150523+00:00 mem auto-init: stack:off, heap alloc:on, heap free:off
2025-08-02T11:49:39,205869+00:00 Memory: 12126948K/12582368K available (16392K kernel code, 4400K rwdata, 10980K rodata, 3284K init, 18780K bss, 455160K reserved, 0K cma-reserved)
2025-08-02T11:49:39,206229+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=8, Nodes=1
2025-08-02T11:49:39,206249+00:00 Kernel/User page tables isolation: enabled
2025-08-02T11:49:39,206291+00:00 ftrace: allocating 50838 entries in 199 pages
2025-08-02T11:49:39,234363+00:00 ftrace: allocated 199 pages with 5 groups
2025-08-02T11:49:39,234615+00:00 rcu: Hierarchical RCU implementation.
2025-08-02T11:49:39,234619+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=8192 to nr_cpu_ids=8.
2025-08-02T11:49:39,234621+00:00 	Rude variant of Tasks RCU enabled.
2025-08-02T11:49:39,234623+00:00 	Tracing variant of Tasks RCU enabled.
2025-08-02T11:49:39,234624+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 25 jiffies.
2025-08-02T11:49:39,234626+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=8
2025-08-02T11:49:39,240126+00:00 NR_IRQS: 524544, nr_irqs: 488, preallocated irqs: 16
2025-08-02T11:49:39,240360+00:00 random: crng init done
2025-08-02T11:49:39,240422+00:00 Console: colour dummy device 80x25
2025-08-02T11:49:39,240664+00:00 printk: console [tty0] enabled
2025-08-02T11:49:39,240709+00:00 ACPI: Core revision 20210730
2025-08-02T11:49:39,241015+00:00 clocksource: hpet: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 19112604467 ns
2025-08-02T11:49:39,241172+00:00 APIC: Switch to symmetric I/O mode setup
2025-08-02T11:49:39,241544+00:00 x2apic enabled
2025-08-02T11:49:39,241902+00:00 Switched APIC routing to physical x2apic.
2025-08-02T11:49:39,241911+00:00 kvm-guest: setup PV IPIs
2025-08-02T11:49:39,243588+00:00 ..TIMER: vector=0x30 apic1=0 pin1=2 apic2=-1 pin2=-1
2025-08-02T11:49:39,243628+00:00 clocksource: tsc-early: mask: 0xffffffffffffffff max_cycles: 0x212731a5301, max_idle_ns: 440795317123 ns
2025-08-02T11:49:39,243639+00:00 Calibrating delay loop (skipped) preset value.. 4599.99 BogoMIPS (lpj=9199984)
2025-08-02T11:49:39,243745+00:00 x86/cpu: User Mode Instruction Prevention (UMIP) activated
2025-08-02T11:49:39,243837+00:00 Last level iTLB entries: 4KB 0, 2MB 0, 4MB 0
2025-08-02T11:49:39,243841+00:00 Last level dTLB entries: 4KB 0, 2MB 0, 4MB 0, 1GB 0
2025-08-02T11:49:39,243849+00:00 Spectre V1 : Mitigation: usercopy/swapgs barriers and __user pointer sanitization
2025-08-02T11:49:39,243853+00:00 Spectre V2 : Mitigation: Retpolines
2025-08-02T11:49:39,243855+00:00 Spectre V2 : Spectre v2 / SpectreRSB mitigation: Filling RSB on context switch
2025-08-02T11:49:39,243859+00:00 Spectre V2 : Spectre v2 / SpectreRSB : Filling RSB on VMEXIT
2025-08-02T11:49:39,243861+00:00 Spectre V2 : Enabling Restricted Speculation for firmware calls
2025-08-02T11:49:39,243864+00:00 Spectre V2 : mitigation: Enabling conditional Indirect Branch Prediction Barrier
2025-08-02T11:49:39,243867+00:00 Speculative Store Bypass: Mitigation: Speculative Store Bypass disabled via prctl and seccomp
2025-08-02T11:49:39,243874+00:00 MDS: Mitigation: Clear CPU buffers
2025-08-02T11:49:39,243876+00:00 MMIO Stale Data: Mitigation: Clear CPU buffers
2025-08-02T11:49:39,243904+00:00 x86/fpu: Supporting XSAVE feature 0x001: 'x87 floating point registers'
2025-08-02T11:49:39,243907+00:00 x86/fpu: Supporting XSAVE feature 0x002: 'SSE registers'
2025-08-02T11:49:39,243909+00:00 x86/fpu: Supporting XSAVE feature 0x004: 'AVX registers'
2025-08-02T11:49:39,243913+00:00 x86/fpu: xstate_offset[2]:  576, xstate_sizes[2]:  256
2025-08-02T11:49:39,243916+00:00 x86/fpu: Enabled xstate features 0x7, context size is 832 bytes, using 'standard' format.
2025-08-02T11:49:39,270859+00:00 Freeing SMP alternatives memory: 44K
2025-08-02T11:49:39,270869+00:00 pid_max: default: 32768 minimum: 301
2025-08-02T11:49:39,270910+00:00 LSM: Security Framework initializing
2025-08-02T11:49:39,270924+00:00 landlock: Up and running.
2025-08-02T11:49:39,270926+00:00 Yama: becoming mindful.
2025-08-02T11:49:39,270967+00:00 AppArmor: AppArmor initialized
2025-08-02T11:49:39,271058+00:00 Mount-cache hash table entries: 32768 (order: 6, 262144 bytes, linear)
2025-08-02T11:49:39,271112+00:00 Mountpoint-cache hash table entries: 32768 (order: 6, 262144 bytes, linear)
2025-08-02T11:49:39,271597+00:00 smpboot: CPU0: Intel(R) Xeon(R) CPU E5-2699 v3 @ 2.30GHz (family: 0x6, model: 0x3f, stepping: 0x2)
2025-08-02T11:49:39,271634+00:00 Performance Events: Haswell events, full-width counters, Intel PMU driver.
2025-08-02T11:49:39,271634+00:00 ... version:                2
2025-08-02T11:49:39,271634+00:00 ... bit width:              48
2025-08-02T11:49:39,271634+00:00 ... generic registers:      4
2025-08-02T11:49:39,271634+00:00 ... value mask:             0000ffffffffffff
2025-08-02T11:49:39,271634+00:00 ... max period:             00007fffffffffff
2025-08-02T11:49:39,271634+00:00 ... fixed-purpose events:   3
2025-08-02T11:49:39,271634+00:00 ... event mask:             000000070000000f
2025-08-02T11:49:39,271634+00:00 signal: max sigframe size: 1776
2025-08-02T11:49:39,271634+00:00 rcu: Hierarchical SRCU implementation.
2025-08-02T11:49:39,271634+00:00 smp: Bringing up secondary CPUs ...
2025-08-02T11:49:39,271634+00:00 x86: Booting SMP configuration:
2025-08-02T11:49:39,271634+00:00 .... node  #0, CPUs:      #1
2025-08-02T11:49:39,086392+00:00 kvm-clock: cpu 1, msr 2fda01041, secondary cpu clock
2025-08-02T11:49:39,271634+00:00 kvm-guest: setup async PF for cpu 1
2025-08-02T11:49:39,271634+00:00 kvm-guest: stealtime: cpu 1, msr 333c74080
2025-08-02T11:49:39,271634+00:00  #2
2025-08-02T11:49:39,086392+00:00 kvm-clock: cpu 2, msr 2fda01081, secondary cpu clock
2025-08-02T11:49:39,271634+00:00 kvm-guest: setup async PF for cpu 2
2025-08-02T11:49:39,271634+00:00 kvm-guest: stealtime: cpu 2, msr 333cb4080
2025-08-02T11:49:39,271634+00:00  #3
2025-08-02T11:49:39,086392+00:00 kvm-clock: cpu 3, msr 2fda010c1, secondary cpu clock
2025-08-02T11:49:39,271634+00:00 kvm-guest: setup async PF for cpu 3
2025-08-02T11:49:39,271634+00:00 kvm-guest: stealtime: cpu 3, msr 333cf4080
2025-08-02T11:49:39,271634+00:00  #4
2025-08-02T11:49:39,086392+00:00 kvm-clock: cpu 4, msr 2fda01101, secondary cpu clock
2025-08-02T11:49:39,086392+00:00 smpboot: CPU 4 Converting physical 0 to logical die 1
2025-08-02T11:49:39,271700+00:00 kvm-guest: setup async PF for cpu 4
2025-08-02T11:49:39,271733+00:00 kvm-guest: stealtime: cpu 4, msr 333d34080
2025-08-02T11:49:39,271819+00:00  #5
2025-08-02T11:49:39,086392+00:00 kvm-clock: cpu 5, msr 2fda01141, secondary cpu clock
2025-08-02T11:49:39,272251+00:00 kvm-guest: setup async PF for cpu 5
2025-08-02T11:49:39,272251+00:00 kvm-guest: stealtime: cpu 5, msr 333d74080
2025-08-02T11:49:39,272251+00:00  #6
2025-08-02T11:49:39,086392+00:00 kvm-clock: cpu 6, msr 2fda01181, secondary cpu clock
2025-08-02T11:49:39,272291+00:00 kvm-guest: setup async PF for cpu 6
2025-08-02T11:49:39,272291+00:00 kvm-guest: stealtime: cpu 6, msr 333db4080
2025-08-02T11:49:39,272291+00:00  #7
2025-08-02T11:49:39,086392+00:00 kvm-clock: cpu 7, msr 2fda011c1, secondary cpu clock
2025-08-02T11:49:39,272330+00:00 kvm-guest: setup async PF for cpu 7
2025-08-02T11:49:39,272330+00:00 kvm-guest: stealtime: cpu 7, msr 333df4080
2025-08-02T11:49:39,272330+00:00 smp: Brought up 1 node, 8 CPUs
2025-08-02T11:49:39,272330+00:00 smpboot: Max logical packages: 2
2025-08-02T11:49:39,272330+00:00 smpboot: Total of 8 processors activated (36799.93 BogoMIPS)
2025-08-02T11:49:39,275643+00:00 devtmpfs: initialized
2025-08-02T11:49:39,275743+00:00 x86/mm: Memory block size: 128MB
2025-08-02T11:49:39,277100+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 7645041785100000 ns
2025-08-02T11:49:39,277100+00:00 futex hash table entries: 2048 (order: 5, 131072 bytes, linear)
2025-08-02T11:49:39,277100+00:00 pinctrl core: initialized pinctrl subsystem
2025-08-02T11:49:39,277100+00:00 PM: RTC time: 11:49:39, date: 2025-08-02
2025-08-02T11:49:39,277100+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2025-08-02T11:49:39,277166+00:00 DMA: preallocated 2048 KiB GFP_KERNEL pool for atomic allocations
2025-08-02T11:49:39,277600+00:00 DMA: preallocated 2048 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2025-08-02T11:49:39,279722+00:00 DMA: preallocated 2048 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2025-08-02T11:49:39,279739+00:00 audit: initializing netlink subsys (disabled)
2025-08-02T11:49:39,279756+00:00 audit: type=2000 audit(1754135379.344:1): state=initialized audit_enabled=0 res=1
2025-08-02T11:49:39,279813+00:00 thermal_sys: Registered thermal governor 'fair_share'
2025-08-02T11:49:39,279815+00:00 thermal_sys: Registered thermal governor 'bang_bang'
2025-08-02T11:49:39,279818+00:00 thermal_sys: Registered thermal governor 'step_wise'
2025-08-02T11:49:39,279821+00:00 thermal_sys: Registered thermal governor 'user_space'
2025-08-02T11:49:39,279823+00:00 thermal_sys: Registered thermal governor 'power_allocator'
2025-08-02T11:49:39,279838+00:00 cpuidle: using governor ladder
2025-08-02T11:49:39,279845+00:00 cpuidle: using governor menu
2025-08-02T11:49:39,280011+00:00 ACPI: bus type PCI registered
2025-08-02T11:49:39,280017+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2025-08-02T11:49:39,280193+00:00 PCI: Using configuration type 1 for base access
2025-08-02T11:49:39,280227+00:00 core: PMU erratum BJ122, BV98, HSD29 workaround disabled, HT off
2025-08-02T11:49:39,282069+00:00 kprobes: kprobe jump-optimization is enabled. All kprobes are optimized if possible.
2025-08-02T11:49:39,282084+00:00 HugeTLB registered 1.00 GiB page size, pre-allocated 0 pages
2025-08-02T11:49:39,282084+00:00 HugeTLB registered 2.00 MiB page size, pre-allocated 0 pages
2025-08-02T11:49:39,287733+00:00 fbcon: Taking over console
2025-08-02T11:49:39,287763+00:00 ACPI: Added _OSI(Module Device)
2025-08-02T11:49:39,287766+00:00 ACPI: Added _OSI(Processor Device)
2025-08-02T11:49:39,287768+00:00 ACPI: Added _OSI(3.0 _SCP Extensions)
2025-08-02T11:49:39,287770+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2025-08-02T11:49:39,287772+00:00 ACPI: Added _OSI(Linux-Dell-Video)
2025-08-02T11:49:39,287774+00:00 ACPI: Added _OSI(Linux-Lenovo-NV-HDMI-Audio)
2025-08-02T11:49:39,287776+00:00 ACPI: Added _OSI(Linux-HPI-Hybrid-Graphics)
2025-08-02T11:49:39,292252+00:00 ACPI: 2 ACPI AML tables successfully acquired and loaded
2025-08-02T11:49:39,293574+00:00 ACPI: Interpreter enabled
2025-08-02T11:49:39,293588+00:00 ACPI: PM: (supports S0 S5)
2025-08-02T11:49:39,293591+00:00 ACPI: Using IOAPIC for interrupt routing
2025-08-02T11:49:39,293607+00:00 PCI: Using host bridge windows from ACPI; if necessary, use "pci=nocrs" and report a bug
2025-08-02T11:49:39,293610+00:00 PCI: Using E820 reservations for host bridge windows
2025-08-02T11:49:39,293826+00:00 ACPI: Enabled 3 GPEs in block 00 to 0F
2025-08-02T11:49:39,302844+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-ff])
2025-08-02T11:49:39,302859+00:00 acpi PNP0A03:00: _OSC: OS supports [ASPM ClockPM Segments MSI EDR HPX-Type3]
2025-08-02T11:49:39,302872+00:00 acpi PNP0A03:00: fail to add MMCONFIG information, can't access extended PCI configuration space under this bridge.
2025-08-02T11:49:39,303287+00:00 acpiphp: Slot [8] registered
2025-08-02T11:49:39,303313+00:00 acpiphp: Slot [10] registered
2025-08-02T11:49:39,303334+00:00 acpiphp: Slot [18] registered
2025-08-02T11:49:39,303433+00:00 acpiphp: Slot [3] registered
2025-08-02T11:49:39,303470+00:00 acpiphp: Slot [4] registered
2025-08-02T11:49:39,303505+00:00 acpiphp: Slot [6] registered
2025-08-02T11:49:39,303530+00:00 acpiphp: Slot [7] registered
2025-08-02T11:49:39,303551+00:00 acpiphp: Slot [9] registered
2025-08-02T11:49:39,303571+00:00 acpiphp: Slot [11] registered
2025-08-02T11:49:39,303593+00:00 acpiphp: Slot [12] registered
2025-08-02T11:49:39,303613+00:00 acpiphp: Slot [13] registered
2025-08-02T11:49:39,303633+00:00 acpiphp: Slot [14] registered
2025-08-02T11:49:39,303684+00:00 acpiphp: Slot [15] registered
2025-08-02T11:49:39,303720+00:00 acpiphp: Slot [16] registered
2025-08-02T11:49:39,303752+00:00 acpiphp: Slot [17] registered
2025-08-02T11:49:39,303790+00:00 acpiphp: Slot [19] registered
2025-08-02T11:49:39,303831+00:00 acpiphp: Slot [20] registered
2025-08-02T11:49:39,303876+00:00 acpiphp: Slot [21] registered
2025-08-02T11:49:39,303907+00:00 acpiphp: Slot [22] registered
2025-08-02T11:49:39,303930+00:00 acpiphp: Slot [23] registered
2025-08-02T11:49:39,303951+00:00 acpiphp: Slot [24] registered
2025-08-02T11:49:39,303971+00:00 acpiphp: Slot [25] registered
2025-08-02T11:49:39,303990+00:00 acpiphp: Slot [26] registered
2025-08-02T11:49:39,304010+00:00 acpiphp: Slot [27] registered
2025-08-02T11:49:39,304030+00:00 acpiphp: Slot [28] registered
2025-08-02T11:49:39,304052+00:00 acpiphp: Slot [29] registered
2025-08-02T11:49:39,304068+00:00 PCI host bridge to bus 0000:00
2025-08-02T11:49:39,304072+00:00 pci_bus 0000:00: root bus resource [bus 00-ff]
2025-08-02T11:49:39,304076+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0x0cf7 window]
2025-08-02T11:49:39,304079+00:00 pci_bus 0000:00: root bus resource [io  0x0d00-0xffff window]
2025-08-02T11:49:39,304082+00:00 pci_bus 0000:00: root bus resource [mem 0x000a0000-0x000bffff window]
2025-08-02T11:49:39,304085+00:00 pci_bus 0000:00: root bus resource [mem 0xc0000000-0xfebfffff window]
2025-08-02T11:49:39,304088+00:00 pci_bus 0000:00: root bus resource [mem 0x380000000000-0x38200000bfff window]
2025-08-02T11:49:39,304225+00:00 pci 0000:00:00.0: [8086:1237] type 00 class 0x060000
2025-08-02T11:49:39,305438+00:00 pci 0000:00:01.0: [8086:7000] type 00 class 0x060100
2025-08-02T11:49:39,306278+00:00 pci 0000:00:01.1: [8086:7010] type 00 class 0x010180
2025-08-02T11:49:39,307689+00:00 pci 0000:00:01.1: reg 0x20: [io  0xf100-0xf10f]
2025-08-02T11:49:39,307779+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x10: [io  0x01f0-0x01f7]
2025-08-02T11:49:39,307786+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x14: [io  0x03f6]
2025-08-02T11:49:39,307791+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x18: [io  0x0170-0x0177]
2025-08-02T11:49:39,307795+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x1c: [io  0x0376]
2025-08-02T11:49:39,308093+00:00 pci 0000:00:01.2: [8086:7020] type 00 class 0x0c0300
2025-08-02T11:49:39,309444+00:00 pci 0000:00:01.2: reg 0x20: [io  0xf0c0-0xf0df]
2025-08-02T11:49:39,310647+00:00 pci 0000:00:01.3: [8086:7113] type 00 class 0x068000
2025-08-02T11:49:39,311165+00:00 pci 0000:00:01.3: quirk: [io  0x0600-0x063f] claimed by PIIX4 ACPI
2025-08-02T11:49:39,311180+00:00 pci 0000:00:01.3: quirk: [io  0x0700-0x070f] claimed by PIIX4 SMB
2025-08-02T11:49:39,311834+00:00 pci 0000:00:02.0: [1234:1111] type 00 class 0x030000
2025-08-02T11:49:39,317157+00:00 pci 0000:00:02.0: reg 0x10: [mem 0xfd000000-0xfdffffff pref]
2025-08-02T11:49:39,317210+00:00 pci 0000:00:02.0: reg 0x18: [mem 0xfea50000-0xfea50fff]
2025-08-02T11:49:39,317249+00:00 pci 0000:00:02.0: reg 0x30: [mem 0xfea40000-0xfea4ffff pref]
2025-08-02T11:49:39,317367+00:00 pci 0000:00:02.0: BAR 0: assigned to efifb
2025-08-02T11:49:39,317407+00:00 pci 0000:00:02.0: Video device with shadowed ROM at [mem 0x000c0000-0x000dffff]
2025-08-02T11:49:39,319124+00:00 pci 0000:00:05.0: [1b36:0001] type 01 class 0x060400
2025-08-02T11:49:39,321937+00:00 pci 0000:00:05.0: reg 0x10: [mem 0x380000000000-0x3800000000ff 64bit]
2025-08-02T11:49:39,325162+00:00 pci 0000:00:08.0: [1af4:1003] type 00 class 0x078000
2025-08-02T11:49:39,328490+00:00 pci 0000:00:08.0: reg 0x10: [io  0xf080-0xf0bf]
2025-08-02T11:49:39,328507+00:00 pci 0000:00:08.0: reg 0x14: [mem 0xfea51000-0xfea51fff]
2025-08-02T11:49:39,328545+00:00 pci 0000:00:08.0: reg 0x20: [mem 0x382000000000-0x382000003fff 64bit pref]
2025-08-02T11:49:39,330950+00:00 pci 0000:00:0a.0: [1af4:1001] type 00 class 0x010000
2025-08-02T11:49:39,333428+00:00 pci 0000:00:0a.0: reg 0x10: [io  0xf000-0xf07f]
2025-08-02T11:49:39,333446+00:00 pci 0000:00:0a.0: reg 0x14: [mem 0xfea52000-0xfea52fff]
2025-08-02T11:49:39,333485+00:00 pci 0000:00:0a.0: reg 0x20: [mem 0x382000004000-0x382000007fff 64bit pref]
2025-08-02T11:49:39,338614+00:00 pci 0000:00:12.0: [1af4:1000] type 00 class 0x020000
2025-08-02T11:49:39,340675+00:00 pci 0000:00:12.0: reg 0x10: [io  0xf0e0-0xf0ff]
2025-08-02T11:49:39,340693+00:00 pci 0000:00:12.0: reg 0x14: [mem 0xfea53000-0xfea53fff]
2025-08-02T11:49:39,340730+00:00 pci 0000:00:12.0: reg 0x20: [mem 0x382000008000-0x38200000bfff 64bit pref]
2025-08-02T11:49:39,340743+00:00 pci 0000:00:12.0: reg 0x30: [mem 0xfea00000-0xfea3ffff pref]
2025-08-02T11:49:39,346285+00:00 pci 0000:00:1e.0: [1b36:0001] type 01 class 0x060400
2025-08-02T11:49:39,348299+00:00 pci 0000:00:1e.0: reg 0x10: [mem 0x380000001000-0x3800000010ff 64bit]
2025-08-02T11:49:39,349949+00:00 pci 0000:00:1f.0: [1b36:0001] type 01 class 0x060400
2025-08-02T11:49:39,351660+00:00 pci 0000:00:1f.0: reg 0x10: [mem 0x380000002000-0x3800000020ff 64bit]
2025-08-02T11:49:39,354184+00:00 pci_bus 0000:01: extended config space not accessible
2025-08-02T11:49:39,354555+00:00 acpiphp: Slot [0] registered
2025-08-02T11:49:39,354596+00:00 acpiphp: Slot [1-2] registered
2025-08-02T11:49:39,354619+00:00 acpiphp: Slot [2] registered
2025-08-02T11:49:39,354644+00:00 acpiphp: Slot [3-2] registered
2025-08-02T11:49:39,354667+00:00 acpiphp: Slot [4-2] registered
2025-08-02T11:49:39,354688+00:00 acpiphp: Slot [5] registered
2025-08-02T11:49:39,354711+00:00 acpiphp: Slot [6-2] registered
2025-08-02T11:49:39,354734+00:00 acpiphp: Slot [7-2] registered
2025-08-02T11:49:39,354759+00:00 acpiphp: Slot [8-2] registered
2025-08-02T11:49:39,354782+00:00 acpiphp: Slot [9-2] registered
2025-08-02T11:49:39,354808+00:00 acpiphp: Slot [10-2] registered
2025-08-02T11:49:39,354831+00:00 acpiphp: Slot [11-2] registered
2025-08-02T11:49:39,354854+00:00 acpiphp: Slot [12-2] registered
2025-08-02T11:49:39,354877+00:00 acpiphp: Slot [13-2] registered
2025-08-02T11:49:39,354901+00:00 acpiphp: Slot [14-2] registered
2025-08-02T11:49:39,354925+00:00 acpiphp: Slot [15-2] registered
2025-08-02T11:49:39,354948+00:00 acpiphp: Slot [16-2] registered
2025-08-02T11:49:39,354970+00:00 acpiphp: Slot [17-2] registered
2025-08-02T11:49:39,355003+00:00 acpiphp: Slot [18-2] registered
2025-08-02T11:49:39,355028+00:00 acpiphp: Slot [19-2] registered
2025-08-02T11:49:39,355052+00:00 acpiphp: Slot [20-2] registered
2025-08-02T11:49:39,355079+00:00 acpiphp: Slot [21-2] registered
2025-08-02T11:49:39,355104+00:00 acpiphp: Slot [22-2] registered
2025-08-02T11:49:39,355127+00:00 acpiphp: Slot [23-2] registered
2025-08-02T11:49:39,355153+00:00 acpiphp: Slot [24-2] registered
2025-08-02T11:49:39,355176+00:00 acpiphp: Slot [25-2] registered
2025-08-02T11:49:39,355200+00:00 acpiphp: Slot [26-2] registered
2025-08-02T11:49:39,355225+00:00 acpiphp: Slot [27-2] registered
2025-08-02T11:49:39,355249+00:00 acpiphp: Slot [28-2] registered
2025-08-02T11:49:39,355272+00:00 acpiphp: Slot [29-2] registered
2025-08-02T11:49:39,355292+00:00 acpiphp: Slot [30] registered
2025-08-02T11:49:39,355313+00:00 acpiphp: Slot [31] registered
2025-08-02T11:49:39,366159+00:00 pci 0000:00:05.0: PCI bridge to [bus 01]
2025-08-02T11:49:39,366192+00:00 pci 0000:00:05.0:   bridge window [io  0xe000-0xefff]
2025-08-02T11:49:39,366213+00:00 pci 0000:00:05.0:   bridge window [mem 0xfe800000-0xfe9fffff]
2025-08-02T11:49:39,366262+00:00 pci 0000:00:05.0:   bridge window [mem 0x381800000000-0x381fffffffff 64bit pref]
2025-08-02T11:49:39,367356+00:00 pci_bus 0000:02: extended config space not accessible
2025-08-02T11:49:39,367646+00:00 acpiphp: Slot [0-2] registered
2025-08-02T11:49:39,367677+00:00 acpiphp: Slot [1-3] registered
2025-08-02T11:49:39,367702+00:00 acpiphp: Slot [2-2] registered
2025-08-02T11:49:39,367726+00:00 acpiphp: Slot [3-3] registered
2025-08-02T11:49:39,367751+00:00 acpiphp: Slot [4-3] registered
2025-08-02T11:49:39,367776+00:00 acpiphp: Slot [5-2] registered
2025-08-02T11:49:39,367800+00:00 acpiphp: Slot [6-3] registered
2025-08-02T11:49:39,367823+00:00 acpiphp: Slot [7-3] registered
2025-08-02T11:49:39,367847+00:00 acpiphp: Slot [8-3] registered
2025-08-02T11:49:39,367871+00:00 acpiphp: Slot [9-3] registered
2025-08-02T11:49:39,367898+00:00 acpiphp: Slot [10-3] registered
2025-08-02T11:49:39,367923+00:00 acpiphp: Slot [11-3] registered
2025-08-02T11:49:39,367947+00:00 acpiphp: Slot [12-3] registered
2025-08-02T11:49:39,367989+00:00 acpiphp: Slot [13-3] registered
2025-08-02T11:49:39,368015+00:00 acpiphp: Slot [14-3] registered
2025-08-02T11:49:39,368039+00:00 acpiphp: Slot [15-3] registered
2025-08-02T11:49:39,368063+00:00 acpiphp: Slot [16-3] registered
2025-08-02T11:49:39,368089+00:00 acpiphp: Slot [17-3] registered
2025-08-02T11:49:39,368117+00:00 acpiphp: Slot [18-3] registered
2025-08-02T11:49:39,368141+00:00 acpiphp: Slot [19-3] registered
2025-08-02T11:49:39,368165+00:00 acpiphp: Slot [20-3] registered
2025-08-02T11:49:39,368189+00:00 acpiphp: Slot [21-3] registered
2025-08-02T11:49:39,368213+00:00 acpiphp: Slot [22-3] registered
2025-08-02T11:49:39,368238+00:00 acpiphp: Slot [23-3] registered
2025-08-02T11:49:39,368265+00:00 acpiphp: Slot [24-3] registered
2025-08-02T11:49:39,368294+00:00 acpiphp: Slot [25-3] registered
2025-08-02T11:49:39,368333+00:00 acpiphp: Slot [26-3] registered
2025-08-02T11:49:39,368374+00:00 acpiphp: Slot [27-3] registered
2025-08-02T11:49:39,368409+00:00 acpiphp: Slot [28-3] registered
2025-08-02T11:49:39,368434+00:00 acpiphp: Slot [29-3] registered
2025-08-02T11:49:39,368460+00:00 acpiphp: Slot [30-2] registered
2025-08-02T11:49:39,368485+00:00 acpiphp: Slot [31-2] registered
2025-08-02T11:49:39,378862+00:00 pci 0000:00:1e.0: PCI bridge to [bus 02]
2025-08-02T11:49:39,378892+00:00 pci 0000:00:1e.0:   bridge window [io  0xd000-0xdfff]
2025-08-02T11:49:39,378913+00:00 pci 0000:00:1e.0:   bridge window [mem 0xfe600000-0xfe7fffff]
2025-08-02T11:49:39,378960+00:00 pci 0000:00:1e.0:   bridge window [mem 0x381000000000-0x3817ffffffff 64bit pref]
2025-08-02T11:49:39,379828+00:00 pci_bus 0000:03: extended config space not accessible
2025-08-02T11:49:39,380238+00:00 acpiphp: Slot [0-3] registered
2025-08-02T11:49:39,380286+00:00 acpiphp: Slot [1-4] registered
2025-08-02T11:49:39,380331+00:00 acpiphp: Slot [2-3] registered
2025-08-02T11:49:39,380362+00:00 acpiphp: Slot [3-4] registered
2025-08-02T11:49:39,380387+00:00 acpiphp: Slot [4-4] registered
2025-08-02T11:49:39,380412+00:00 acpiphp: Slot [5-3] registered
2025-08-02T11:49:39,380437+00:00 acpiphp: Slot [6-4] registered
2025-08-02T11:49:39,380479+00:00 acpiphp: Slot [7-4] registered
2025-08-02T11:49:39,380522+00:00 acpiphp: Slot [8-4] registered
2025-08-02T11:49:39,380569+00:00 acpiphp: Slot [9-4] registered
2025-08-02T11:49:39,380617+00:00 acpiphp: Slot [10-4] registered
2025-08-02T11:49:39,380664+00:00 acpiphp: Slot [11-4] registered
2025-08-02T11:49:39,380711+00:00 acpiphp: Slot [12-4] registered
2025-08-02T11:49:39,380751+00:00 acpiphp: Slot [13-4] registered
2025-08-02T11:49:39,380778+00:00 acpiphp: Slot [14-4] registered
2025-08-02T11:49:39,380818+00:00 acpiphp: Slot [15-4] registered
2025-08-02T11:49:39,380848+00:00 acpiphp: Slot [16-4] registered
2025-08-02T11:49:39,380873+00:00 acpiphp: Slot [17-4] registered
2025-08-02T11:49:39,380899+00:00 acpiphp: Slot [18-4] registered
2025-08-02T11:49:39,380925+00:00 acpiphp: Slot [19-4] registered
2025-08-02T11:49:39,380952+00:00 acpiphp: Slot [20-4] registered
2025-08-02T11:49:39,380995+00:00 acpiphp: Slot [21-4] registered
2025-08-02T11:49:39,381032+00:00 acpiphp: Slot [22-4] registered
2025-08-02T11:49:39,381058+00:00 acpiphp: Slot [23-4] registered
2025-08-02T11:49:39,381086+00:00 acpiphp: Slot [24-4] registered
2025-08-02T11:49:39,381112+00:00 acpiphp: Slot [25-4] registered
2025-08-02T11:49:39,381140+00:00 acpiphp: Slot [26-4] registered
2025-08-02T11:49:39,381166+00:00 acpiphp: Slot [27-4] registered
2025-08-02T11:49:39,381191+00:00 acpiphp: Slot [28-4] registered
2025-08-02T11:49:39,381216+00:00 acpiphp: Slot [29-4] registered
2025-08-02T11:49:39,381241+00:00 acpiphp: Slot [30-3] registered
2025-08-02T11:49:39,381266+00:00 acpiphp: Slot [31-3] registered
2025-08-02T11:49:39,392361+00:00 pci 0000:00:1f.0: PCI bridge to [bus 03]
2025-08-02T11:49:39,392396+00:00 pci 0000:00:1f.0:   bridge window [io  0xc000-0xcfff]
2025-08-02T11:49:39,392417+00:00 pci 0000:00:1f.0:   bridge window [mem 0xfe400000-0xfe5fffff]
2025-08-02T11:49:39,392455+00:00 pci 0000:00:1f.0:   bridge window [mem 0x380800000000-0x380fffffffff 64bit pref]
2025-08-02T11:49:39,395042+00:00 ACPI: PCI: Interrupt link LNKA configured for IRQ 10
2025-08-02T11:49:39,395218+00:00 ACPI: PCI: Interrupt link LNKB configured for IRQ 10
2025-08-02T11:49:39,395367+00:00 ACPI: PCI: Interrupt link LNKC configured for IRQ 11
2025-08-02T11:49:39,395512+00:00 ACPI: PCI: Interrupt link LNKD configured for IRQ 11
2025-08-02T11:49:39,395600+00:00 ACPI: PCI: Interrupt link LNKS configured for IRQ 9
2025-08-02T11:49:39,396535+00:00 iommu: Default domain type: Translated 
2025-08-02T11:49:39,396535+00:00 iommu: DMA domain TLB invalidation policy: lazy mode 
2025-08-02T11:49:39,396535+00:00 SCSI subsystem initialized
2025-08-02T11:49:39,396535+00:00 libata version 3.00 loaded.
2025-08-02T11:49:39,396535+00:00 pci 0000:00:02.0: vgaarb: setting as boot VGA device
2025-08-02T11:49:39,396535+00:00 pci 0000:00:02.0: vgaarb: VGA device added: decodes=io+mem,owns=io+mem,locks=none
2025-08-02T11:49:39,396535+00:00 pci 0000:00:02.0: vgaarb: bridge control possible
2025-08-02T11:49:39,396535+00:00 vgaarb: loaded
2025-08-02T11:49:39,396535+00:00 ACPI: bus type USB registered
2025-08-02T11:49:39,396535+00:00 usbcore: registered new interface driver usbfs
2025-08-02T11:49:39,396535+00:00 usbcore: registered new interface driver hub
2025-08-02T11:49:39,396535+00:00 usbcore: registered new device driver usb
2025-08-02T11:49:39,396535+00:00 pps_core: LinuxPPS API ver. 1 registered
2025-08-02T11:49:39,396535+00:00 pps_core: Software ver. 5.3.6 - Copyright 2005-2007 Rodolfo Giometti <giometti@linux.it>
2025-08-02T11:49:39,396535+00:00 PTP clock support registered
2025-08-02T11:49:39,396535+00:00 EDAC MC: Ver: 3.0.0
2025-08-02T11:49:39,396535+00:00 NetLabel: Initializing
2025-08-02T11:49:39,396535+00:00 NetLabel:  domain hash size = 128
2025-08-02T11:49:39,396535+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2025-08-02T11:49:39,396535+00:00 NetLabel:  unlabeled traffic allowed by default
2025-08-02T11:49:39,396535+00:00 PCI: Using ACPI for IRQ routing
2025-08-02T11:49:39,396535+00:00 PCI: pci_cache_line_size set to 64 bytes
2025-08-02T11:49:39,399954+00:00 e820: reserve RAM buffer [mem 0x0009fc00-0x0009ffff]
2025-08-02T11:49:39,399960+00:00 e820: reserve RAM buffer [mem 0xbffda000-0xbfffffff]
2025-08-02T11:49:39,402445+00:00 hpet0: at MMIO 0xfed00000, IRQs 2, 8, 0
2025-08-02T11:49:39,402457+00:00 hpet0: 3 comparators, 64-bit 100.000000 MHz counter
2025-08-02T11:49:39,406874+00:00 clocksource: Switched to clocksource kvm-clock
2025-08-02T11:49:39,418282+00:00 VFS: Disk quotas dquot_6.6.0
2025-08-02T11:49:39,418307+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2025-08-02T11:49:39,418485+00:00 AppArmor: AppArmor Filesystem Enabled
2025-08-02T11:49:39,418518+00:00 pnp: PnP ACPI init
2025-08-02T11:49:39,418683+00:00 pnp 00:02: [dma 2]
2025-08-02T11:49:39,419152+00:00 pnp: PnP ACPI: found 4 devices
2025-08-02T11:49:39,427894+00:00 clocksource: acpi_pm: mask: 0xffffff max_cycles: 0xffffff, max_idle_ns: 2085701024 ns
2025-08-02T11:49:39,427998+00:00 NET: Registered PF_INET protocol family
2025-08-02T11:49:39,428479+00:00 IP idents hash table entries: 262144 (order: 9, 2097152 bytes, linear)
2025-08-02T11:49:39,430960+00:00 tcp_listen_portaddr_hash hash table entries: 8192 (order: 5, 131072 bytes, linear)
2025-08-02T11:49:39,431031+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2025-08-02T11:49:39,431252+00:00 TCP established hash table entries: 131072 (order: 8, 1048576 bytes, linear)
2025-08-02T11:49:39,431554+00:00 TCP bind hash table entries: 65536 (order: 8, 1048576 bytes, linear)
2025-08-02T11:49:39,431628+00:00 TCP: Hash tables configured (established 131072 bind 65536)
2025-08-02T11:49:39,431833+00:00 MPTCP token hash table entries: 16384 (order: 6, 393216 bytes, linear)
2025-08-02T11:49:39,431962+00:00 UDP hash table entries: 8192 (order: 6, 262144 bytes, linear)
2025-08-02T11:49:39,432047+00:00 UDP-Lite hash table entries: 8192 (order: 6, 262144 bytes, linear)
2025-08-02T11:49:39,432153+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2025-08-02T11:49:39,432167+00:00 NET: Registered PF_XDP protocol family
2025-08-02T11:49:39,432192+00:00 pci 0000:00:05.0: PCI bridge to [bus 01]
2025-08-02T11:49:39,432221+00:00 pci 0000:00:05.0:   bridge window [io  0xe000-0xefff]
2025-08-02T11:49:39,433157+00:00 pci 0000:00:05.0:   bridge window [mem 0xfe800000-0xfe9fffff]
2025-08-02T11:49:39,433717+00:00 pci 0000:00:05.0:   bridge window [mem 0x381800000000-0x381fffffffff 64bit pref]
2025-08-02T11:49:39,434852+00:00 pci 0000:00:1e.0: PCI bridge to [bus 02]
2025-08-02T11:49:39,434882+00:00 pci 0000:00:1e.0:   bridge window [io  0xd000-0xdfff]
2025-08-02T11:49:39,435901+00:00 pci 0000:00:1e.0:   bridge window [mem 0xfe600000-0xfe7fffff]
2025-08-02T11:49:39,437425+00:00 pci 0000:00:1e.0:   bridge window [mem 0x381000000000-0x3817ffffffff 64bit pref]
2025-08-02T11:49:39,438512+00:00 pci 0000:00:1f.0: PCI bridge to [bus 03]
2025-08-02T11:49:39,438531+00:00 pci 0000:00:1f.0:   bridge window [io  0xc000-0xcfff]
2025-08-02T11:49:39,439390+00:00 pci 0000:00:1f.0:   bridge window [mem 0xfe400000-0xfe5fffff]
2025-08-02T11:49:39,440076+00:00 pci 0000:00:1f.0:   bridge window [mem 0x380800000000-0x380fffffffff 64bit pref]
2025-08-02T11:49:39,441865+00:00 pci_bus 0000:00: resource 4 [io  0x0000-0x0cf7 window]
2025-08-02T11:49:39,441871+00:00 pci_bus 0000:00: resource 5 [io  0x0d00-0xffff window]
2025-08-02T11:49:39,441874+00:00 pci_bus 0000:00: resource 6 [mem 0x000a0000-0x000bffff window]
2025-08-02T11:49:39,441878+00:00 pci_bus 0000:00: resource 7 [mem 0xc0000000-0xfebfffff window]
2025-08-02T11:49:39,441880+00:00 pci_bus 0000:00: resource 8 [mem 0x380000000000-0x38200000bfff window]
2025-08-02T11:49:39,441884+00:00 pci_bus 0000:01: resource 0 [io  0xe000-0xefff]
2025-08-02T11:49:39,441887+00:00 pci_bus 0000:01: resource 1 [mem 0xfe800000-0xfe9fffff]
2025-08-02T11:49:39,441889+00:00 pci_bus 0000:01: resource 2 [mem 0x381800000000-0x381fffffffff 64bit pref]
2025-08-02T11:49:39,441893+00:00 pci_bus 0000:02: resource 0 [io  0xd000-0xdfff]
2025-08-02T11:49:39,441896+00:00 pci_bus 0000:02: resource 1 [mem 0xfe600000-0xfe7fffff]
2025-08-02T11:49:39,441898+00:00 pci_bus 0000:02: resource 2 [mem 0x381000000000-0x3817ffffffff 64bit pref]
2025-08-02T11:49:39,441902+00:00 pci_bus 0000:03: resource 0 [io  0xc000-0xcfff]
2025-08-02T11:49:39,441904+00:00 pci_bus 0000:03: resource 1 [mem 0xfe400000-0xfe5fffff]
2025-08-02T11:49:39,441906+00:00 pci_bus 0000:03: resource 2 [mem 0x380800000000-0x380fffffffff 64bit pref]
2025-08-02T11:49:39,442076+00:00 pci 0000:00:01.0: PIIX3: Enabling Passive Release
2025-08-02T11:49:39,442094+00:00 pci 0000:00:00.0: Limiting direct PCI/PCI transfers
2025-08-02T11:49:39,442108+00:00 pci 0000:00:01.0: Activating ISA DMA hang workarounds
2025-08-02T11:49:39,443254+00:00 ACPI: \_SB_.LNKD: Enabled at IRQ 11
2025-08-02T11:49:39,445086+00:00 PCI: CLS 0 bytes, default 64
2025-08-02T11:49:39,445106+00:00 PCI-DMA: Using software bounce buffering for IO (SWIOTLB)
2025-08-02T11:49:39,445110+00:00 software IO TLB: mapped [mem 0x00000000bbfda000-0x00000000bffda000] (64MB)
2025-08-02T11:49:39,445160+00:00 clocksource: tsc: mask: 0xffffffffffffffff max_cycles: 0x212731a5301, max_idle_ns: 440795317123 ns
2025-08-02T11:49:39,445256+00:00 Trying to unpack rootfs image as initramfs...
2025-08-02T11:49:39,445962+00:00 Initialise system trusted keyrings
2025-08-02T11:49:39,445992+00:00 Key type blacklist registered
2025-08-02T11:49:39,446094+00:00 workingset: timestamp_bits=36 max_order=22 bucket_order=0
2025-08-02T11:49:39,447474+00:00 zbud: loaded
2025-08-02T11:49:39,447753+00:00 squashfs: version 4.0 (2009/01/31) Phillip Lougher
2025-08-02T11:49:39,448084+00:00 fuse: init (API version 7.34)
2025-08-02T11:49:39,448438+00:00 integrity: Platform Keyring initialized
2025-08-02T11:49:39,459140+00:00 Key type asymmetric registered
2025-08-02T11:49:39,459153+00:00 Asymmetric key parser 'x509' registered
2025-08-02T11:49:39,459188+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 243)
2025-08-02T11:49:39,459316+00:00 io scheduler mq-deadline registered
2025-08-02T11:49:39,460369+00:00 shpchp 0000:00:05.0: Requesting control of SHPC hotplug via OSHP (\_SB_.PCI0.S28_)
2025-08-02T11:49:39,460392+00:00 shpchp 0000:00:05.0: Requesting control of SHPC hotplug via OSHP (\_SB_.PCI0)
2025-08-02T11:49:39,460412+00:00 shpchp 0000:00:05.0: Cannot get control of SHPC hotplug
2025-08-02T11:49:39,460496+00:00 shpchp 0000:00:1e.0: Requesting control of SHPC hotplug via OSHP (\_SB_.PCI0.SF0_)
2025-08-02T11:49:39,460510+00:00 shpchp 0000:00:1e.0: Requesting control of SHPC hotplug via OSHP (\_SB_.PCI0)
2025-08-02T11:49:39,460517+00:00 shpchp 0000:00:1e.0: Cannot get control of SHPC hotplug
2025-08-02T11:49:39,460586+00:00 shpchp 0000:00:1f.0: Requesting control of SHPC hotplug via OSHP (\_SB_.PCI0.SF8_)
2025-08-02T11:49:39,460596+00:00 shpchp 0000:00:1f.0: Requesting control of SHPC hotplug via OSHP (\_SB_.PCI0)
2025-08-02T11:49:39,460600+00:00 shpchp 0000:00:1f.0: Cannot get control of SHPC hotplug
2025-08-02T11:49:39,460613+00:00 shpchp: Standard Hot Plug PCI Controller Driver version: 0.4
2025-08-02T11:49:39,460812+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXPWRBN:00/input/input0
2025-08-02T11:49:39,460861+00:00 ACPI: button: Power Button [PWRF]
2025-08-02T11:49:39,465333+00:00 ACPI: \_SB_.LNKB: Enabled at IRQ 10
2025-08-02T11:49:39,469498+00:00 Serial: 8250/16550 driver, 32 ports, IRQ sharing enabled
2025-08-02T11:49:39,487331+00:00 Linux agpgart interface v0.103
2025-08-02T11:49:39,491355+00:00 loop: module loaded
2025-08-02T11:49:39,491609+00:00 ata_piix 0000:00:01.1: version 2.13
2025-08-02T11:49:39,492706+00:00 scsi host0: ata_piix
2025-08-02T11:49:39,493026+00:00 scsi host1: ata_piix
2025-08-02T11:49:39,493084+00:00 ata1: PATA max MWDMA2 cmd 0x1f0 ctl 0x3f6 bmdma 0xf100 irq 14
2025-08-02T11:49:39,493092+00:00 ata2: PATA max MWDMA2 cmd 0x170 ctl 0x376 bmdma 0xf108 irq 15
2025-08-02T11:49:39,493287+00:00 tun: Universal TUN/TAP device driver, 1.6
2025-08-02T11:49:39,493363+00:00 PPP generic driver version 2.4.2
2025-08-02T11:49:39,493485+00:00 VFIO - User Level meta-driver version: 0.3
2025-08-02T11:49:39,493640+00:00 ehci_hcd: USB 2.0 'Enhanced' Host Controller (EHCI) Driver
2025-08-02T11:49:39,493651+00:00 ehci-pci: EHCI PCI platform driver
2025-08-02T11:49:39,493661+00:00 ehci-platform: EHCI generic platform driver
2025-08-02T11:49:39,493667+00:00 ohci_hcd: USB 1.1 'Open' Host Controller (OHCI) Driver
2025-08-02T11:49:39,493670+00:00 ohci-pci: OHCI PCI platform driver
2025-08-02T11:49:39,493680+00:00 ohci-platform: OHCI generic platform driver
2025-08-02T11:49:39,493688+00:00 uhci_hcd: USB Universal Host Controller Interface driver
2025-08-02T11:49:39,495336+00:00 uhci_hcd 0000:00:01.2: UHCI Host Controller
2025-08-02T11:49:39,495352+00:00 uhci_hcd 0000:00:01.2: new USB bus registered, assigned bus number 1
2025-08-02T11:49:39,495380+00:00 uhci_hcd 0000:00:01.2: detected 2 ports
2025-08-02T11:49:39,495510+00:00 uhci_hcd 0000:00:01.2: irq 11, io base 0x0000f0c0
2025-08-02T11:49:39,495675+00:00 usb usb1: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 5.15
2025-08-02T11:49:39,495684+00:00 usb usb1: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2025-08-02T11:49:39,495693+00:00 usb usb1: Product: UHCI Host Controller
2025-08-02T11:49:39,495697+00:00 usb usb1: Manufacturer: Linux 5.15.0-142-generic uhci_hcd
2025-08-02T11:49:39,495701+00:00 usb usb1: SerialNumber: 0000:00:01.2
2025-08-02T11:49:39,495888+00:00 hub 1-0:1.0: USB hub found
2025-08-02T11:49:39,495910+00:00 hub 1-0:1.0: 2 ports detected
2025-08-02T11:49:39,496137+00:00 i8042: PNP: PS/2 Controller [PNP0303:KBD,PNP0f13:MOU] at 0x60,0x64 irq 1,12
2025-08-02T11:49:39,497091+00:00 serio: i8042 KBD port at 0x60,0x64 irq 1
2025-08-02T11:49:39,497105+00:00 serio: i8042 AUX port at 0x60,0x64 irq 12
2025-08-02T11:49:39,497291+00:00 mousedev: PS/2 mouse device common for all mice
2025-08-02T11:49:39,497744+00:00 input: AT Translated Set 2 keyboard as /devices/platform/i8042/serio0/input/input1
2025-08-02T11:49:39,497862+00:00 rtc_cmos 00:03: RTC can wake from S4
2025-08-02T11:49:39,498573+00:00 rtc_cmos 00:03: registered as rtc0
2025-08-02T11:49:39,499289+00:00 rtc_cmos 00:03: setting system clock to 2025-08-02T11:49:39 UTC (1754135379)
2025-08-02T11:49:39,499382+00:00 rtc_cmos 00:03: alarms up to one day, y3k, 242 bytes nvram, hpet irqs
2025-08-02T11:49:39,499394+00:00 i2c_dev: i2c /dev entries driver
2025-08-02T11:49:39,499427+00:00 device-mapper: core: CONFIG_IMA_DISABLE_HTABLE is disabled. Duplicate IMA measurements will not be recorded in the IMA log.
2025-08-02T11:49:39,499467+00:00 device-mapper: uevent: version 1.0.3
2025-08-02T11:49:39,499562+00:00 device-mapper: ioctl: 4.45.0-ioctl (2021-03-22) initialised: dm-devel@redhat.com
2025-08-02T11:49:39,499568+00:00 intel_pstate: CPU model not supported
2025-08-02T11:49:39,500039+00:00 ledtrig-cpu: registered to indicate activity on CPUs
2025-08-02T11:49:39,500089+00:00 efifb: probing for efifb
2025-08-02T11:49:39,500110+00:00 efifb: No BGRT, not showing boot graphics
2025-08-02T11:49:39,500112+00:00 efifb: framebuffer at 0xfd000000, using 1408k, total 1408k
2025-08-02T11:49:39,500115+00:00 efifb: mode is 800x600x24, linelength=2400, pages=1
2025-08-02T11:49:39,500118+00:00 efifb: scrolling: redraw
2025-08-02T11:49:39,500119+00:00 efifb: Truecolor: size=0:8:8:8, shift=0:16:8:0
2025-08-02T11:49:39,500291+00:00 Console: switching to colour frame buffer device 100x37
2025-08-02T11:49:39,503013+00:00 fb0: EFI VGA frame buffer device
2025-08-02T11:49:39,503149+00:00 drop_monitor: Initializing network drop monitor service
2025-08-02T11:49:39,503417+00:00 NET: Registered PF_INET6 protocol family
2025-08-02T11:49:39,651721+00:00 ata2.00: ATAPI: QEMU DVD-ROM, 2.5+, max UDMA/100
2025-08-02T11:49:39,653365+00:00 scsi 1:0:0:0: CD-ROM            QEMU     QEMU DVD-ROM     2.5+ PQ: 0 ANSI: 5
2025-08-02T11:49:39,687371+00:00 sr 1:0:0:0: [sr0] scsi3-mmc drive: 4x/4x cd/rw xa/form2 tray
2025-08-02T11:49:39,687427+00:00 cdrom: Uniform CD-ROM driver Revision: 3.20
2025-08-02T11:49:39,751316+00:00 sr 1:0:0:0: Attached scsi CD-ROM sr0
2025-08-02T11:49:39,751412+00:00 sr 1:0:0:0: Attached scsi generic sg0 type 5
2025-08-02T11:49:39,830439+00:00 usb 1-1: new full-speed USB device number 2 using uhci_hcd
2025-08-02T11:49:40,016499+00:00 usb 1-1: New USB device found, idVendor=0627, idProduct=0001, bcdDevice= 0.00
2025-08-02T11:49:40,016585+00:00 usb 1-1: New USB device strings: Mfr=1, Product=3, SerialNumber=10
2025-08-02T11:49:40,016648+00:00 usb 1-1: Product: QEMU USB Tablet
2025-08-02T11:49:40,018007+00:00 usb 1-1: Manufacturer: QEMU
2025-08-02T11:49:40,019030+00:00 usb 1-1: SerialNumber: 28754-0000:00:01.2-1
2025-08-02T11:49:40,251423+00:00 Freeing initrd memory: 107356K
2025-08-02T11:49:40,262070+00:00 Segment Routing with IPv6
2025-08-02T11:49:40,263170+00:00 In-situ OAM (IOAM) with IPv6
2025-08-02T11:49:40,264167+00:00 NET: Registered PF_PACKET protocol family
2025-08-02T11:49:40,265199+00:00 Key type dns_resolver registered
2025-08-02T11:49:40,267145+00:00 IPI shorthand broadcast: enabled
2025-08-02T11:49:40,268034+00:00 sched_clock: Marking stable (1184691253, -716999)->(1212819177, -28844923)
2025-08-02T11:49:40,269358+00:00 registered taskstats version 1
2025-08-02T11:49:40,271041+00:00 Loading compiled-in X.509 certificates
2025-08-02T11:49:40,273094+00:00 Loaded X.509 cert 'Build time autogenerated kernel key: 3eefbd0531de61f8b3b4b5eda3826d6ede23b67e'
2025-08-02T11:49:40,275676+00:00 Loaded X.509 cert 'Canonical Ltd. Live Patch Signing 2025 Kmod: d541cef61dc7e793b7eb7e899970a2eef0b5dc8c'
2025-08-02T11:49:40,278060+00:00 Loaded X.509 cert 'Canonical Ltd. Live Patch Signing: 14df34d1a87cf37625abec039ef2bf521249b969'
2025-08-02T11:49:40,280489+00:00 Loaded X.509 cert 'Canonical Ltd. Kernel Module Signing: 88f752e560a1e0737e31163a466ad7b70a850c19'
2025-08-02T11:49:40,282344+00:00 blacklist: Loading compiled-in revocation X.509 certificates
2025-08-02T11:49:40,283578+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing: 61482aa2830d0ab2ad5af10b7250da9033ddcef0'
2025-08-02T11:49:40,285755+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2017): 242ade75ac4a15e50d50c84b0d45ff3eae707a03'
2025-08-02T11:49:40,287739+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (ESM 2018): 365188c1d374d6b07c3c8f240f8ef722433d6a8b'
2025-08-02T11:49:40,290002+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2019): c0746fd6c5da3ae827864651ad66ae47fe24b3e8'
2025-08-02T11:49:40,292698+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v1): a8d54bbb3825cfb94fa13c9f8a594a195c107b8d'
2025-08-02T11:49:40,295422+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v2): 4cf046892d6fd3c9a5b03f98d845f90851dc6a8c'
2025-08-02T11:49:40,297741+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v3): 100437bb6de6e469b581e61cd66bce3ef4ed53af'
2025-08-02T11:49:40,299987+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (Ubuntu Core 2019): c1d57b8f6b743f23ee41f4f7ee292f06eecadfb9'
2025-08-02T11:49:40,303272+00:00 zswap: loaded using pool lzo/zbud
2025-08-02T11:49:40,305455+00:00 Key type .fscrypt registered
2025-08-02T11:49:40,306623+00:00 Key type fscrypt-provisioning registered
2025-08-02T11:49:40,312601+00:00 Key type encrypted registered
2025-08-02T11:49:40,314292+00:00 AppArmor: AppArmor sha1 policy hashing enabled
2025-08-02T11:49:40,315970+00:00 ima: No TPM chip found, activating TPM-bypass!
2025-08-02T11:49:40,317644+00:00 Loading compiled-in module X.509 certificates
2025-08-02T11:49:40,320005+00:00 Loaded X.509 cert 'Build time autogenerated kernel key: 3eefbd0531de61f8b3b4b5eda3826d6ede23b67e'
2025-08-02T11:49:40,322835+00:00 ima: Allocated hash algorithm: sha1
2025-08-02T11:49:40,324135+00:00 ima: No architecture policies found
2025-08-02T11:49:40,325339+00:00 evm: Initialising EVM extended attributes:
2025-08-02T11:49:40,326726+00:00 evm: security.selinux
2025-08-02T11:49:40,327817+00:00 evm: security.SMACK64
2025-08-02T11:49:40,328929+00:00 evm: security.SMACK64EXEC
2025-08-02T11:49:40,330106+00:00 evm: security.SMACK64TRANSMUTE
2025-08-02T11:49:40,331282+00:00 evm: security.SMACK64MMAP
2025-08-02T11:49:40,332284+00:00 evm: security.apparmor
2025-08-02T11:49:40,333242+00:00 evm: security.ima
2025-08-02T11:49:40,334221+00:00 evm: security.capability
2025-08-02T11:49:40,335177+00:00 evm: HMAC attrs: 0x1
2025-08-02T11:49:40,336479+00:00 PM:   Magic number: 5:116:832
2025-08-02T11:49:40,338203+00:00 RAS: Correctable Errors collector initialized.
2025-08-02T11:49:40,339651+00:00 clk: Disabling unused clocks
2025-08-02T11:49:40,342348+00:00 Freeing unused decrypted memory: 2036K
2025-08-02T11:49:40,344231+00:00 Freeing unused kernel image (initmem) memory: 3284K
2025-08-02T11:49:40,345385+00:00 Write protecting the kernel read-only data: 30720k
2025-08-02T11:49:40,347960+00:00 Freeing unused kernel image (text/rodata gap) memory: 2036K
2025-08-02T11:49:40,349361+00:00 Freeing unused kernel image (rodata/data gap) memory: 1308K
2025-08-02T11:49:40,405722+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2025-08-02T11:49:40,406701+00:00 x86/mm: Checking user space page tables
2025-08-02T11:49:40,458469+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2025-08-02T11:49:40,459315+00:00 Run /init as init process
2025-08-02T11:49:40,460181+00:00   with arguments:
2025-08-02T11:49:40,460184+00:00     /init
2025-08-02T11:49:40,460186+00:00   with environment:
2025-08-02T11:49:40,460188+00:00     HOME=/
2025-08-02T11:49:40,460189+00:00     TERM=linux
2025-08-02T11:49:40,460190+00:00     BOOT_IMAGE=/boot/vmlinuz-5.15.0-142-generic
2025-08-02T11:49:40,604571+00:00 piix4_smbus 0000:00:01.3: SMBus Host Controller at 0x700, revision 0
2025-08-02T11:49:40,607212+00:00 virtio_blk virtio1: [vda] 209715200 512-byte logical blocks (107 GB/100 GiB)
2025-08-02T11:49:40,611007+00:00 hid: raw HID events driver (C) Jiri Kosina
2025-08-02T11:49:40,613598+00:00 cryptd: max_cpu_qlen set to 1000
2025-08-02T11:49:40,615291+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input4
2025-08-02T11:49:40,620556+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input3
2025-08-02T11:49:40,627022+00:00 usbcore: registered new interface driver usbhid
2025-08-02T11:49:40,627861+00:00 usbhid: USB HID core driver
2025-08-02T11:49:40,628625+00:00  vda: vda1 vda2
2025-08-02T11:49:40,631393+00:00 AVX2 version of gcm_enc/dec engaged.
2025-08-02T11:49:40,632658+00:00 AES CTR mode by8 optimization enabled
2025-08-02T11:49:40,645809+00:00 Console: switching to colour dummy device 80x25
2025-08-02T11:49:40,645932+00:00 bochs-drm 0000:00:02.0: vgaarb: deactivate vga console
2025-08-02T11:49:40,646181+00:00 [drm] Found bochs VGA, ID 0xb0c5.
2025-08-02T11:49:40,646188+00:00 [drm] Framebuffer size 16384 kB @ 0xfd000000, mmio @ 0xfea50000.
2025-08-02T11:49:40,648223+00:00 [drm] Found EDID data blob.
2025-08-02T11:49:40,648449+00:00 [drm] Initialized bochs-drm 1.0.0 20130925 for 0000:00:02.0 on minor 0
2025-08-02T11:49:40,649915+00:00 fbcon: bochs-drmdrmfb (fb0) is primary device
2025-08-02T11:49:40,658362+00:00 Console: switching to colour frame buffer device 160x50
2025-08-02T11:49:40,663676+00:00 bochs-drm 0000:00:02.0: [drm] fb0: bochs-drmdrmfb frame buffer device
2025-08-02T11:49:40,688349+00:00 input: QEMU QEMU USB Tablet as /devices/pci0000:00/0000:00:01.2/usb1/1-1/1-1:1.0/0003:0627:0001.0001/input/input5
2025-08-02T11:49:40,688772+00:00 hid-generic 0003:0627:0001.0001: input,hidraw0: USB HID v0.01 Mouse [QEMU QEMU USB Tablet] on usb-0000:00:01.2-1/input0
2025-08-02T11:49:40,689519+00:00 virtio_net virtio2 ens18: renamed from eth0
2025-08-02T11:49:40,966410+00:00 raid6: avx2x4   gen() 14228 MB/s
2025-08-02T11:49:41,034429+00:00 raid6: avx2x4   xor()  6965 MB/s
2025-08-02T11:49:41,102428+00:00 raid6: avx2x2   gen() 13720 MB/s
2025-08-02T11:49:41,170419+00:00 raid6: avx2x2   xor()  9222 MB/s
2025-08-02T11:49:41,238417+00:00 raid6: avx2x1   gen() 12325 MB/s
2025-08-02T11:49:41,306421+00:00 raid6: avx2x1   xor()  7913 MB/s
2025-08-02T11:49:41,374423+00:00 raid6: sse2x4   gen()  7777 MB/s
2025-08-02T11:49:41,442416+00:00 raid6: sse2x4   xor()  5117 MB/s
2025-08-02T11:49:41,510413+00:00 raid6: sse2x2   gen()  7789 MB/s
2025-08-02T11:49:41,578422+00:00 raid6: sse2x2   xor()  5266 MB/s
2025-08-02T11:49:41,646416+00:00 raid6: sse2x1   gen()  6106 MB/s
2025-08-02T11:49:41,714417+00:00 raid6: sse2x1   xor()  4321 MB/s
2025-08-02T11:49:41,714451+00:00 raid6: using algorithm avx2x4 gen() 14228 MB/s
2025-08-02T11:49:41,714470+00:00 raid6: .... xor() 6965 MB/s, rmw enabled
2025-08-02T11:49:41,714487+00:00 raid6: using avx2x2 recovery algorithm
2025-08-02T11:49:41,716015+00:00 xor: automatically using best checksumming function   avx       
2025-08-02T11:49:41,717298+00:00 async_tx: api initialized (async)
2025-08-02T11:49:41,806736+00:00 Btrfs loaded, crc32c=crc32c-intel, zoned=yes, fsverity=yes
2025-08-02T11:49:41,950180+00:00 EXT4-fs (vda2): mounted filesystem with ordered data mode. Opts: (null). Quota mode: none.
2025-08-02T11:49:42,238212+00:00 systemd[1]: Inserted module 'autofs4'
2025-08-02T11:49:42,268705+00:00 systemd[1]: systemd 249.11-0ubuntu3.16 running in system mode (+PAM +AUDIT +SELINUX +APPARMOR +IMA +SMACK +SECCOMP +GCRYPT +GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN +IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 -PWQUALITY -P11KIT -QRENCODE +BZIP2 +LZ4 +XZ +ZLIB +ZSTD -XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2025-08-02T11:49:42,270086+00:00 systemd[1]: Detected virtualization kvm.
2025-08-02T11:49:42,270655+00:00 systemd[1]: Detected architecture x86-64.
2025-08-02T11:49:42,274808+00:00 systemd[1]: Hostname set to <k8s-master-n1>.
2025-08-02T11:49:42,513736+00:00 systemd[1]: Configuration file /run/systemd/system/netplan-ovs-cleanup.service is marked world-inaccessible. This has no effect as configuration data is accessible via APIs without restrictions. Proceeding anyway.
2025-08-02T11:49:42,685904+00:00 systemd[1]: Queued start job for default target Graphical Interface.
2025-08-02T11:49:42,689745+00:00 systemd[1]: Created slice Slice /system/modprobe.
2025-08-02T11:49:42,691368+00:00 systemd[1]: Created slice User and Session Slice.
2025-08-02T11:49:42,692667+00:00 systemd[1]: Started Forward Password Requests to Wall Directory Watch.
2025-08-02T11:49:42,694618+00:00 systemd[1]: Set up automount Arbitrary Executable File Formats File System Automount Point.
2025-08-02T11:49:42,696333+00:00 systemd[1]: Reached target Slice Units.
2025-08-02T11:49:42,697866+00:00 systemd[1]: Reached target Mounting snaps.
2025-08-02T11:49:42,699498+00:00 systemd[1]: Reached target Swaps.
2025-08-02T11:49:42,701565+00:00 systemd[1]: Reached target System Time Set.
2025-08-02T11:49:42,703513+00:00 systemd[1]: Reached target Local Verity Protected Volumes.
2025-08-02T11:49:42,705440+00:00 systemd[1]: Listening on Device-mapper event daemon FIFOs.
2025-08-02T11:49:42,707310+00:00 systemd[1]: Listening on LVM2 poll daemon socket.
2025-08-02T11:49:42,708581+00:00 systemd[1]: Listening on multipathd control socket.
2025-08-02T11:49:42,715633+00:00 systemd[1]: Listening on RPCbind Server Activation Socket.
2025-08-02T11:49:42,717140+00:00 systemd[1]: Listening on Syslog Socket.
2025-08-02T11:49:42,718508+00:00 systemd[1]: Listening on fsck to fsckd communication Socket.
2025-08-02T11:49:42,719723+00:00 systemd[1]: Listening on initctl Compatibility Named Pipe.
2025-08-02T11:49:42,721030+00:00 systemd[1]: Listening on Journal Audit Socket.
2025-08-02T11:49:42,722272+00:00 systemd[1]: Listening on Journal Socket (/dev/log).
2025-08-02T11:49:42,725659+00:00 systemd[1]: Listening on Journal Socket.
2025-08-02T11:49:42,727218+00:00 systemd[1]: Listening on Network Service Netlink Socket.
2025-08-02T11:49:42,728438+00:00 systemd[1]: Listening on udev Control Socket.
2025-08-02T11:49:42,729509+00:00 systemd[1]: Listening on udev Kernel Socket.
2025-08-02T11:49:42,732491+00:00 systemd[1]: Mounting Huge Pages File System...
2025-08-02T11:49:42,735329+00:00 systemd[1]: Mounting POSIX Message Queue File System...
2025-08-02T11:49:42,738968+00:00 systemd[1]: Mounting Kernel Debug File System...
2025-08-02T11:49:42,742532+00:00 systemd[1]: Mounting Kernel Trace File System...
2025-08-02T11:49:42,747529+00:00 systemd[1]: Starting Journal Service...
2025-08-02T11:49:42,750020+00:00 systemd[1]: Condition check resulted in Kernel Module supporting RPCSEC_GSS being skipped.
2025-08-02T11:49:42,752609+00:00 systemd[1]: Starting Set the console keyboard layout...
2025-08-02T11:49:42,755500+00:00 systemd[1]: Starting Create List of Static Device Nodes...
2025-08-02T11:49:42,757900+00:00 systemd[1]: Starting Monitoring of LVM2 mirrors, snapshots etc. using dmeventd or progress polling...
2025-08-02T11:49:42,760407+00:00 systemd[1]: Condition check resulted in LXD - agent being skipped.
2025-08-02T11:49:42,762157+00:00 systemd[1]: Starting Load Kernel Module configfs...
2025-08-02T11:49:42,764710+00:00 systemd[1]: Starting Load Kernel Module drm...
2025-08-02T11:49:42,767908+00:00 systemd[1]: Starting Load Kernel Module efi_pstore...
2025-08-02T11:49:42,770682+00:00 systemd[1]: Starting Load Kernel Module fuse...
2025-08-02T11:49:42,771721+00:00 systemd[1]: Condition check resulted in OpenVSwitch configuration for cleanup being skipped.
2025-08-02T11:49:42,772371+00:00 systemd[1]: Condition check resulted in File System Check on Root Device being skipped.
2025-08-02T11:49:42,775735+00:00 systemd[1]: Starting Load Kernel Modules...
2025-08-02T11:49:42,777925+00:00 systemd[1]: Starting Remount Root and Kernel File Systems...
2025-08-02T11:49:42,780036+00:00 systemd[1]: Starting Coldplug All udev Devices...
2025-08-02T11:49:42,784866+00:00 systemd[1]: Mounted Huge Pages File System.
2025-08-02T11:49:42,785083+00:00 EXT4-fs (vda2): re-mounted. Opts: (null). Quota mode: none.
2025-08-02T11:49:42,788164+00:00 systemd[1]: Mounted POSIX Message Queue File System.
2025-08-02T11:49:42,789461+00:00 systemd[1]: Mounted Kernel Debug File System.
2025-08-02T11:49:42,792033+00:00 systemd[1]: Mounted Kernel Trace File System.
2025-08-02T11:49:42,796275+00:00 systemd[1]: Finished Create List of Static Device Nodes.
2025-08-02T11:49:42,799755+00:00 systemd[1]: modprobe@configfs.service: Deactivated successfully.
2025-08-02T11:49:42,801655+00:00 systemd[1]: Finished Load Kernel Module configfs.
2025-08-02T11:49:42,802034+00:00 bridge: filtering via arp/ip/ip6tables is no longer available by default. Update your scripts to load br_netfilter if you need this.
2025-08-02T11:49:42,803990+00:00 systemd[1]: Started Journal Service.
2025-08-02T11:49:42,806040+00:00 Bridge firewalling registered
2025-08-02T11:49:42,831369+00:00 alua: device handler registered
2025-08-02T11:49:42,832470+00:00 systemd-journald[426]: Received client request to flush runtime journal.
2025-08-02T11:49:42,833519+00:00 emc: device handler registered
2025-08-02T11:49:42,837004+00:00 rdac: device handler registered
2025-08-02T11:49:42,903138+00:00 loop0: detected capacity change from 0 to 130568
2025-08-02T11:49:42,904833+00:00 loop1: detected capacity change from 0 to 130592
2025-08-02T11:49:42,910108+00:00 loop2: detected capacity change from 0 to 178256
2025-08-02T11:49:42,915414+00:00 loop3: detected capacity change from 0 to 183096
2025-08-02T11:49:42,920648+00:00 loop4: detected capacity change from 0 to 104240
2025-08-02T11:49:42,924590+00:00 loop5: detected capacity change from 0 to 100952
2025-08-02T11:49:43,000613+00:00 audit: type=1400 audit(1754135382.996:2): apparmor="STATUS" operation="profile_load" profile="unconfined" name="lsb_release" pid=495 comm="apparmor_parser"
2025-08-02T11:49:43,001457+00:00 audit: type=1400 audit(1754135382.996:3): apparmor="STATUS" operation="profile_load" profile="unconfined" name="nvidia_modprobe" pid=496 comm="apparmor_parser"
2025-08-02T11:49:43,001465+00:00 audit: type=1400 audit(1754135382.996:4): apparmor="STATUS" operation="profile_load" profile="unconfined" name="nvidia_modprobe//kmod" pid=496 comm="apparmor_parser"
2025-08-02T11:49:43,002882+00:00 audit: type=1400 audit(1754135383.000:5): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/bin/man" pid=500 comm="apparmor_parser"
2025-08-02T11:49:43,002890+00:00 audit: type=1400 audit(1754135383.000:6): apparmor="STATUS" operation="profile_load" profile="unconfined" name="man_filter" pid=500 comm="apparmor_parser"
2025-08-02T11:49:43,002894+00:00 audit: type=1400 audit(1754135383.000:7): apparmor="STATUS" operation="profile_load" profile="unconfined" name="man_groff" pid=500 comm="apparmor_parser"
2025-08-02T11:49:43,006650+00:00 audit: type=1400 audit(1754135383.004:8): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/lib/snapd/snap-confine" pid=502 comm="apparmor_parser"
2025-08-02T11:49:43,006657+00:00 audit: type=1400 audit(1754135383.004:9): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/lib/snapd/snap-confine//mount-namespace-capture-helper" pid=502 comm="apparmor_parser"
2025-08-02T11:49:43,009058+00:00 audit: type=1400 audit(1754135383.004:10): apparmor="STATUS" operation="profile_load" profile="unconfined" name="ubuntu_pro_apt_news" pid=498 comm="apparmor_parser"
2025-08-02T11:49:43,261052+00:00 RAPL PMU: API unit is 2^-32 Joules, 0 fixed counters, 10737418240 ms ovfl timer
2025-08-02T11:49:43,444509+00:00 RPC: Registered named UNIX socket transport module.
2025-08-02T11:49:43,444515+00:00 RPC: Registered udp transport module.
2025-08-02T11:49:43,444516+00:00 RPC: Registered tcp transport module.
2025-08-02T11:49:43,444517+00:00 RPC: Registered tcp NFSv4.1 backchannel transport module.
2025-08-02T11:49:46,699473+00:00 Loading iSCSI transport class v2.0-870.
2025-08-02T11:49:53,615012+00:00 loop6: detected capacity change from 0 to 8
2025-08-02T11:51:54,776072+00:00 kauditd_printk_skb: 33 callbacks suppressed
2025-08-02T11:51:54,776088+00:00 audit: type=1400 audit(1754135514.861:44): apparmor="STATUS" operation="profile_load" profile="unconfined" name="cri-containerd.apparmor.d" pid=1577 comm="apparmor_parser"
2025-08-02T11:51:54,776479+00:00 audit: type=1400 audit(1754135514.861:45): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="cri-containerd.apparmor.d" pid=1575 comm="apparmor_parser"
2025-08-02T11:51:54,777802+00:00 audit: type=1400 audit(1754135514.865:46): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="cri-containerd.apparmor.d" pid=1579 comm="apparmor_parser"
2025-08-02T11:51:54,781891+00:00 audit: type=1400 audit(1754135514.869:47): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="cri-containerd.apparmor.d" pid=1578 comm="apparmor_parser"
2025-08-02T11:53:16,229451+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): cilium_net: link becomes ready
2025-08-02T11:53:16,229563+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): cilium_host: link becomes ready
2025-08-02T11:53:18,382032+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-02T11:53:21,082077+00:00 eth0: renamed from tmpfa970
2025-08-02T11:53:21,100988+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2025-08-02T11:53:21,101067+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc58ab27bf58c0: link becomes ready
2025-08-02T11:53:21,131372+00:00 eth0: renamed from tmp31e6a
2025-08-02T11:53:21,162114+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc06759d08b236: link becomes ready
2025-08-02T11:53:22,040193+00:00 cilium_vxlan: Caught tx_queue_len zero misconfig
2025-08-02T11:53:22,095880+00:00 Initializing XFRM netlink socket
2025-08-02T11:54:08,089833+00:00 eth0: renamed from tmpe83bc
2025-08-02T11:54:08,161784+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2025-08-02T11:54:08,161854+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc689a0c20511e: link becomes ready
2025-08-02T11:54:08,217763+00:00 eth0: renamed from tmp8408a
2025-08-02T11:54:08,298106+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcfcc06f0c2863: link becomes ready
2025-08-02T11:58:24,757774+00:00 eth0: renamed from tmpdee7e
2025-08-02T11:58:24,799534+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc19ab778dadc1: link becomes ready
2025-08-02T11:58:24,841736+00:00 eth0: renamed from tmpf4697
2025-08-02T11:58:24,873836+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2025-08-02T11:58:24,873925+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc4953b004582a: link becomes ready
2025-08-02T11:58:28,226035+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-02T12:01:23,159180+00:00 eth0: renamed from tmpb47b0
2025-08-02T12:01:23,193809+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc2bc425394e7e: link becomes ready
2025-08-02T12:02:47,446235+00:00 eth0: renamed from tmpbe48e
2025-08-02T12:02:47,474356+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxce5cf8d7e6021: link becomes ready
2025-08-02T12:03:28,537917+00:00 eth0: renamed from tmpe24e1
2025-08-02T12:03:28,565925+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2025-08-02T12:03:28,565989+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcd06f0cab4f14: link becomes ready
2025-08-02T18:37:48,975552+00:00 eth0: renamed from tmp1f83e
2025-08-02T18:37:48,992307+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc0078399641bb: link becomes ready
2025-08-02T18:39:22,027594+00:00 eth0: renamed from tmp4e8ff
2025-08-02T18:39:22,055941+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc5621e3ade00a: link becomes ready
2025-08-02T18:41:35,492305+00:00 eth0: renamed from tmpb3d9b
2025-08-02T18:41:35,515954+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcb19fd20ec457: link becomes ready
2025-08-02T18:45:07,811912+00:00 eth0: renamed from tmp81eca
2025-08-02T18:45:07,840198+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc8fcdd7282462: link becomes ready
2025-08-03T03:18:50,549381+00:00 systemd-journald[426]: Retention time reached.
2025-08-03T05:46:18,055481+00:00 eth0: renamed from tmp676e5
2025-08-03T05:46:18,075266+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcaa7d1a18b08a: link becomes ready
2025-08-03T06:15:06,615979+00:00 eth0: renamed from tmp253cf
2025-08-03T06:15:06,636274+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcb4fdff93a4d3: link becomes ready
2025-08-03T06:16:16,776882+00:00 eth0: renamed from tmp0d8d0
2025-08-03T06:16:16,800161+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcef9ebbe357f2: link becomes ready
2025-08-03T10:43:17,152249+00:00 eth0: renamed from tmp1b5d2
2025-08-03T10:43:17,180316+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcf328247c3410: link becomes ready
2025-08-03T10:46:59,612650+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T10:57:05,128657+00:00 eth0: renamed from tmp96549
2025-08-03T10:57:05,152841+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcb58fde5112c7: link becomes ready
2025-08-03T11:07:34,317497+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T11:13:21,426214+00:00 eth0: renamed from tmpcf0d6
2025-08-03T11:13:21,445218+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcb587064aecb1: link becomes ready
2025-08-03T11:16:01,161314+00:00 eth0: renamed from tmp46b39
2025-08-03T11:16:01,178089+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2025-08-03T11:16:01,178165+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc4cef0965cc0d: link becomes ready
2025-08-03T11:16:44,181436+00:00 eth0: renamed from tmpd667a
2025-08-03T11:16:44,201750+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc44898f59817b: link becomes ready
2025-08-03T11:19:54,045444+00:00 eth0: renamed from tmp77f41
2025-08-03T11:19:54,069673+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc6e89c6bc52ac: link becomes ready
2025-08-03T11:26:34,077809+00:00 eth0: renamed from tmpbd33b
2025-08-03T11:26:34,093905+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc1d72d2feaebb: link becomes ready
2025-08-03T11:42:08,554442+00:00 eth0: renamed from tmpf38e4
2025-08-03T11:42:08,574492+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc065c8232e8fd: link becomes ready
2025-08-03T11:49:30,175246+00:00 eth0: renamed from tmpe10d0
2025-08-03T11:49:30,198641+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2025-08-03T11:49:30,198717+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc06ffa71b700a: link becomes ready
2025-08-03T11:53:52,915168+00:00 eth0: renamed from tmp0211e
2025-08-03T11:53:52,934750+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc13a868b569bb: link becomes ready
2025-08-03T11:54:23,510641+00:00 eth0: renamed from tmp404de
2025-08-03T11:54:23,534868+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2025-08-03T11:54:23,534921+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcf57d951d1bb3: link becomes ready
2025-08-03T12:32:53,603712+00:00 eth0: renamed from tmpdfabd
2025-08-03T12:32:53,624722+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2025-08-03T12:32:53,624787+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc5b5d7377c42c: link becomes ready
2025-08-03T12:35:24,227775+00:00 eth0: renamed from tmp6e4b5
2025-08-03T12:35:24,260231+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc55782e7376f8: link becomes ready
2025-08-03T13:04:47,592949+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T13:09:59,281622+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T13:33:34,996011+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T13:35:05,354516+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T13:35:50,446019+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T13:38:56,826895+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T13:40:21,194306+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T13:50:16,170279+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T13:50:28,162367+00:00 eth0: renamed from tmp321c5
2025-08-03T13:50:28,191467+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2025-08-03T13:50:28,191543+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc5ca0daa43914: link becomes ready
2025-08-03T14:09:02,390287+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T14:09:29,587044+00:00 eth0: renamed from tmp3b897
2025-08-03T14:09:29,627004+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcf9e134da9662: link becomes ready
2025-08-03T14:14:11,769319+00:00 device cilium_vxlan entered promiscuous mode
2025-08-03T14:22:06,891187+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2025-08-03T14:25:05,323945+00:00 printk: dmesg (52263): Attempt to access syslog with CAP_SYS_ADMIN but no CAP_SYSLOG (deprecated).
