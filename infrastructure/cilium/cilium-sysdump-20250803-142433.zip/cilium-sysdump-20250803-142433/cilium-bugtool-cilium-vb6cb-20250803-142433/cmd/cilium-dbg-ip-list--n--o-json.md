[
  {
    "cidr": "0.0.0.0/0",
    "identity": 2
  },
  {
    "cidr": "10.0.0.0/24",
    "hostIP": "91.217.196.189",
    "identity": 2
  },
  {
    "cidr": "10.0.0.43/32",
    "hostIP": "91.217.196.189",
    "identity": 17157,
    "metadata": {
      "name": "hubble-relay-6b7b5877f4-vfr4c",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.0.0.124/32",
    "hostIP": "91.217.196.189",
    "identity": 6
  },
  {
    "cidr": "10.0.0.203/32",
    "hostIP": "91.217.196.189",
    "identity": 4
  },
  {
    "cidr": "10.0.0.220/32",
    "hostIP": "91.217.196.189",
    "identity": 24121,
    "metadata": {
      "name": "coredns-54558b56c7-zth5g",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.0.0.236/32",
    "hostIP": "91.217.196.189",
    "identity": 64642,
    "metadata": {
      "name": "dnsutils",
      "namespace": "default",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.0.1.78/32",
    "hostIP": "91.217.196.183",
    "identity": 2284,
    "metadata": {
      "name": "hubble-ui-655f947f96-bdmvs",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.0.1.138/32",
    "hostIP": "91.217.196.183",
    "identity": 1
  },
  {
    "cidr": "10.0.1.156/32",
    "hostIP": "91.217.196.183",
    "identity": 45704,
    "metadata": {
      "name": "metrics-server-7f4c46496-hwgxn",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.0.1.184/32",
    "hostIP": "91.217.196.183",
    "identity": 24121,
    "metadata": {
      "name": "coredns-54558b56c7-tsmph",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.0.1.237/32",
    "hostIP": "91.217.196.183",
    "identity": 4
  },
  {
    "cidr": "91.217.196.183/32",
    "identity": 1
  },
  {
    "cidr": "91.217.196.189/32",
    "identity": 7
  }
]

