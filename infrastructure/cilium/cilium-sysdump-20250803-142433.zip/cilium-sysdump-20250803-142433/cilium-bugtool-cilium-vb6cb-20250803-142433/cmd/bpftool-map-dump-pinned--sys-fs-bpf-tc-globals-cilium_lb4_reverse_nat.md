key: 00 0c  value: 0a 64 a6 be 00 50
key: 00 07  value: 0a 60 00 0a 00 35
key: 00 01  value: 0a 60 00 01 01 bb
key: 00 0b  value: 0a 69 e9 b1 01 bb
key: 00 05  value: 0a 60 00 0a 00 35
key: 00 0e  value: 0a 6f 4a 7e 01 bb
key: 00 0d  value: 0a 60 c4 1d 00 50
key: 00 06  value: 0a 60 00 0a 23 c1
Found 8 elements
