REASON                                            DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                                         INGRESS     1092      70206       1172   bpf_host.c
Interface                                         INGRESS     1207960   852579872   1202   bpf_host.c
Interface                                         INGRESS     1641420   91919520    1121   bpf_host.c
Interface                                         INGRESS     37385     2093560     1075   bpf_host.c
Interface                                         INGRESS     44956     32160183    1156   bpf_host.c
Interface                                         INGRESS     48821     3137460     1218   bpf_host.c
LB: sock cgroup: Reverse entry delete succeeded   EGRESS      1447      0           1256   bpf_sock.c
Success                                           EGRESS      1026      67724       1808   bpf_host.c
Success                                           EGRESS      19743     1871030     75     local_delivery.h
Success                                           EGRESS      24674     1790257     53     encap.h
Success                                           EGRESS      28917     3203003     1659   bpf_host.c
Success                                           EGRESS      32122     24812871    459    nodeport_egress.h
Success                                           EGRESS      384248    41184279    1347   bpf_lxc.c
Success                                           EGRESS      46        7078        122    local_delivery.h
Success                                           EGRESS      574634    251880827   293    trace.h
Success                                           EGRESS      6402      475020      1819   bpf_host.c
Success                                           EGRESS      6662      583392      1344   bpf_lxc.c
Success                                           EGRESS      7245      537587      35     encap.h
Success                                           EGRESS      7307      902441      1648   bpf_host.c
Success                                           INGRESS     444839    41472412    75     local_delivery.h
Success                                           INGRESS     464570    43340994    293    trace.h
Success                                           INGRESS     8110      854982      122    local_delivery.h
Success                                           INGRESS     8168      864508      2030   bpf_lxc.c
Unsupported L3 protocol                           EGRESS      399       29966       1544   bpf_lxc.c
