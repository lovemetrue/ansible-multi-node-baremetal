top - 14:25:05 up 1 day,  2:25,  0 user,  load average: 0.08, 0.09, 0.09
Tasks:  14 total,   8 running,   5 sleeping,   0 stopped,   1 zombie
%Cpu(s): 20.4 us, 46.6 sy,  0.0 ni, 29.1 id,  1.0 wa,  0.0 hi,  0.0 si,  2.9 st 
MiB Mem :  15987.8 total,  11293.9 free,   1178.2 used,   3869.3 buff/cache     
MiB Swap:      0.0 total,      0.0 free,      0.0 used.  14809.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    570 root      20   0    4244   1280   1148 R 100.0   0.0   0:00.14 bpftool
    597 root      20   0   47776  41932   2412 R 100.0   0.3   0:00.12 bpftool
    599 root      20   0    2840   1068    980 R 100.0   0.0   0:00.11 cat
    607 root      20   0 1324752  65284  52388 S 100.0   0.4   0:00.10 cilium-+
    608 root      20   0 1324240  65376  52556 S  90.0   0.4   0:00.09 cilium-+
    629 root      20   0       0      0      0 Z  90.0   0.0   0:00.09 cilium-+
    630 root      20   0 1323984  60952  49676 R  70.0   0.4   0:00.07 cilium-+
      1 root      20   0 1429684 181612  96856 S  40.0   1.1   0:13.50 cilium-+
    659 root      20   0 1321808  20112  18836 R  10.0   0.1   0:00.01 cilium-+
    235 root      20   0 1230132   4516   3712 S   0.0   0.0   0:00.01 cilium-+
    488 root      20   0 1238076  15732   9680 S   0.0   0.1   0:00.10 cilium-+
    525 root      20   0    8716   4788   2912 R   0.0   0.0   0:00.00 top
    655 root      20   0 1322064  24836  22924 R   0.0   0.2   0:00.00 cilium-+
    658 root      20   0 1321296   9360   8980 R   0.0   0.1   0:00.00 cilium
