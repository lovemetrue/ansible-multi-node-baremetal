ID   Capture Length   Wildcard Filters   

Users   Priority      Wildcard Masks   
