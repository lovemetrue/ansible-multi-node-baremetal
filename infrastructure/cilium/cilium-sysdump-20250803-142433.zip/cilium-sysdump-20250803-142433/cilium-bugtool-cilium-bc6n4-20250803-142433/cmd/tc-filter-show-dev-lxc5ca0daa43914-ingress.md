filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc5ca0daa43914 direct-action not_in_hw id 7264 name cil_from_contai tag 7806952dab6adb9b jited 
